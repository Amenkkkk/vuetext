<template>
  <div class="wrapper" > 
       <list-header :title="title"></list-header>
       <div  class="main-page"  offset-accuracy="300px">
         <div v-if="type==1">
           <div class="pay-a">
               <div class="paytext">应缴党费（元）</div>
               <div class="pay-count">{{Money}}</div>
           </div>
           <div class="pay-b">
               <div class="pay-d border" >
                 <div class="paytext">月固定党费（元）</div>
                 <div class="pay-num">{{moneyMon}}</div>
               </div>
               <div class="pay-d">
                 <div class="paytext">缴纳周期</div>
                 <div class="pay-num2">{{payweek}}</div>
               </div>
           </div>
           <div class="pay-c">
                 <div class="paytext">到期时间</div>
                 <div class="pay-num3">{{payDay}}</div>
           </div>
           <div class="pay-c">
                 <div class="paytext">月工资（元）</div>
                 <div class="pay-num3">{{salary}}</div>
           </div>
         </div>
           <div class="paytips">{{message}}</div>
       </div>
  </div> 
</template>

<style scoped>
   .main-page{background: #f2f2f2}
   .pay-a{background-color: #fff; padding:10px 20px;;margin-bottom: 2px; }
   .paytext{ color: #454545;  height: 30px;line-height: 30px;}
   .pay-count{ font-size: 58px; color:#e20202 ; text-align: center;}
   .pay-b{background-color: #fff; padding-bottom: 10px;justify-content: space-between; align-items: center;flex-direction: row; margin-bottom: 10px; display: flex;}
   .pay-d{ flex: 0.5;  margin-top:5px; padding-left:20px; padding-right: 10px;flex-direction: column; justify-content: space-between; display: flex;}
   .border{border-right:#e4e4e4 1px solid;}
   .pay-num{color: #067ad6; font-size: 18px; }
   .pay-num2{color:#ec7402; font-size: 18px; }
   .pay-num3{color: #067ad6; font-size: 18px;text-align: right;}
   .pay-c{background-color: #fff;padding:8px 20px; margin-bottom: 2px;justify-content: space-between; align-items: center;flex-direction: row; display: flex;}
   .paytips{ text-align: center; margin-top:80px; font-size: 18px; color: #777}
</style>

<script>
import CryptoJS from "crypto-js";
import Header from "../../components/listHeader.vue";
import util from "../../util";

export default {
  components: {
    "list-header": Header
  },
data() {
    return {
       title: this.$route.params.name,
       Money:'120',
       moneyMon:'10',
       payweek:'12',
       payDay:'2020年9月27日',
       salary:'****',
       message:'网上缴费请下载app！',
       type:1,     
    }
},
methods: {
  
 },
created(){
      var me=this
        //   me.token=localStorage.getItem("token")
        //   var POST_USER =me.imgdoc+"/apppaymentrecords/getOrder?USER_ID=" + me.USER_ID;
        //   me.$http({
        //   method: "post",
        //   url: POST_USER,
        //   headers: { "Content-Type": "application/x-www-form-urlencoded" ,
        //              "token": me.token == undefined ? '' : me.token,
        //              "userid": me.USER_ID == undefined ? '' : me.USER_ID,
        //              "timestamp": Date.now().toString(),
        //              "sign": CryptoJS.MD5(Date.now().toString() + me.USER_ID + me.token + '/zhdj/apppaymentrecords/getOrder')+''
        //              }, //新增加
        //   credientials: false,
        //   emulateJSON: true
        // })
        // .then(ret => {//请求成功
        //       console.log(ret.body)
        //       if(ret.body.CODE==1){
        //                me.type=1
        //                me.message = '网上缴费请下载app！';
        //                me.Money = ret.data.DATA.PAY_MONEY;
        //                me.moneyMon = ret.data.DATA.PAY_CYCLE+'个月';
        //                me.payweek = ret.data.DATA.STATIC_PAY;
        //                me.payDay = ret.data.DATA.DEADLINE;
        //                me.salary = ret.data.DATA.SALARY;
        //         }else if(ret.body.CODE==0){
        //          me.$router.push({ name: "login"}); //退出后跳转登录页面
        //          me.Msgtxt('登录超时，请重新登录！')
        //         }else{
        //          me.message = ret.data.MSG
        //       }   
        //   },
        //   ret => {
        //     //请求失败
        //     console.log("服务器请求失败！");
        //   }
        // );
 }
}

</script>