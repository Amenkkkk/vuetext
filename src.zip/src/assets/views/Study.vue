<template>
  <div class="wrapper">
    <home-header :title="title"></home-header>
    <mt-loadmore  :top-method="loadTop" :autoFill='autof'  @top-status-change="handleTopChange"  :bottom-method="loadBottom"  @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="main-list ">
        <!--这个页面还需要添加刷新和加载-->
        <div class="cell-item-top">
            <item-top :topics="topics"></item-top>
        </div>
        <div class="cell-button">
            <study-list  :items="studyList"></study-list>
        </div>
        <div slot="top" class="loadmore-top">
            <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
            <span v-show="topStatus === 'drop'">释放加载</span>
            <span v-show="topStatus === 'loading'">正在加载....</span>
        </div>
             <!--下拉刷新提示-->
        <div slot="bottom" class="loadmore-bottom">
            <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
            <span v-show="bottomStatus === 'loading'">加载中...</span>
         </div><!--上拉加载提示-->
    </mt-loadmore>
    <tabNav :active="active"/>
  </div>
</template>
<style scoped>
.main-list{position: fixed;top: 35px;bottom: 62px;left: 0;right: 0;overflow-y: auto;
  -webkit-overflow-scrolling: touch;}
.cell-item-top{padding-top: 10px;padding-bottom: 10px;/*border-bottom-width: 10px;border-bottom-color: #f2f2f2;*/}


.listbottom{ background-color: #f2f2f2; line-height: 70px; height: 70px; text-align: center}

</style>
<script>
    import Header from '../components/Header.vue';
    import itemTop from '../components/itemTop.vue';
    import studyList from '../components/list/studyList.vue';
    import tabNav from '../components/tabNav.vue';
    import CryptoJS from "crypto-js";    
    export default {
        components: {
            'home-header': Header,
            'item-top': itemTop,
            'study-list': studyList,
            'tabNav':tabNav,
        },
        data () {
          return {
                loadinging: false,
                refreshing: false,
                title:'在线学习',
                active: 3,
                topics:[
                        { title:'在线课堂', img:this.ImageUrl('/icon/mipmap-mdpi/study_zxxt.png'),url:'onlineClass'},
                        { title:'学习测评', img:this.ImageUrl('/icon/mipmap-mdpi/study_xxcp.png'), url:'learnText'},
                        { title:'成绩公开', img:this.ImageUrl('/icon/mipmap-mdpi/study_cjgk.png'), url:'resPublic'},
                        { title:'我的学习', img:this.ImageUrl('/icon/mipmap-mdpi/organize_hyjh.png'), url:'myLearn'}
                ],
                POST_study:'',
                studyList:[{id:'123',url:this.ImageUrl('icon/demo_1.jpg'),type:'2',title:'文化学习课程',create_time:'2020年9月14日'}],
                alllist:'',//文章总数
                listcount:10,//文章加载数
                last:false,
          }
        },
        created: function() {
           // this.datalist() //调用加载数据方法
        },
        methods: {
            datalist(){
                var me = this;
                me.token=localStorage.getItem("token")
                me.POST_study = me.showdoc+'/appocourses/couindex?DEPT_ID='+ me.mydept+'&USER_ID='+me.myuser;
            me.$http({
                method: "post",
                url: me.POST_study,
                headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": me.timestamp,
                     "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appocourses/couindex')+''
                   }, //新增加
                credientials: false,
                emulateJSON: true
                }).then(ret => {
                    //请求成功
                    var tokenkey = ret.headers.map.key // 获取token
                    me.takestate(tokenkey,ret.body.CODE)
                    me.studyList = ret.body.DATA.result;
                    me.alllist = ret.body.DATA.totalResult;  
                    console.log(ret.body)                 
                },ret => {
                    //请求失败
                    console.log("服务器请求失败！");
                }
                );
            },
    loadTop() {
      setTimeout(() => {
        this.listcount = 10; //重置条数
      //  this.datalist(); //重新加载数据
        this.loadingmsg = "上拉加载";
        this.allLoaded = false; //启动加载
        this.$refs.loadmore.onTopLoaded();
        this.Msgtxt("刷新成功！")
      }, 2000);
    },
    loadBottom() {
      this.token = localStorage.getItem("token");
      setTimeout(() => {
        var me = this;
        if (me.alllist - me.listcount > 0) {
          me.listcount = me.listcount + 10;
          me.$http({//获取数据
              method: "post",
              url: me.POST_study + "&SHOWCOUNT=" + me.listcount,
              headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                token: me.token == undefined ? "" : me.token,
                userid: me.USER_ID == undefined ? "" : me.USER_ID,
                timestamp: Date.now().toString(),
                sign:CryptoJS.MD5(Date.now().toString() +me.USER_ID +me.token +'/zhdj/appocourses/couindex') + ""
              }, //新增加
              credientials: false,
              emulateJSON: true
            }).then(res => {
                //请求成功
                me.studyList = res.body.DATA.result;
              },res => {
                //请求失败
                console.log("服务器请求失败！");
              }
            );
        } else {
          me.allLoaded = true;
          me.loadingmsg = "已经到底了";
        }
        me.$refs.loadmore.onBottomLoaded();
      }, 1000);
    }
        }
    }
        
</script>