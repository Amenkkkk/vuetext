<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="main-page" >
            <!-- {{POST_URL}} -->
            <div class="cj_li" v-for="(items,i) in detail_text" :key='i'> 
                <div class="cj_name">
                    <div class="uname">{{items.uname}}</div>
                </div>
                <div class="cj_fenshu">
                    <div class="scores">{{items.scores}}</div>
                </div>
            </div>
        </div>
    </div>
</template>
<style scoped>
.cj_li{display: flex; justify-content:space-between;  flex-direction:row; padding:10px 0;border-bottom:1px solid #ccc; }
.cj_name{flex: 1;border-right:1px solid #ccc; text-align: center; width:55%;height: 35px; line-height: 35px;}
.cj_fenshu{flex: 1;text-align: center;}
.uname{font-size: 16px; text-align: center;}
.scores{font-size: 16px; font-weight: bold;color: #da0000; text-align: center; line-height: 35px;}
</style>

<script>
    import listHeader from '../listHeader.vue'
    import CryptoJS from "crypto-js";        
    export default {
        components: {
            'list-header': listHeader,
        },
        data () {
            var me = this;
            return {  
                loadinging: false,
                refreshing: false,
                title: '',
                detail_text:[{uname:'张三',scores:'95'},{uname:'李四',scores:'90'},{uname:'黄五',scores:'89'},{uname:'张三2',scores:'85'},{uname:'李四3',scores:'82'},{uname:'黄五4',scores:'77'}],
                templateArr :[],
                POST_URL:'/appocourses/retgkList?ID=',
            }
        },
        created: function() {
            var me = this;
            var userDATA= localStorage.getItem("userDATA")   //获取用户信息
            var USER= JSON.parse(userDATA)    //编译用户信息
            me.USER_ID= USER.DATA.USER_ID   //在用户信息中获取id
            me.token=localStorage.getItem("token")
            me.POST_URL=me.showdoc + '/appocourses/retgkList?ID='+me.$route.params.ID//,
            // me.$http({
            //     method: "post",
            //     url: me.POST_URL,
            //     headers: { "Content-Type": "application/x-www-form-urlencoded" ,
            //          "token": me.token == undefined ? '' : me.token,
            //          "userid": me.USER_ID == undefined ? '' : me.USER_ID,
            //          "timestamp": Date.now().toString(),
            //          "sign": CryptoJS.MD5(Date.now().toString() + me.USER_ID + me.token + '/zhdj/appocourses/retgkList')+''
            //        }, //新增加
            //     credientials: false,
            //     emulateJSON: true
            //     })
            //     .then(
            //     res => {
            //         //请求成功
            //      var tokenkey = res.headers.map.key // 获取token
            //         me.takestate(tokenkey,ret.body.CODE)
            //         me.detail_text = res.body.DATA.result;
            //     },
            //     res => {
            //         //请求失败
            //         console.log("服务器请求失败！");
            //     }
            //     );
        },
        methods: {
             
        },
        
    }
        
</script>
