<template>
<div class="newbox" id="ifdiv">
    <mt-loadmore :top-method="loadTop" :autoFill='autof'  @top-status-change="handleTopChange"  :bottom-method="loadBottom"  @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="textbox">
        <div class="newUl" >
            <div class="newLi"  v-for="(item,i) in items" :key="i"  @click="showdetail(item.id)">
                <div class="new-imgdiv" >
                    <img  class="new-img" resize="stretch" :src="item.src" />
                </div>
                <div class="newtext">
                    <div class="new-title"  >{{item.title}}</div>
                    <div class="new-date"  >{{item.publish_date}} <span class="new-ss">{{item.column_name}}</span></div>
                </div>
            </div>
        </div>
        <div slot="top" class="loadmore-top">
            <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
            <span v-show="topStatus === 'drop'">释放加载</span>
            <span v-show="topStatus === 'loading'">正在加载....</span>
             </div>
             <!--下拉刷新提示-->
        <div slot="bottom" class="loadmore-bottom">
            <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
            <span v-show="bottomStatus === 'loading'">加载中...</span>
         </div><!--上拉加载提示-->
    </mt-loadmore>
    <div class="detailbox"  v-if='detail'>  
           <div class="closebtn" ><!--关闭按钮-->
                <img @click="closebox()" class="top-goimg" :src="this.ImageUrl('icon/mipmap-mdpi/ico_back.png')"/>
           </div>
           <detailsjl :infodatas="infodatas"></detailsjl>
           <!-- {{infodatas}} -->
        </div> 
</div>
</template>
<style scoped>
.newbox {
  position: fixed;
  top: 35px;
  bottom: 0;
  left: 0;
  right: 0;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  width: 100%;
}
.textbox {
  display: inherit;
}
.newUl {
  display: block;
}
.newLi:first-child {
  border-top-color: #ccc;
  border-top-width: 1px;
  border-top-style: solid;
}
.newLi {
  border-bottom-color: #ccc;
  border-bottom-width: 1px;
  border-bottom-style: solid;
  padding: 20px;
  display: flex;
  justify-content: space-between;
  flex-direction: row;
}
.new-imgdiv {
  flex: 40%;
}
.new-img {
  width: 100%;
  border: 1px solid #e8e8e8;
  height: 80px;
}
.newtext {
  flex: 70%;
  margin-left: 20px;
  text-align: left;
}
.new-title {
  color: #333;
  margin-bottom: 10px;    min-height: 55px;
}
.new-date {
  font-size: 13px;
  color: #555;
  position: relative;
}
span.new-ss {
  position: absolute;
  right: 0; font-size: 10px;
  border: 1px solid #da0000;
  padding: 0px 5px;
  border-radius: 4px;
  color: #da0000;
  top: -2px;
}
.detailbox {
  position: fixed;
  background-color: #fff;
  top: 0px;
  left: 0;
  right: 0;
  bottom: 0px;
}
.closebtn {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 35px;
  z-index: 100;
  background: #da0000;
}
.closebtn img.top-goimg {
  position: absolute;
  left: 5px;
  top: 2px;
}
</style>

<script>
import CryptoJS from "crypto-js";
import details from "../detail/newDetail.vue";
export default {
  props: ["title", "indexpost"],
  components: {
    detailsjl: details
  },
  data() {
    return {
      items:  [
      { title: '新闻标题1', src: this.ImageUrl('img1.jpg'), url:'myLearn',column_name:'党建要闻',publish_date:'2020年9月3日',id:'19'},
      { title: '新闻标题2', src: this.ImageUrl('img2.jpg'), url:'myLearn',column_name:'党建要闻',publish_date:'2020年9月3日',id:'11'},
      { title: '新闻标题3', src: this.ImageUrl('img3.jpg'), url:'myLearn',column_name:'党建要闻',publish_date:'2020年9月3日',id:'199'},
      { title: '新闻标题4', src: this.ImageUrl('img4.jpg'), url:'myLearn',column_name:'党建要闻',publish_date:'2020年9月3日',id:'000'}
                ],
      POST_list: "",
      alllist: "", //文章总数
      listcount: 10, //文章加载数
      last: false,
      infodatas: {
        detailID: 0,
        ifrheight: 0,
        title:"ceshi"
      },
      detail: false
    };
  },
  methods: {
    datalist() {
      var me = this;
      //首页文章列表数据
      var userDATA = localStorage.getItem("userDATA"); //获取用户信息
      var USER = JSON.parse(userDATA); //编译用户信息      
      me.USER_ID = USER.DATA.USER_ID; //在用户信息中获取id
      me.token = localStorage.getItem("token");
      me.mydept = 63;
      me.POST_list =me.showdoc +me.indexpost +"?DEPT_ID=" +me.mydept +"&COLUMN_ID=" +me.depid;
      me.$http({
          method: "post",
          url: me.POST_list,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            token: me.token == undefined ? "" : me.token,
            userid: me.USER_ID == undefined ? "" : me.USER_ID,
            timestamp: Date.now().toString(),
            sign:
              CryptoJS.MD5(
                Date.now().toString() +
                  me.USER_ID +
                  me.token +
                  me.showdoc +
                  me.indexpost
              ) + ""
          }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => { //请求成功
           var tokenkey = ret.headers.map.key // 获取token
            me.takestate(tokenkey,ret.body.CODE)
            me.items = ret.body.DATA.result;
            me.alllist = ret.body.DATA.totalResult;
            if (me.alllist < 10) {
              me.allLoaded = true;
              me.loadingmsg = "已经到底了";
            }
          },
          ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
    },
    showdetail(ID) {
      this.detail = true;
      this.infodatas.detailID = ID;
      this.infodatas.ifrheight = document.getElementById("ifdiv").offsetHeight;
    }, //传数据到详细页窗口
    closebox() {
      this.detail = false;
    }, //关闭窗口
    loadTop() {
      setTimeout(() => {
        this.listcount = 10; //重置条数
      //  this.datalist(); //重新加载数据
        this.loadingmsg = "上拉加载";
        this.allLoaded = false; //启动加载
        this.$refs.loadmore.onTopLoaded();
        this.Msgtxt("刷新成功！")
      }, 2000);
    },
    loadBottom() {
      this.token = localStorage.getItem("token");
      setTimeout(() => {
        var me = this;
        if (me.alllist - me.listcount > 0) {
          me.listcount = me.listcount + 10;
          me.$http({//获取数据
              method: "post",
              url: me.POST_list + "&SHOWCOUNT=" + me.listcount,
              headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                token: me.token == undefined ? "" : me.token,
                userid: me.USER_ID == undefined ? "" : me.USER_ID,
                timestamp: Date.now().toString(),
                sign:CryptoJS.MD5(Date.now().toString() +me.USER_ID +me.token +me.showdoc +me.indexpost) + ""
              }, //新增加
              credientials: false,
              emulateJSON: true
            }).then(ret => {
                //请求成功
                me.items = ret.body.DATA.result;
              },ret => {
                //请求失败
                console.log("服务器请求失败！");
              }
            );
        } else {
          me.allLoaded = true;
          me.loadingmsg = "已经到底了";
        }
        me.$refs.loadmore.onBottomLoaded();
      }, 1000);
    }
  },
  created: function() {
    if(this.$route.params.id=='' ||this.$route.params.id==undefined){
    var pageurl=window.location.href
    var pagenum=pageurl.indexOf('=')
    var pagecode=pageurl.substr(pagenum+1)
    console.log(pagecode)
    this.depid=pagecode
    }else{
      this.depid=this.$route.params.id
    }
   // this.datalist(); //调用加载数据方法
  }
};
</script>