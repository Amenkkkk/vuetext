<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="main-list" >
        <!-- <tabTop :tablise="tablise" v-if="tablise.tabNum>1"></tabTop> -->
        <div class="tab-panels" >
            <div class="main-ul"> 
                <orgaList :itemsOrga="tablise"></orgaList>
            </div>
        </div>
        <!-- <text class="paytips">{{tablise}}</text> -->
        </div>
    </div>
</template>
<style scoped>
.nottabtop{
    top: 100px;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
.paytips{ text-align: center; margin-top:80px; font-size: 25px; color: #777; }
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import orgaLists from '../../components/list/orgaList.vue';
    export default {
        components: {
            'list-header': Header,
            // 'tabTop':tabTop,
            'orgaList': orgaLists,
        },
        data () {
            var me=this;
            return {
                link:'',
                loadinging: false,
                refreshing: false,
                title:me.$route.params.name,
                postResult:'',
                tablise:{
                    colunm_id:'',
                    activeTab: 0,
                    tabNum:1,
                    POST_list:me.$route.params.dataUrl,
                    POST_detail:'/appreelection/findTXById',
                    pj_posturl:'?ELECTION_ID=',
                    dateText:me.$route.params.dateText,
                    textItems: {
                        dateText:me.$route.params.dateText,
                        items:[],
                    },
                },
            }
        },
        methods: {
           
        }
        
    }
        
</script>

