import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/assets/vuedemo/HelloWorld'
import Home from '@/assets/views/Home'
import Orga from '@/assets/views/Orga'
import Study from '@/assets/views/Study'
import My from '@/assets/views/My'
// import picker from '@/text/pickertime'

//登陆注册
import login from '@/assets/login/login.vue'
import forget from '@/assets/login/forget.vue'
import ResetP from '@/assets/login/resetpassword.vue'
import register from '@/assets/login/register.vue'
import Infor from '@/assets/login/Information.vue'

import partyNew from '@/assets/views/home/partyNew' //首页列表页
import newDetail from '@/assets/components/detail/newDetail' //首页详细页
import reviewList from '@/assets/components/list/reviewList' //文章评论页



import joinApply from "@/assets/views/orga/joinApply"; //我的组织-入党申请
import tranRemind from "@/assets/views/orga/tranRemind";  //我的组织 - 支委换届选举，结果公示
import recActivity from "@/assets/views/orga/recActivity";  //我的组织 - 近期活动，往期活动
import prePublic from "@/assets/views/orga/prePublic";  //我的组织 - 党员公示
import posPublic from "@/assets/views/orga/posPublic";  //我的组织 - 正式党员公示

import courseDetail from "@/assets/components/detail/courseDetail";  //在线学习 - 详细页
import onlineClass from "@/assets/views/study/onlineClass";  //在线学习 - 在线课堂（专题）
import courseList from "@/assets/views/study/courseList";  //在线学习 - 在线课堂（文章）
import learnText from "@/assets/views/study/learnText";  //在线学习 - 学习测评
import resPublic from "@/assets/views/study/resPublic";  //在线学习 - 成绩公开
import myLearn from "@/assets/views/study/myLearn";  //在线学习 - 我的学习
import resDetail from "@/assets/components/detail/resDetail";  //在线学习 - 成绩公开详细页

//个人中心
import PersonInfor from '@/assets/views/my/personInfor.vue' //个人中心信息页面
import PartyPay from '@/assets/views/my/PartyPay.vue' //党费缴交
import personList from '@/assets/views/my/personList.vue' //个人中心信息页面
import Setup from '@/assets/views/my/Setup.vue' //个人中心设置页面
import messageList from '@/assets/components/list/messageList.vue' //个人中心 消息中心
import messDetail from '@/assets/components/detail/messDetail.vue' //个人中心 消息中心




Vue.use(Router)

export default new Router({
  routes: [
    { path: '/', component: Home},  //默认登录
    { path: '/HelloWorld', name: 'HelloWorld', component: HelloWorld}, //测试页面
    { path: '/Home', name: 'Home', component: Home},  // 首页
    { path: '/Orga', name: 'Orga', component: Orga},  // 我的组织
    { path: '/Study', name: 'Study', component: Study},  // 在线学习
    { path: '/My', name: 'My', component: My},  //个人中心
    { path: '/partyNew', name: 'partyNew', component: partyNew},  // 首页图标栏目列表页

    { path: '/Login',name:'login', component: login },            // 登录页面
    { path: '/Reset',name:'reset', component: ResetP },           // 重置密码页面
    { path: '/Register',name:'register', component: register },   // 注册页面
    { path: '/Forget',name:'forget', component: forget },         // 忘记密码页面
    { path: '/Infor',name:'infor', component: Infor }, 
    // { path: '/picker',name:'picker', component: picker },             // 注册信息填写页面

    { path: '/partyNew', name: 'partyNew', component: partyNew },
    { path: '/newDetail', name: 'newDetail', component: newDetail },
    { path: '/reviewList', name: 'reviewList', component: reviewList },
    
    { path: '/joinApply', name: 'joinApply', component: joinApply },
    { path: '/tranRemind', name: 'tranRemind', component: tranRemind },
    { path: '/recActivity', name: 'recActivity', component: recActivity },
    { path: '/prePublic', name: 'prePublic', component: prePublic },    
    { path: '/posPublic', name: 'posPublic', component: posPublic }, 

    { path: '/courseDetail', name: 'courseDetail', component: courseDetail },
    { path: '/onlineClass', name: 'onlineClass', component: onlineClass },
    { path: '/courseList', name: 'courseList', component: courseList },    
    { path: '/learnText', name: 'learnText', component: learnText },      
    { path: '/resPublic', name: 'resPublic', component: resPublic },      
    { path: '/myLearn', name: 'myLearn', component: myLearn }, 
    { path: '/resDetail', name: 'resDetail', component: resDetail },  
    
    //个人中心
    { path: '/PersonInfor', name: 'PersonInfor', component: PersonInfor},
    { path: '/PartyPay', name: 'PartyPay', component: PartyPay},
    { path: '/personList', name: 'personList', component: personList},
    { path: '/Setup', name: 'Setup', component: Setup},
    { path: '/messageList', name: 'messageList', component: messageList},
    { path: '/messDetail', name: 'messDetail', component: messDetail},
    
    
        
  ]
})
