<template>
<div  class="wrapper" >
    <div  class="main-li main-page" offset-accuracy="300px">
        <mt-loadmore :top-method="loadTop" :autoFill='autof'  @top-status-change="handleTopChange"  :bottom-method="loadBottom"  @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="textbox">
        <div class="cell-button">
            <div class="newbox">
                <div class="newUl">
                    <!-- {{strItems}}{{POST_actlist}} -->
                    <div class="newLi" v-for="(lisen,i) in strItems" :key='i'>
                        <div class="newtext" @click="showdetail(lisen.ID, myuser)">
                            <!-- <div class="click_zw" ></div> -->
                            <div class="new-title">{{lisen.TITLE}}</div>
                            <div class="qzdy-div">
                                <div class="qzdy_left">
                                    <div class="qzdy_sf" >党员</div>
                                    <div class="qzdy_sf" v-if="lisen.TYPE==1">群众</div>
                                </div>
                                <div class="qzdy_right" >
                                    <div class="qzdy_zt" v-if="lisen.STATUS==0">未开始</div>
                                    <div class="qzdy_zt" v-if="lisen.STATUS==1">进行中</div>
                                    <div class="qzdy_zt" v-if="lisen.STATUS==2">已结束</div>
                                </div>
                            </div>
                            <div class="date-div">
                                <div class="date-icomi">
                                <img class="date-ico-dz" :src="address"/>
                                </div>
                                <div class="new-date">{{lisen.ADDRESS}}</div>
                            </div>
                            <div class="date-div">
                                <div class="date-icomi">
                                <img class="date-ico" :src="acttime"/>
                                </div>
                                <div class="new-date">{{lisen.START_DATE.substr(0,11)}}至{{lisen.END_DATE.substr(0,11)}}</div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
        <div slot="top" class="loadmore-top">
               <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
               <span v-show="topStatus === 'drop'">释放加载</span>
               <span v-show="topStatus === 'loading'">正在加载....</span>
             </div>
             <!--下拉刷新提示-->
        <div slot="bottom" class="loadmore-bottom">
          <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
          <span v-show="bottomStatus === 'loading'">加载中...</span>
          </div>
          <!--上拉加载提示-->
         </mt-loadmore>     
         <nodata-ms v-if="nodata"></nodata-ms>
        <div class="detailbox"  v-if='detail'>  
           <div class="closebtn" @click="closebox()"><!--关闭按钮--></div>
           <detail :infodata='infodatas'></detail>
        </div>
    </div>
</div>
        
</template>
<style scoped>
.main-li {
  width: 100%;
}

.listbottom {
  background-color: #f2f2f2;
  line-height: 70px;
  height: 70px;
  text-align: center;
}
.indicator-text {
  color: #888888;
  font-size: 22px;
  text-align: center;
}
.newUl {
  display: block;
}
.newLi:first-child {
  border-top-color: #ccc;
  border-top-width: 1px;
  border-top-style: solid;
}
.newLi {
  border-bottom-color: #ccc;
  border-bottom-width: 1px;
  border-bottom-style: solid;
  padding: 15px;
  display: flex;
  justify-content: space-between;
  flex-direction: row;
}
.new-imgdiv {
  flex: 1;
}
.new-img {
  height: 150px;
  border: 1px solid #e8e8e8;
}
.newtext {
  flex: 2.5;
  position: relative;
}
.click_zw {
  position: absolute;
  width: 100%;
  height: 300px;
}
.new-title {
  font-size: 16px;
  color: #000;
  margin-bottom: 10px;
}
.new-date {
  font-size: 14px;
  color: #555;
  flex: 14;
  height: 20px;
  line-height: 20px;
}
.date-div {
  display: flex;
  justify-content: space-between;
  flex-direction: row;
}
.qzdy-div {
  display: flex;
  justify-content: space-between;
  flex-direction: row;
  margin-bottom: 10px;
}
.qzdy_left {
  flex: 2;
  display: flex;
  flex-direction: row;
}
.qzdy_sf {
  margin-right: 10px;
  width: 40px;
  height: 20px;
  border-radius: 10px;
  line-height: 20px;
  border: 1px solid #da0000;
  font-size: 12px;
  color: #da0000;
  text-align: center;
}
.qzdy_right {
  flex: 1;
}
.qzdy_zt {
  font-size: 14px;
  text-align: center;
  color: #fda502;
}
.date-icomi {
  flex: 1;
  /* align-items:center;
    text-align:center; */
}
.date-ico-dz {
  width: 20px;
  height: 20px;
}
.date-ico {
  width: 20px;
  height: 20px;
}

.detailbox {
  position: fixed;
  background-color: #fff;
  top: 0px;
  left: 0;
  right: 0;
  bottom: 0px;
}
.closebtn {
  position: absolute;
  top: 0;
  left: 0;
  width: 50px;
  height: 50px;
  z-index: 100;
}
</style>

<script>
import detail from "../detail/activeDetail.vue";
import CryptoJS from "crypto-js";
import nodatams from "../../components/nodatams.vue";
export default {
  props: ["items"],
  components: {
    detail: detail,    
    "nodata-ms":nodatams
  },
  data() {
    return {
      text: "",
      loadinging: false,
      refreshing: false,
      nodata:false,
      postResult: "",
      alllist: "", //文章总数
      listcount: 10, //文章加载数
      last: false,
      showLoading: "hide",
      address: this.ImageUrl("icon/mipmap-xhdpi/activity_address.png"),
      acttime: this.ImageUrl("icon/mipmap-xhdpi/activity_time.png"),
      mydept: "",
      strItems: [{ID:'2454',TITLE:'测试标题',TYPE:'1',STATUS:'2',ADDRESS:'花城大道83号',START_DATE:'2020年9月9日',END_DATE:'2020年9月9日'}],
      detail: false,
      infodatas: {
        detailID: "",
        detailUID: ""
      },
      token: "",
      timestamp: Date.now().toString()
    };
  },
  created: function() {
  //   this.datalist(); //调用加载数据方法  
  },
  methods: {
    datalist() {
      var me = this;  
      me.token = localStorage.getItem("token");
      me.POST_actlist = me.showdoc + me.items.linku + "?"+me.items.linkey+"&USER_ID=" + me.myuser;
      me.$http({
          method: "post",
          url: me.POST_actlist,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            token: me.token == undefined ? "" : me.token,
            userid: me.USER_ID == undefined ? "" : me.USER_ID,
            timestamp: me.timestamp,
            sign: CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + "/zhdj"+me.items.linku ) + ""
          }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {           
            //请求成功
            var tokenkey = ret.headers.map.key; // 获取token
            me.takestate(tokenkey,ret.body.CODE)
            me.strItems = ret.body.DATA.result;
            me.alllist = ret.body.DATA.totalResult;       
            if(me.alllist==0){
                 me.nodata=true
                 me.allLoaded = true;
                 me.loadingmsg='' 
            }else if(me.alllist<10&&me.alllist!=0){
                 me.allLoaded = true;
                 me.loadingmsg='' 
            } 
          },ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
    },
    showdetail(ID, UID) {
      this.detail = true;
      this.infodatas = {
        detailID: ID,
        detailUID: UID
      };
    }, //传数据到详细页窗口
    closebox() {
      this.detail = false;
    }, //关闭窗口 
    loadTop() {
              setTimeout(() => {
                this.listcount=10 //重置条数
              //  this.datalist()  //重新加载数据
                this.loadingmsg='上拉加载'
                this.allLoaded = false;  //启动加载
                this.$refs.loadmore.onTopLoaded();
                this.Msgtxt("刷新成功！")     
               }, 2000);
            },
   loadBottom(){
       this.token=localStorage.getItem("token")
                 setTimeout(() => {
                      var me=this
                      if(me.alllist-me.listcount > 0){     
                       me.listcount=me.listcount+10
                       me.$http({  //获取数据
                         method:"post",
                         url: me.POST_actlist+'&SHOWCOUNT='+ me.listcount,
                         headers: {
                           "Content-Type": "application/x-www-form-urlencoded",
                           token: me.token == undefined ? "" : me.token,
                           userid: me.USER_ID == undefined ? "" : me.USER_ID,
                           timestamp: me.timestamp,
                           sign: CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + "/zhdj/appPartyBranchActivity/activityList" ) + ""
                         }, //新增加
                         credientials:false, 
                         emulateJSON: true     
                       }).then(res=>{  //请求成功
                            me.strItems = res.body.DATA.result;
                       }, res => { //请求失败
                          console.log('服务器请求失败！')
                         }
                       ); 
                    }else{
                      me.allLoaded = true;
                      me.loadingmsg='已经到底了'                     
                    }
                     me.$refs.loadmore.onBottomLoaded()
      }, 1000);
   }
  }
};
</script>