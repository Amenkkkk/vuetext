<template>
<div class="main-li" >
    <div  class="main-page" offset-accuracy="300px">   
    <mt-loadmore :top-method="loadTop" :autoFill='autof'  @top-status-change="handleTopChange"  :bottom-method="loadBottom"  @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="textbox">
        <div class="cell-button">
            <div class="newbox">
                <div class="newUl">
                    <div class="newLi" v-for="(lisen,i) in dygsitem" :key='i'>
                        <div class="newtext"  @click="showdetail(Detailpost, lisen.FOLW_ID)">
                            <div class="new-title" >{{lisen.NAME}}</div>
                            <div class="date-div">
                                <div class="date-icomi">
                                <img class="date-ico" :src="ImageUrl('/icon/status_shenhe.png')"/>
                                </div>
                                <div class="new-date" >{{itemsOrga.dateText}}:{{lisen.CREATE_TIME.substr(0,11)}}</div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
        <div slot="top" class="loadmore-top">
            <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
            <span v-show="topStatus === 'drop'">释放加载</span>
            <span v-show="topStatus === 'loading'">正在加载....</span>
             </div>
             <!--下拉刷新提示-->
        <div slot="bottom" class="loadmore-bottom">
            <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
            <span v-show="bottomStatus === 'loading'">加载中...</span>
         </div><!--上拉加载提示-->
        </mt-loadmore>
        <div class="detailbox"  v-if='detail'>  
           <div class="closebtn" @click="closebox()"><!--关闭按钮--></div>
           <detail-1  v-if="type==1" :infodata='infodatas'></detail-1>
           <detail-2  v-if="type==2" :infodata='infodatas'></detail-2>
        </div>
    </div>
</div>
        
</template>
<style scoped>

.main-li{
    width: 100%;
}
.refresh {
    width: 100%;
    height:90px;
    display: -ms-flex;
    display: -webkit-flex;
    display: flex;
    -ms-flex-align: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    align-items: center;
  }
.refont{
    font-size: 30px;
    /* height: 100px; margin-top: -100px; */
} 
.indicator{ width:50px; height:50px; margin-top:20px; }
.loading-bg{width: 30px; position: fixed; z-index: 100;
    height: 30px;}
.loading {
    width: 750;
    display: -ms-flex;
    display: -webkit-flex;
    display: flex;
    -ms-flex-align: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    align-items: center;
  }
  .listbottom{ background-color: #f2f2f2; line-height: 70px; height: 70px; text-align: center}
  .indicator-text {
    color: #888888;
    font-size: 22px;
    text-align: center;
  }
.newUl{display: block;}
.newLi:first-child{border-top-color:#ccc; border-top-width: 1px;border-top-style: solid;}
.newLi{ border-bottom-color: #ccc;border-bottom-width: 1px;border-bottom-style: solid; padding: 15px;display: flex; justify-content:space-between;  flex-direction:row;}
.new-imgdiv{flex: 1; }
.new-img{ height: 150px;border: 1px solid #e8e8e8;}
.newtext{ flex: 2.5; }
.new-title{
    font-size: 16px;
    color: #000;
    margin-bottom: 10px;
}
.new-date{
    font-size: 14px;
    color: #555;
    flex:14;
    height:20px;
    padding-left: 10px;
    line-height: 20px;
}
.date-div{
    display: flex; 
}
.date-icomi{
    flex:1;
}
.date-ico{
    width:20px;
    height:20px;
}
.detailbox{ position: fixed; background-color:#fff; top:0px;left: 0;right: 0;bottom:0px;}
.closebtn{position: absolute ; top: 0;left: 0;width:200px; height: 100px; z-index: 100;}
</style>

<script>
    import detail1 from '../detail/dygsDetail.vue'
    import detail2 from '../detail/zsdygsDetail.vue'
    import CryptoJS from "crypto-js";     
    export default {
        props:["itemsOrga"],
        components: {
            'detail-1': detail1,
            'detail-2': detail2,
        },
        data () {
            var me=this; 
            return {
                loadinging: false,
                refreshing: false,
                postResult:'',
                alllist:'',//文章总数
                listcount:10,//文章加载数
                last:false,
                showLoading: 'hide',
                post_dygs:'',
                dygsitem:[{FOLW_ID:'123',NAME:'张三',CREATE_TIME:'2020年9月14日'}],
                Detailpost:me.itemsOrga.detailpost,
                kk:'22',
                detail:false,
                infodatas:{
                    detailURL: '',
                    detailID:'',
                },
            }
        },
        created: function() {
          //  this.datalist() 
        },
        methods: {
            datalist(){
                var me = this;
                me.token=localStorage.getItem("token")
                me.post_dygs = me.showdoc+me.itemsOrga.post_dygs+me.itemsOrga.dataUrl_type+'&DEPT_ID='+me.mydept
            //党员公示列表数据
            me
                .$http({
                method: "post",
                url: me.post_dygs,
                headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                    "token": me.token == undefined ? '' : me.token,
                    "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                    "timestamp": me.timestamp,
                    "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj'+me.itemsOrga.post_dygs)+''
                }, //新增加
                credientials: false,
                emulateJSON: true
                }).then(ret => {
                    //请求成功
                var tokenkey = ret.headers.map.key // 获取token
                    me.takestate(tokenkey,ret.body.CODE)
                    me.dygsitem = ret.body.DATA.result;
                    me.alllist = ret.body.DATA.totalResult;
                    if(me.alllist<10){
                             me.allLoaded = true;
                             me.loadingmsg='' 
                          }
                },ret => {
                    //请求失败
                    console.log("服务器请求失败！");
                }
                );
            },     
            showdetail(URL,ID){
                this.detail=true
                if(this.itemsOrga.detailName=='dygsDetail'){
                    this.type=1
                }else if(this.itemsOrga.detailName=='zsdygsDetail'){
                    this.type=2
                }
                 this.infodatas={
                    detailURL:URL,
                    detailID: ID }
            },//传数据到详细页窗口
            closebox(){
               this.detail=false
            },//关闭窗口
            loadTop() {
              setTimeout(() => {
                this.listcount = 10; //重置条数
             //   this.datalist(); //重新加载数据
                this.loadingmsg = "上拉加载";
                this.allLoaded = false; //启动加载
                this.$refs.loadmore.onTopLoaded();
                this.Msgtxt("刷新成功！")
              }, 2000);
    },
    loadBottom(){
       this.token=localStorage.getItem("token")
                 setTimeout(() => {
                      var me=this
                      if(me.alllist-me.listcount > 0){     
                       me.listcount=me.listcount+10
                       me.$http({  //获取数据
                         method:"post",
                         url: me.post_dygs+'&SHOWCOUNT='+ me.listcount,
                         headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                             "token": me.token == undefined ? '' : me.token,
                             "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                             "timestamp": me.timestamp,
                             "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj'+me.itemsOrga.post_dygs)+''
                }, //新增加
                         credientials:false, 
                         emulateJSON: true     
                       }).then(res=>{  //请求成功
                           me.dygsitem = res.body.DATA.result;
                       }, res => { //请求失败
                          console.log('服务器请求失败！')
                         }
                       ); 
                    }else{
                      me.allLoaded = true;
                      me.loadingmsg='已经到底了'                     
                    }
                     me.$refs.loadmore.onBottomLoaded()
      }, 1000);
   }
        }
    }
</script>