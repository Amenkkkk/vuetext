<template>
  <div class="wrapper">
    <home-header :title="title"></home-header>
    <div>
        <div class="cell-button orga">
            <!-- <text>{{items1}}</text> -->
        
            <!-- <item :items="items2"></item>
            <item :items="items3"></item>
            <item :items="items4"></item> -->
            <item :items="items5"></item>
            <!-- <item :items="items6"></item> -->
            <item :items="items7"></item>
            <!-- <item :items="items8"></item> -->
            <!-- <item :items="items9"></item> -->
            <item :items="items1"></item>
        </div>
    </div>
    <tabNav :active="active"/>
  </div>
</template>
<style scoped>
.cell-button.orga{
  background-color: #f2f2f2;
  position: fixed;
  top: 35px;
  left: 0;
  width: 100%;
  bottom: 63px;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;

}
.main-list{
        position: fixed;
        top: 100px;
        left: 0;
        right: 0;
        /*margin-top: 167px;*/
        /*margin-bottom: 90px;*/
    }
</style>
<script>
    import Header from '../components/Header.vue';
    import item from '../components/item.vue';
    import tabNav from '../components/tabNav.vue';
    export default {
        components: {
            'home-header': Header,
            'item':item,
            'tabNav':tabNav,
        },
        data () {
            var me=this;
            return {
                loadinging: false,
                refreshing: false,
                active:2,
                title:'我的组织',
                items1:{
                    title:'我要入党',
                    itemlist:[
                        { title:'入党申请', img:me.ImageUrl('/icon/rdsq.png'),url:'joinApply',
                          dataUrl:'/apprdflow/rdflowCurrentStage',
                          dateText:'',
                        },
                        { title:'预备党员公示', 
                          img:me.ImageUrl('/icon/ybdygs.png'),
                          url:'prePublic',
                          dataUrl:'/apprdflow/getDygsList',
                          dateText:'公示时间'
                        },
                        { title:'转正党员公示', img:me.ImageUrl('/icon/dygs.png'), url:'posPublic',
                          dataUrl:'/apprdflow/getDygsList',
                          dateText:'公示时间'
                        },
                    ]
                },
                // items2:{
                //     title:'三会一课',
                //     itemlist:[
                //         { title:'会议精华', img:'/icon/hyjh.png',url:'/'},
                //         { title:'会议记录', img:'/icon/hyjl.png', url:'/'},
                //         { title:'', img:'', url:''},
                //         { title:'', img:'', url:''}
                //     ]
                // },
                // items3:{
                //     title:'选拔任用',
                //     itemlist:[
                //         { title:'选拔任用', img:'/icon/xbry.png',url:'/'},
                //         { title:'通报表彰', img:'/icon/tbbz.png', url:'/'},
                //         { title:'', img:'', url:''},
                //         { title:'', img:'', url:''}
                //     ]
                // }, 
                // items4:{
                //     title:'党组织关系转接',
                //     itemlist:[
                //         { title:'我要转入', img:'/icon/wyzr.png',url:'/'},
                //         { title:'我要转出', img:'/icon/wyzc.png', url:'/'},
                //         { title:'', img:'', url:''},
                //         { title:'', img:'', url:''}
                //     ]
                // },
                items5:{
                    title:'基层党组织换届选举',
                    itemlist:[
                        { title:'支委换届选举',
                          img:me.ImageUrl('/icon/zwhjtx.png'),
                          url:'tranRemind',
                          dataUrl:'/appreelection/findTXByDeptId',
                          dateText:'选举时间'
                        },
                        { title:'结果公示', 
                          img:me.ImageUrl('/icon/jggs.png'),
                           url:'tranRemind',
                           dataUrl:'/appreelection/findGSByDeptId',
                           dateText:'公示时间'
                        },
                    ]
                },
                // items6:{
                //     title:'先锋模范',
                //     itemlist:[
                //         { title:'创先争优', img:'/icon/cxzy.png',url:'/'},
                //         { title:'先进典型', img:'/icon/xjdx.png', url:'/'},
                //         { title:'', img:'', url:''},
                //         { title:'', img:'', url:''}
                //     ]
                // },
                items7:{
                    title:'支部活动',
                    itemlist:[
                        { title:'近期活动', img:this.ImageUrl ('icon/jqhd.png'),url:'recActivity',
                          dataUrl:'/appPartyBranchActivity/activityList',actType:'TYPE=JQ',
                        },
                         { title:'往期活动', img:this.ImageUrl ('icon/wqhd.png'),url:'recActivity',
                          dataUrl:'/appPartyBranchActivity/activityList',actType:'TYPE=WQ',
                        },
                    ]
                },
                items8:{
                    title:'党委',
                    itemlist:[
                        { title:'三重一大', img:'/icon/szyd.png',url:'/'},
                    ]
                },

                // // 首页有党员心声，此处不要，且列表样式与首页的党员心声不一样
                // items9:{
                //     title:'交流互动',
                //     itemlist:[
                //         { title:'党员心声', img:this.ImageUrl ('icon/dyxs.png'),url:'applyVoice',
                //           dataUrl:'/zhdj/apphtml5index/appUserPostList?NAME_EN=DYXS',dateText:'发表时间'
                //         },
                //     ]
                // }
            }
        },
    }
 </script>