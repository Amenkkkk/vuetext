<template>
<div class="topnav">
        <div class="toptitle">{{title}}</div>
    <div :class="['message']"  @click="jumpTo('messageList')">
        <img class="msg-img" resize="contain" :src="this.ImageUrl('icon/mipmap-xhdpi/ic_msg.png')"/>
        <!-- <div class="iconfont2 magicon">&#xe901;</div> -->
        <div class="mass_number" v-if="mass.ZS>0">{{masszs}}</div>
    </div>
</div>
</template>
<style scoped>

.topnav{ height:35px;width:100%; background-color: #da0000; display: flex;justify-content:center;align-items: center; position: fixed; z-index: 100000;}
.toptitle{color: #fff; font-size: 16px; }
.message{ position: absolute;top: 0;right: 0;}
.magicon{color: #fff; width: 30px;height:30px ;line-height: 100px; margin-right:10px;}
.msg-img{ width: 23px; margin-right: 15px; margin-top: 8px}
.mass_number{
    position: absolute;
     height: 20px;line-height: 22px;
    background-color: #fff;
    top: 6px;
    right: 6px;
    border-radius: 14px;
    color: #da0000;
    font-size: 10px;width: 20px;text-align: center;
}
</style>
<script>
import CryptoJS from "crypto-js";
    export default {
        props:["title"],
        data () {
            return {
                POST_URL:'',
                postResult:'',
                mass:[],
                masszs:'9+',
            }
        },
        state:{//state
        show:0,
        },
        created: function() {
             var me = this;
             me.mass.ZS='22'
            // me.token=localStorage.getItem("token")
            // me.POST_URL = me.showdoc+'/appmessage/getwdzs?USER_ID='+ me.myuser;
            // me.$http({
            // method: "post",
            // url: me.POST_URL,
            // headers: { "Content-Type": "application/x-www-form-urlencoded" ,
            //             "token": me.token == undefined ? '' : me.token,
            //             "userid": me.USER_ID == undefined ? '' : me.USER_ID,
            //             "timestamp": me.timestamp,
            //             "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appmessage/getwdzs')+''
            //         }, //新增加
            // credientials: false,
            // emulateJSON: true
            // })
            // .then(ret => {//请求成功
            //     var tokenkey = ret.headers.map.key // 获取token
            //     me.takestate(tokenkey,ret.body.CODE)
            //     me.mass=ret.data.DATA;
            //     me.masszs=ret.data.DATA.ZS;
            //     if(me.masszs>9){
            //                 me.masszs='9+'
            //             }
            //     localStorage.setItem("msgnum",ret.data.DATA.ZS) //储存更新未读消息
            // },ret => {
            //     //请求失败
            //     console.log("服务器请求失败！");
            //   }
            // );
        },        
    mutations:{
    },
        methods: {
        }
    }
</script>