<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="iframe_div" v-for="(style_detail, i) in style_detail" :key="i">
            <!-- <iframe class="webview_zxcp" :src="POST_link"></iframe> -->
            <div class="detialbox">
                <!-- {{POST_link}} -->
                <div class="new-title" id="title"><!-- 文章标题 -->{{style_detail.TITLE}}</div>
                <div class="new-info">
                        <!-- <span id='time'>{{style_detail.CREATE_TIME.substr(0,11)}}</span> -->
                        <span id='time'>{{style_detail.CREATE_TIME}}</span>
                </div>
                <div class="new-profile" id="profile">{{style_detail.PROFILE}}</div>
                <div class="new-content" id='contenttxt' v-html="style_detail.CONTENT"><!-- 文章内容 --></div>
                <!-- <div id="mmm">gggggg</div> -->
            </div>
            <div class="video" v-if="style_detail.TYPE==2">
                <video id="new-video" :src="style_detail.VURL" controls="controls" poster="" width="100%">
                无法连接服务器！
                </video>
                <div class="v-title" id="v-title"></div>
            </div>
        </div>
    </div>
</template>
<style scoped>
.iframe_div{
    position: fixed;
    top: 35px;
    bottom: 0;
    left: 0;
    right: 0;
    overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.webview_zxcp{
    width: 100%;
    height: 100%;
    border: none;
}
     .detialbox{ margin:10px 15px;padding-top:20px; padding-bottom: 20px;margin:0.625em 0.9375em;padding-top:1.250em; padding-bottom: 1.250em;}
     .new-title{ padding:0 20px 0 28px; font-size: 18px;color: #4b4b4d;padding:0 1.250em 0.625em 1.75em; text-align: center;}
     .new-info{ display: flex; flex-flow: nowrap; justify-content: center;padding-top: 5px;}
     .new-info span{ color: #a3a3ac; font-size: 13px; padding:0 5px;}
     .newline{border-right:1px solid #dbdbde;}
     .new-profile{padding:0 20px 0 28px;padding:0.625em 1.250em 0 1.75em;color:#666}
     .new-content{ padding-top:10px;}
     .new-content p{ line-height: 22px; color: #4b4b4d; }
     .new-content img{ margin:0 auto;display: block;padding-top: 10px; padding-bottom: 15px; width:100% !important;}
     .v-title{line-height: 50px;  font-size: 18px;color: #4b4b4d; padding:0 10px; border-bottom: 5px solid #f2f2f2; }
</style>
<style>
.new-content *{max-width: 100% ;}
</style>

<script>
    import listHeader from '../listHeader.vue'
    import CryptoJS from "crypto-js";    
    export default {
        props:["infodata"],
        components: {
            'list-header': listHeader,
        },
        data () {
            var me = this;
            return {  
                loadinging: false,
                refreshing: false,
                title: '',
               // POST_URL: me.serverUrl('appocourses/CoursesDetailed?COURSES_ID='+me.$route.params.id),
                POST_link:'',
                inner: '',
                style_detail:[{TITLE:'学习课程视频文章测试',CREATE_TIME:'2020年9月15日',PROFILE:'文章短标题',CONTENT:'文章内容测试111111',TYPE:'2',VURL:'test',}],
            }
        },
        created: function() {
        //    var a=document.getElementById("mmm").innerText;
        //             console.log(a)
                    
        //             document.getElementById("mmm").innerText="3333333"

            // if(this.infodata=='' || this.infodata==undefined){
            //  this.POST_link=this.showdoc + '/appocourses/CoursesDetailed?COURSES_ID=' + this.$route.params.id+'&USER_ID='+this.myuser
            // }else{
            //  this.POST_link=this.showdoc + '/appocourses/CoursesDetailed?COURSES_ID=' + this.infodata.detailID+'&USER_ID='+this.myuser
            // }
            // var me=this;
            //  me.token=localStorage.getItem("token")
            //  me.$http({
            //     method: "post",
            //     url: me.POST_link,
            //     headers: { "Content-Type": "application/x-www-form-urlencoded" ,
            //                 "token": me.token == undefined ? '' : me.token,
            //                 "userid": me.USER_ID == undefined ? '' : me.USER_ID,
            //                 "timestamp": me.timestamp,
            //                 "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appocourses/CoursesDetailed')+''
            //             }, //新增加
            //     credientials: false,
            //     emulateJSON: true
            //     })
            //     .then(ret => {//请求成功
            //         var tokenkey = ret.headers.map.key // 获取token
            //         me.takestate(tokenkey,ret.body.CODE)
            //         me.style_detail = ret.body.DATA;                
            //         // document.getElementsByClassName("mmm").innerHTML(me.style_detail.CONTENT)
            //     },ret => {    //请求失败
            //         console.log("服务器请求失败！");
            //     }
            //     );
                 
        },
         methods: { 
             
        },
        
    }
        
</script>
