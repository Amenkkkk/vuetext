<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="main-page">
        <div class="tab-panels"> 
            <div class="new_h1">{{$route.params.title}}</div>
            <div class="deta_xin">
                <div class="deta_xinli">时间：{{$route.params.receive_date}}</div>
            </div>
            <div>
                <div class="contant_xx">
                    {{$route.params.content}}
                </div>
            </div>
        </div>
    </div>
    </div>
</template>
<style scoped>
div.nottablist{
    top: 100px;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
.new_h1{
    width: 100%;
    padding-top: 30px;
    padding-bottom: 10px;
    font-size: 16px;
    color: #000;
    text-align: center;
}
.deta_xin{
    text-align: center;
}
.deta_xinli{
    margin-bottom: 10px;
    font-size: 14px;
}
.new_h2{
    width: 100%;
    text-align: center;
    font-size: 14px;
}
.contant_xx{
    width: 100%;
    box-sizing: border-box;
    padding: 0 15px;
}
</style>

<script>
    import listHeader from '../listHeader.vue'
    import CryptoJS from "crypto-js";
    export default {
        components: {
            'list-header': listHeader,
        },  
         data () {
             return{
             title:'消息详情'
             }
         },
         created: function() {
        }      
    }
        
</script>
