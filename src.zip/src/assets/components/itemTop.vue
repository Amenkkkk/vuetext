<template>
<div class="itembox">
    <div class="itemUl">
    <div class="itemLi" v-for="(topic,i) in topics" :key="i">
       <div @click="jumpTo(topic.url,{id: 0})" class="click-div">
            <img class="item-img" resize="contain" :src="topic.img"/>
            <div class="item-name">{{topic.title}}</div>
       </div>
    </div>
    </div>
</div>
</template>
<style scoped>
.itembox{display: block;}
.itemUl{ width:100%; overflow: hidden}
.itemLi{ text-align: center;float: left;width: 25%;}
.item-img{ width:40px; height: 40px; margin-bottom:10px; margin-top:10px;}
.itemLi p{ text-align: center;}

</style>
<script>
    // var navigator = weex.requireModule('navigator')
    export default {
        props:["topics"],
        data () {
            return {
                
            }
        },
        methods: {
        }
    }
</script>