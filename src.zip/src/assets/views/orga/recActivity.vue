<template>
    <div class="wrapper">
         <list-header :title="title"></list-header>
        <!-- <tabTop :tablise="tablise" v-if="tablise.tabNum>1"></tabTop> -->
        <div class="tab-panels" >
            <div class="main-ul"> 
                <activeList :items="POST_list"></activeList>
            </div>
        </div>
        <!-- <text>{{tablise.textItems.items}}</text> -->
    </div>
</template>
<style scoped>
.tab-panels{
    position: fixed;
    width: 750px;
    top: 200px;
    bottom: 0px;
    left: 0;
    right: 0;
    /* transition: left 0.2s ease-in-out; */
}
.nottabtop{
    top: 100px;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    // import tabTop from '../../components/tabTop.vue';
    import activeList from '../../components/list/activeList.vue';
    export default {
        components: {
            'list-header': Header,
            // 'tabTop':tabTop,
            'activeList': activeList,
        },
        data () {
            var me=this;
            return {
                loadinging: false,
                refreshing: false,
                title:me.$route.params.name,
                postResult:'',
                POST_list:{ 
                    linku:me.$route.params.dataUrl,
                    linkey:me.$route.params.dateType,
                           },
                // POST_list:me.$route.params.dateType,
                tablise:{
                    colunm_id:'',
                    activeTab: 0,
                    tabs: [],
                    tabNum:1,
                    textItems: {
                        dateText:me.$route.params.dateText,
                    },
                },
            }
        },
        methods: {
        },
        created(){
        }
    }
        
</script>

