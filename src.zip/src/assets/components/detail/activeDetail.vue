<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="iframe_div">
            <!-- <div class="">{{act_detail}}{{POST_actlist}}</div> -->
            <div class="activebox" v-for="(act_detail,i) in act_detail" :key='i'> 
                <div class="new_h1" id='title'>{{act_detail.TITLE}}</div>        
                <div class="date-div depname">
                    <img class="date-ico-dz" :src="ImageUrl('icon/mipmap-xhdpi/activity_sponsor.png')"/>
                    <div class="new-date" id='department'>主办方：{{act_detail.DEPARTMENT_NAME}}</div>
                </div>
                <div class="act_zt">
                    <div class="date-div">
                        <img class="date-ico-dz" :src="ImageUrl('icon/mipmap-xhdpi/activity_address.png')"/>
                        <div class="new-date" id='address' ><!-- 地址 -->{{act_detail.ADDRESS}}</div>
                    </div>
                    <div class="date-div">
                        <img class="date-ico-dz" :src="ImageUrl('icon/mipmap-xhdpi/activity_time.png')"/>
                        <div class="new-date" id='time'><!-- 时间 -->{{act_detail.START_DATE.substr(0,11)}}至{{act_detail.END_DATE.substr(0,11)}}</div>
                    </div>
                    <div class="date-div">
                        <img class="date-ico-dz" :src="ImageUrl('icon/mipmap-xhdpi/activity_people.png')"/>
                        <div class="new-date" id='people'>参与人数：{{act_detail.JOIN_PEOPLES}}人</div>
                    </div>
                    <div class="date-div">
                        <img class="date-ico-dz" :src="ImageUrl('icon/mipmap-xhdpi/activity_qunti.png')"/>
                        <div class="new-date qzdy-main">
                            <div class="qzdy_bz">受众群众：</div>
                            <div class="qzdy_sf" id='type1' v-if="act_detail.TYPE==1">群众</div>
                            <div class="qzdy_sf" id='type2' v-if="act_detail.TYPE==2">党员</div>
                        </div>
                    </div>
                </div>
                <div class="date-div zt_main">
                    <div class="join_pf">
                        <img class="date-ico-dz" :src="ImageUrl('icon/ic_join.png')"/>
                        <div class="new-date" id='join'>
                            参加状态：<span v-if="act_detail.IS_JOIN==0">未参加</span><span v-if="act_detail.IS_JOIN==1">参加</span>
                        </div>
                    </div>
                    <div class="join_pf">
                        <img class="date-ico-dz" :src="ImageUrl('icon/ic_finish.png')"/>
                        <div class="new-date" id="complate">完成状态：<span v-if="act_detail.IS_COMPLATE==0">未完成</span><span v-if="act_detail.IS_COMPLATE==1">完成</span></div>
                    </div>
                </div>
                <div class="hdjj_main">
                    <div class="hdjj_top">
                        <div class="hdjj_bt">活动简介</div>
                        <div class="hdzt_text" id="status" v-if="act_detail.STATUS==0">活动未开始</div>
                        <div class="hdzt_text" id="status" v-if="act_detail.STATUS==1">活动进行中</div>
                        <div class="hdzt_text" id="status" v-if="act_detail.STATUS==2">活动已结束</div>
                    </div>
                    <!-- <div id="contenttxt" >
                        {{act_detail.CONTENT}}
                    </div> -->
                    <div v-html="act_detail.CONTENT"> </div>
                </div>
            </div>
            <!-- <iframe class="webview_zxcp" :src="POST_URL"></iframe> -->
        </div>
    </div>
</template>
<style scoped>
.iframe_div {
  position: fixed;
  width: 100%;
  top: 35px;
  bottom: 0;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.webview_zxcp {
  width: 100%;
  height: 100%;
  border: none;
}
.new_h1{ text-align: center;padding: 15px;}
.deta_xin {
  justify-content: center;
  flex-direction: row;
  align-items: center;
}
.date-div {
  display: flex;
  justify-content: space-between;
  flex-direction: row;
  padding-left: 20px;
  padding-right: 20px;
  padding-top: 10px;
}
.depname {
  border-top: #f2f2f2 solid 6px;
  border-bottom: #f2f2f2 1px solid;
  padding-top: 11px;
  padding-bottom: 10px;
}
.qzdy_sf {
  margin-right: 10px;
  line-height: 16px;
  height: 16px;
  font-size: 12px;
  color: #da0000;
  text-align: center;
  border: solid 1px #da0000;
  border-radius: 10px;
  padding: 0 7px;
  display: flex;
  align-items: center;
  text-align: center;
}
.date-ico-dz {
  width: 20px;
  height: 20px;
  padding-right: 10px;
}
.date-ico {
  width: 32px;
  height: 32px;
  margin-top: 2px;
}
.new-date {
  font-size: 14px;
  color: #555;
  flex: 13;
  line-height: 22px;
}
.join_pf {
  flex: 1;
  display: flex;
  justify-content: space-between;
  flex-direction: row;
}
.qzdy-main {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.cjzk,
.qzdy_bz {
  font-size: 14px;
  color: #555;
}
.zt_main {
  border-top: 6px solid #f2f2f2;
  border-bottom: 6px #f2f2f2 solid;
  padding-top: 10px;
  padding-bottom: 10px;
}
.act_zt {
  padding-top: 0px;
  padding-bottom: 10px;
}
.hdjj_main {
  padding-left: 20px;
  padding-right: 20px;
  padding-top: 10px;
  padding-bottom: 10px;
}
.hdjj_top {
  display: flex;
  justify-content: space-between;
  flex-direction: row;
  padding-top: 3px;
  padding-bottom: 10px;
  border-bottom: 1px solid #d4dee0;
}
.hdjj_bt {
  flex: 1;
  color: rgb(31, 109, 255);
  font-weight: bold;
  font-size: 16px;
}
.hdzt_text {
  flex: 1;
  color: #ffbb00;
  font-size: 14px;
  text-align: right;
}
.hide {
  display: none;
}
#contenttxt {
  margin: 10px;
}
</style>

<script>
import listHeader from "../listHeader.vue";
import CryptoJS from "crypto-js";
export default {
  props: ["infodata"],
  components: {
    "list-header": listHeader
  },
  data() {
    var me = this;
    return {
      title: "",
      token: "",
      timestamp: Date.now().toString(),
      act_detail: [{TITLE:'测试标题',DEPARTMENT_NAME:"政治部",ADDRESS:'花城大道83号',START_DATE:'2020年9月1日',END_DATE:'2020年9月9日',JOIN_PEOPLES:'25',TYPE:'1',IS_JOIN:'0',IS_COMPLATE:'0',STATUS:'0',CONTENT:'测试文章写点什么看看。。'}],
      POST_actlist: ""
    };
  },
  created: function() {
    // this.POST_URL=this.linkdoc+'/zhdjweb/detail/Activedetail.html?'+ this.showdoc + '/appPartyBranchActivity/activityDetail?USER_ID='+this.infodata.detailUID+'&ACTIVITY_ID=' + this.infodata.detailID
  //  this.datalist();
  },
  methods: {
    datalist() {
      var me = this;
      me.token = localStorage.getItem("token");
      me.POST_actlist =
        me.showdoc +
        "/appPartyBranchActivity/activityDetail?USER_ID=" +
        me.infodata.detailUID +
        "&ACTIVITY_ID=" +
        me.infodata.detailID;
      me.$http({
          method: "post",
          url: me.POST_actlist,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            token: me.token == undefined ? "" : me.token,
            userid: me.USER_ID == undefined ? "" : me.USER_ID,
            timestamp: me.timestamp,
            sign:
              CryptoJS.MD5(
                me.timestamp +
                  me.USER_ID +
                  me.token +
                  "/zhdj/appPartyBranchActivity/activityDetail"
              ) + ""
          }, //新增加
          credientials: false,
          emulateJSON: true
        }).then(ret => {
            //请求成功
            var tokenkey = ret.headers.map.key; // 获取token
            me.takestate(tokenkey,ret.body.CODE)
            me.act_detail = ret.body.DATA;
          },ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
    }
  }
};
</script>
