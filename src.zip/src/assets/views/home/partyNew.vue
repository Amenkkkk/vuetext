<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <!-- <text>{{tablise.textItems.items1}}</text> -->
        <div class="tablist_main">
            <div class="main-ul" > 
                <tabList :indexpost="indexpost"></tabList>
            </div>
        </div>
        <!-- <text>{{tablise}}</text> -->
    </div>
</template>
<style>
/* .tablist_main{
    position: fixed;
    bottom: 0;
    top: 50px;
    overflow-y: scroll;
    width: 100%;
} */
</style>

<script>
import Header from "../../components/listHeader.vue";
import tabList from "../../components/list/tabList.vue";
export default {
  components: {
    "list-header": Header,
    tabList: tabList
  },
  data() {
    var me = this;
    return {
      title: me.$route.params.name,
      indexpost: "/appindex/articleListByColumnId",
      postResult: "",
      tablise: {
        POST_Tablist: "测试",
        colunm_id: "",
        activeTab: 0,
        tabNum: 1,
        tabs: [],
        textItems: {
          items1: []
        }
      }
    };
  },
  mounted: function() { 
    if(this.$route.params.id!=''&&this.$route.params.id!=undefined){ //传递的栏目id拼到栏目上
  var stateObject = {};
  var title = "";
  var newUrl = '#/partyNew?column='+this.$route.params.id;
  history.replaceState(stateObject,title,newUrl);
     }
   }
  
};
</script>

