// 封装fetch、post请求及http 拦截器配置文件
import Vue from 'vue'
import axios from 'axios'
Vue.prototype.axios = axios

export default {
  data(){
    return{
    }
  },
 methods: {
   dataget(link){
    this.axios.post(link, {
       firstName: 'Fred',
       lastName: 'Flintstone'
     })
     .then(function (response) {
     //  console.log(response);
       var mmm=response.data.MSG
       return mmm
     })
     .catch(function (error) {
       console.log(error);
     });
    }
  }
}