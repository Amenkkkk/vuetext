<template>
 <div class="wapper" >
   <div class="logonheader">
         <img class="login-img" resize="stretch" :src="this.ImageUrl('icon/mipmap-mdpi/avatar_bg.png')" />       
    <div class="top-go" @click="routerBack()"></div>
   </div>
 <div class="loginbox">
      <div class="login-title">广州工业发展集团党建</div>
     <div class="userIN">
      <div class="login-info" v-if="typeid === 1">
        <div class="top-row input-row">
            <img class="user-img" resize="contain" :src="this.ImageUrl('icon/mipmap-xhdpi/ic_username.png')"/>
            <input type="text" placeholder="用户名" id="userid" class="username" placeholder-color="#999" v-model="nameInput"  value="" />
        </div>
        <div class="bottom-row input-row">
            <img class="pw-img" resize="contain" :src="this.ImageUrl('icon/mipmap-xhdpi/ic_password.png')"/>
           <input type="password" placeholder="密码" class="password"   maxlength="16    " placeholder-color="#999" v-model="pwInput"/>
            <img class="forget-pw"  @click="jump('/forget')" resize="contain" :src="this.ImageUrl('icon/mipmap-mdpi/ic_forget.png')" />
        </div>
        <div class="LIbox" @click="clickTypePost()">
        <div class="loginIN" >登  录</div>
        </div>
      </div>
      <div class="phoneIN" v-else-if="typeid === 2">
          <div class="top-row input-row">
            <img class="user-img" resize="contain" :src="this.ImageUrl('icon/mipmap-xhdpi/ico_phone.png')"/>
            <input type="number"  maxlength="11" placeholder="手机号" class="username" placeholder-color="#999" value=""  @change="checkphone" v-model="phonenumber" />
          </div>
          <div class="bottom-row input-row">
            <img class="pw-img" resize="contain" :src="this.ImageUrl('icon/mipmap-xhdpi/ico_coden.png')"/>
           <input type="text" maxlength="6" placeholder="验证码"   class="codenumber"  placeholder-color="#999" v-model="codeinput"/>
            <div  @click="checkp()"  class="PCodep">获取验证码</div>
        </div>
        <div class="LIbox" @click="codecheck()">
        <div class="loginIN">登  录</div>
        </div>
      </div>
        <div class="else-row">
            <div class="phone-login"  @click="changepage(2)"  v-if="typeid === 1">手机号登录</div>
            <div class="phone-login"  @click="changepage(1)" v-if="typeid === 2">密码登录</div>
            <div class="register" @click="jump('register')">注册账号</div>
        </div>
     </div>
 </div>
 </div>
</template>

<style scoped>
@import"./login.css";
</style>


<script>
import md5 from "crypto-js/md5";
import { Toast } from 'mint-ui';
export default {
  data() {
    return {
      typeid: 1,
      txtInput: "",
      passw: "",
      nameInput:'',
      pwInput:'',
      phonenumber: "",
      codeinput:'',
    //  keys: '[]',
      // getResult: "加载中..",
      // postResult: "loading..."  //测试初始值
    };
  },
  methods: {
    changepage(type) {
      this.typeid = type;
    },
    checkphone() {
      if (this.phonenumber == "") {
        this.Msgtxt("请输入手机号");
      } else if ( this.phonenumber.search( /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/ ) == 0 ) {
        return true;
      } else {
        this.Msgtxt("请输入正确手机号");
      }
    },
    submit(n) {
      return this.backHome(n);
    },
    clickTypePost() {  //用户登陆接口
      var me = this;
      me.$router.push({ name: "Home", params: { userID: '123' } }); //路由传值,***直接跳转测试
      localStorage.setItem( 'userDATA', '{"DATA":[{"USER_NAME":"测试账号","USER_ID":123}]}') //直接测试储存更新登陆数据
      localStorage.setItem("token",'123454dsdsad') //搞个测试的上去，不让token检测程序跳出来
      // var typeid = me.typeid;
      // var name = me.nameInput;
      // var pw = me.pwInput;
      // if (name === "") {
      //   me.Msgtxt("请输入用户名！");
      // } else if (pw === "") {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
      //   me.Msgtxt("请输入密码！");
      // }else{
      // me.Msgtxt("正在验证用户信息...");
      // var postid ={type: typeid,USERNAME: name,PASSWORD: md5(pw)}
      // var postid2 = me.toParams({
      //   type: typeid,
      //   USERNAME: name,
      //   PASSWORD: md5(pw)
      // });
      // var POST_USER = me.showdoc+"/appregister/applogin?"+postid2;//用户登陆接口
      // me .$http({
      //         method: "post",
      //         url:POST_USER,
      //        // params:postid,
      //         headers: { "Content-Type": "application/x-www-form-urlencoded" }, //新增加
      //         credientials: false,
      //         emulateJSON: true
      //       }).then(
      //         ret => { //请求成功
      //            console.log(ret.body);
      //            console.log(ret.body.CODE)
      //           var loginmsg = ret.body.MSG;
      //           var codenum = ret.body.CODE;
      //           var UID = ret.body.DATA.USER_ID; //获取拿到的userid
      //           localStorage.setItem( 'userDATA', JSON.stringify(ret.body)) //储存更新登陆数据
      //         setTimeout(() => {
      //           if (codenum === "1"||codenum === "3") { //成功登陆后跳转首页 
      //             me.Msgtxt(loginmsg);
      //             me.$router.push({ name: "Home", params: { userID: UID } }); //路由传值
      //             var savetoken=me.aesDecrypt(ret.headers.map.key.toString()) //获取解密token
      //             localStorage.setItem("token",savetoken) //储存更新token
      //           } else if (codenum === "2") {//成功登陆后没填写信息
      //             me.Msgtxt("信息未填写")
      //             me.$router.push({ name: "infor" });
      //           }else if (codenum === "8") {//成功登陆后没填写信息
      //             me.phonenumber=ret.body.DATA.PHONE
      //             Toast({
      //                  message: loginmsg+'请用手机验证码重新登录',
      //                  position: 'center',
      //                  duration: 3000
      //                });
      //             this.typeid=2
      //           } else { //登陆失败，弹出失败信息
      //            me.Msgtxt(loginmsg);
      //           }   
      //         }, 1500);                                
      //       },
      //         ret => {  //请求失败
      //           me.Msgtxt("服务器请求失败！");
      //         }
      //       );
      //   }
    },
    checkp() {   //验证码获取
      var me = this;
      var phone = me.phonenumber;
      var POST_TEL = me.showdoc+"/appregister/vercode?PHONE=" + phone; //验证码接口
      me .$http({
              method: "post",
              url: POST_TEL,
              headers: { "Content-Type": "application/x-www-form-urlencoded" }, //新增加
              credientials: false,
              emulateJSON: true
            }).then( ret => { //请求成功
                me.code = ret.body.CODE;
                if( me.code==1){
                me.codekey = ret.body.DATA.CODEKEY; //获取codekey
                me.Msgtxt('验证码已发送，请留意短信')
                }else{
                me.Msgtxt('获取失败'+me.code)
                }
              },ret => {  //请求失败
                me.Msgtxt("服务器请求失败！");
              }
            );
    },
    codecheck() {   //验证码登录
      var me = this;
      me.Msgtxt("正在验证用户信息...");
      var postcode = {TYPE: me.typeid,PHONE: me.phonenumber,CODE: me.code,CODEKEY: me.codekey,IDENTIFYING: me.codeinput}
      var POST_CODE = me.imgdoc+"/appregister/applogin?";
       me .$http({
              method: "post",
              url: POST_CODE,
              params:postcode,
              headers: { "Content-Type": "application/x-www-form-urlencoded" }, //新增加
              credientials: false,
              emulateJSON: true
            }).then( ret => { //请求成功
                console.log(ret.body)
                var codenum = ret.body.CODE; //获取登陆后的code
                var loginmsg = ret.body.MSG; //获取返回结果说明
                var UID = ret.body.DATA.USER_ID; //获取拿到的userid
                localStorage.setItem( 'userDATA', JSON.stringify(ret.body)) //储存更新登陆数据
               setTimeout(() => {
               if (codenum === "1"||codenum === "3") {
                  //成功登陆后跳转首页
                  var savetoken=me.aesDecrypt(ret.headers.map.key.toString()) //获取解密token
                  localStorage.setItem("token",savetoken) //储存更新token
                  me.Msgtxt("登录成功！")
                  me.$router.push({ name: "Home", params: { userID: UID } }); //路由传值
                } else if (codenum === "2") { //成功登陆后没填写信息，不跳转
                  me.Msgtxt("信息未填写")
                  me.$router.push({ name: "infor" });
                } else {  //登陆失败，弹出失败信息
                  me.Msgtxt("登录失败了！")
                }
               }, 1500);   
              },ret => {  //请求失败
                me.Msgtxt("服务器请求失败！");
              }
            );
    },
  },
  created() { 
      
  },
  mounted(){
    window.addEventListener('popstate', function () {
       window.opener=null;
       window.open('/Login');
       window.close();
      });
  }
};
</script>

