<template>
<div class="itembox">
  <div class="itemtitle">{{items.title}}</div>
  <div class="itemUl" >
     <div v-for="(item,i) in items.itemlist"  :key='i' class="itemLi">
       <div @click="jumpTo(item.url,{dataUrl: item.dataUrl,name:item.title,dateText:item.dateText,dateType:item.actType})" class="item-imgdiv">
          <img class="item-img" :src="item.img"/>
        <div class="item_text">{{item.title}}</div>
       </div>
     </div>
  </div>
</div>
</template>

<script>
 export default {
        props:['items'],
        data () {
            return {
            }
        },
        created(){
        }
    }
    
</script>

<style scoped>
.itembox{display: block;padding-left: 15px;padding-right: 15px; padding-top: 18px;padding-bottom: 18px;background-color: #fff;border-bottom: 10px solid #f2f2f2;}
.itemtitle{padding-left: 10px;border-left-style: solid; border-left-width: 5px; border-color: #da0000;  margin-bottom: 10px;font-size: 18px; text-align: left}
.itemUl{width: 100%; overflow: hidden}
.itemLi{ width:25%; float: left}
.item-imgdiv{text-align: center;}
.item-img{ width:40px; height: 40px; margin-bottom:10px;}
.item_text{ text-align: center; font-size: 16px;color: #666;}
.cell-button{
  background-color: #f2f2f2;
}
</style>

