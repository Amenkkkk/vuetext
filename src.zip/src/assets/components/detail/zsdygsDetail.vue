<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="main-page" offset-accuracy="300px">
            <div class="dygs_gsnr">{{detail_text}}</div>
        </div>
    </div>
</template>
<style scoped>
.dygs_gsnr{
    font-size: 16px;
    padding-left: 30px;
    padding-right: 30px;
    padding-top: 20px;
    padding-bottom: 20px;
}
</style>

<script>
    import listHeader from '../listHeader.vue'
    import CryptoJS from "crypto-js"; 
    
    export default {
        props:["infodata"],
        components: {
            'list-header': listHeader,
        },
        data () {
            var me = this;
            return {  
                loadinging: false,
                refreshing: false,
                title: '',
                detail_text:'测试22222222',
                text:'',
                POST_URL:me.infodata.detailURL+'?FLOW_ID=' + me.infodata.detailID,
                uu:me.infodata.detailURL,
            }
        },
        created: function() {
            // var me = this;
            // me.token=localStorage.getItem("token")
            // me.POST_URL=me.showdoc+me.POST_URL
            // me
            //     .$http({
            //     method: "post",
            //     url: me.POST_URL,
            //     headers: { "Content-Type": "application/x-www-form-urlencoded" ,
            //         "token": me.token == undefined ? '' : me.token,
            //         "userid": me.USER_ID == undefined ? '' : me.USER_ID,
            //         "timestamp": me.timestamp,
            //         "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj'+me.infodata.detailURL)+''
            //     }, //新增加
            //     credientials: false,
            //     emulateJSON: true
            //     })
            //     .then(
            //     res => {
            //         //请求成功
            //     var tokenkey = res.headers.map.key // 获取token
            //         me.takestate(tokenkey,ret.body.CODE)
            //         me.detail_text = res.body.DATA.GSNR;
            //     },
            //     res => {
            //         //请求失败
            //         console.log("服务器请求失败！");
            //     }
            //     );
        },
        methods: {
             
        },
        
    }
        
</script>
