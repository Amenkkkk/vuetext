<template>
<div class="newbox">
    <div class="newUl">
        <div class="newLi"  v-for="(item,i) in items" :key="i" >
            <div class="new-imgdiv" @click="jumpTo('newDetail',{id: item.id})" >
                <img class="new-img" resize="stretch" :src="item.img_url" />
            </div>
            <div class="newtext" @click="jumpTo('newDetail',{id: item.id})">
                <div class="new-title" >{{item.title}}</div>
                <div class="new-date" >{{item.publish_date}}</div>
            </div>
        </div>
    </div>
</div>
</template>
<style scoped>
.newUl{display: block;}
.newLi:first-child{border-top-color:#ccc; border-top-width: 1px;border-top-style: solid;}
.newLi{ border-bottom-color: #ccc;border-bottom-width: 1px;border-bottom-style: solid; padding: 15px;display: flex; justify-content:space-between;  flex-direction:row;}
.new-imgdiv{flex:40%; }
.new-img{width: 100%;border: 1px solid #e8e8e8; height: 80px;}
.newtext{ flex: 70%; margin-left: 20px; text-align: left;}
.new-title{
    color: #333; min-height: 55px;
    margin-bottom: 10px;
}
.new-date{
    font-size: 13px;
    color: #555;
}
</style>

<script>
    export default {
        props:["title","items"],
        data () {
            return {
            }
        },
        methods: {
        }
    }
</script>