// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './index'
import router from './router'
import store from './store'
import mixins from './mixins/index.js'
import  VueResource  from 'vue-resource'
import Vuex from 'vuex'
import Mint from 'mint-ui'
import httpjs from './http.js'

Vue.config.productionTip = false
// register global mixins.
Vue.mixin(mixins)
Vue.use(VueResource) 
Vue.use(Vuex)
Vue.use(Mint)
Vue.mixin(httpjs)

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  components: { App },
  template: '<app/>'
})