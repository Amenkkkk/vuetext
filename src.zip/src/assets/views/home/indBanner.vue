<template>
<div class="indban">
    <mt-swipe :auto="4000" class="mt_ul ">
        <mt-swipe-item v-for="(item,i) in indBanners" :key="i" class="mt_li">
          <div @click="jumpTo('newDetail',{id: item.url})"> <img :src="item.src" alt="" ></div> 
        </mt-swipe-item>
    </mt-swipe>
</div>
</template>
<style scoped>
.mt_ul{
    overflow: hidden;
    width: 100%;
    height: 220px;
    position: relative;
}
.mt_li{
    display: none;
    position: absolute;
    width: 100%;
    height:100%;
}
.mt_li img{
    width: 100%;
    height: 220px;
}
.is-active{
    display: block
}
</style>
<script>
    export default {
        props:["indBanners"],
        data () {
            return {
                
            }
        },
        methods: {
        }
    }
</script>