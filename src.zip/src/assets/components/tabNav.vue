<template>
  <div class="nav_bottom">
      <div class="nav_li" @click="jump('/Home')">
        <img v-if="active != 1" class="nav_li_img" :src="this.ImageUrl('icon/home.png')"/>
        <img v-if="active == 1" class="nav_li_img" :src="this.ImageUrl('icon/home_on.png')"/>
        <div class="tabname" v-bind:class="{ cur: active == 1 }">主页</div>
      </div>
      <div class="nav_li" @click="jump('/Orga')">
        <img v-if="active != 2" class="nav_li_img" :src="this.ImageUrl('icon/team.png')"/>
        <img v-if="active == 2" class="nav_li_img" :src="this.ImageUrl('icon/team_on.png')"/>
        <div class="tabname" v-bind:class="{ cur: active == 2 }" >我的组织</div>
      </div>
      <div class="nav_li" @click="jump('/Study')">
        <img v-if="active != 3" class="nav_li_img" :src="this.ImageUrl('icon/study.png')"/>
        <img v-if="active == 3" class="nav_li_img" :src="this.ImageUrl('icon/study_on.png')"/>
        <div class="tabname" v-bind:class="{ cur: active == 3 }" >在线学习</div>
      </div>
      <div class="nav_li" @click="jump('/My')" style="position: relative;">
        <div class="mspoint" v-if="msgnum>0"></div>
        <img v-if="active != 4" class="nav_li_img" :src="this.ImageUrl('icon/me.png')"/>
        <img v-if="active == 4" class="nav_li_img" :src="this.ImageUrl('icon/me_on.png')"/>
        <div class="tabname" v-bind:class="{ cur: active == 4 }" >个人中心</div>
      </div>
    </div>
</template>
<style  scoped>
.nav_bottom{
    flex-direction:row;
    bottom: 0;
    width: 100%;
    position:fixed;
    bottom: 0;
    background-color: #fff;
    display: flex;
  }
  .nav_li{
    flex: 1;
    text-align: center;
    align-items: center;
    border-top: #ccc 1px solid;
    padding-top:8px;
    padding-bottom: 3px;
  }
  .nav_li_img{
    width: 30%;
    border-bottom: 8px;
  }
  .cur{
      color: #da0000;
  }
  .mspoint{ background: #ec0000; width: 7px ; height: 7px; border-radius:5px; position: absolute; right: 50%;
    margin-right: -20px;}
  .tabname{font-size: 14px;}
</style>

<script>
export default {
        props:["active"],
        data () {
            return {
              msgnum:'', //获取未读消息
            }
        },
        methods: {
        },
        created(){
          this.msgnum=localStorage.getItem("msgnum")
        }
    }
</script>
