<template>
<div class="main-li" >
    <div  class="mainbox" >
        <mt-loadmore :top-method="loadTop" :autoFill='autof'  @top-status-change="handleTopChange"  :bottom-method="loadBottom"  @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="textbox">
        <div class="cell-button">
            <div class="newbox">
                <div class="newUl">
                    <!-- <div> {{onclassList}}</div> -->
                    <div class="newLi" v-for="(item, i) in onclassList" :key="i" @click="jumpTo('courseDetail',{id: item.id})">
                        <!-- {{item.ydqk}} -->
                        <div class="ydqk">
                            <div class="ydqk_bg"><div class="ydqk_bghui"></div></div>
                            <img class="ydqk_bgimg" v-if="item.ydqk==0" :src="status0"/>
                            <img class="ydqk_bgimg" v-if="item.ydqk==1" :src="status1"/>
                            <img class="ydqk_bgimg" v-if="item.ydqk==2" :src="status2"/>
                            <div class="ydqk_bg"><div class="ydqk_bghui"></div></div>
                        </div>
                        <div class="new-imgdiv">
                            <img class="new-img" resize="stretch" :src="serverUrl (item.url)" />
                            <img class="videologo" v-if="item.type==2" :src="videologo"/>
                        </div>
                        <div class="newtext" >
                            <div class="new-title">{{item.title.substr(0,26)}}</div>
                            <div class="new-date" >{{item.create_time.substr(0,11)}}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div slot="top" class="loadmore-top">
            <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
            <span v-show="topStatus === 'drop'">释放加载</span>
            <span v-show="topStatus === 'loading'">正在加载....</span>
             </div>
             <!--下拉刷新提示-->
        <div slot="bottom" class="loadmore-bottom">
            <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
            <span v-show="bottomStatus === 'loading'">加载中...</span>
         </div><!--上拉加载提示-->
        </mt-loadmore>
        <div class="detailbox"  v-if='detail'>  
           <div class="closebtn" @click="closebox()"><!--关闭按钮--></div>
           <detail :infodata='infodatas'></detail>
        </div>
    </div>
</div>   
</template>
<style scoped>
.refresh {
    width:100%;
    height:90px;
    display: -ms-flex;
    display: -webkit-flex;
    display: flex;
    -ms-flex-align: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    align-items: center;
  }
.refont{
    font-size: 30px;
    /* height: 100px; margin-top: -100px; */
} 
.indicator{ width:50px; height:50px; margin-top:20px; }
.listbottom{ background-color: #f2f2f2; line-height: 70px; height: 70px; text-align: center}
.newUl{display: block;}
.newLi:first-child{border-top-color:#ccc; border-top-width: 1px;border-top-style: solid;}
.newLi{ border-bottom-color: #ccc;border-bottom-width: 1px;border-bottom-style: solid; padding-right: 20px;display: flex; justify-content:space-between;  flex-direction:row;}
.new-imgdiv{flex: 2; margin-top: 20px;margin-bottom: 20px; width: 100px; height: 78px;position: relative;}
.new-img{ width: 100%; height: 100%; border: 1px solid #e8e8e8;}
.newtext{ flex:4; margin-left: 15px; margin-top: 20px;margin-bottom: 20px;}
.new-title{ min-height: 55px;
    font-size: 16px;
    color: #000;
    margin-bottom: 8px;
}
.new-date{
    font-size: 14px;
    color: #555;
}
.ydqk{flex: 1;height:120px;display: flex; justify-content:space-between;  flex-direction:column; text-align: center;align-items: center;}
.ydqk_bg{flex: 2;position: relative;}
.ydqk_bghui{width: 5px;height: 48px;background-color: #ccc;}
.ydqk_bgimg{flex: 1;width: 25px;height: 25px;}
.detailbox{ position: fixed; background-color:#fff; top:0px;left: 0;right: 0;bottom:0px;}
.closebtn{position: absolute ; top: 0;left: 0;width:200px; height: 100px; z-index: 100; }
.videologo{position: absolute;
    width: 36px;
    top: 50%;
    left: 50%;
    margin-left: -19px;margin-top: -19px;}
</style>

<script>
    import detail from '../detail/courseDetail.vue'
    import CryptoJS from "crypto-js";    
    export default {
        props:["title","items"],
        components: {
            'detail': detail,
        },
        data () {
            var me=this;
            return {
                status0:this.ImageUrl('icon/mipmap-xhdpi/status_0.png'),
                status1:this.ImageUrl('icon/mipmap-xhdpi/status_1.png'),
                status2:this.ImageUrl('icon/mipmap-xhdpi/status_2.png'),
                videologo:this.ImageUrl('icon/ic_play.png'),
                loadinging: false,
                refreshing: false,
                showLoading: 'hide',
                POST_onclass:me.items.POST_onclass,
                onclassList:[{id:'123',ydqk:'1',url:this.ImageUrl('img1.jpg'),type:'2',title:'学习课程标题多出字符串自动截取1234568910111213',create_time:'2020年9月15日'},
                {id:'123',ydqk:'0',url:this.ImageUrl('img2.jpg'),type:'1',title:'学习课程标题多出字符串自动截取21234568910111213',create_time:'2020年9月15日'},
                {id:'123',ydqk:'0',url:this.ImageUrl('img3.jpg'),type:'1',title:'学习课程标题多出字符串自动截取31234568910111213',create_time:'2020年9月15日'},{id:'123',ydqk:'2',url:this.ImageUrl('img4.jpg'),type:'2',title:'学习课程标题多出字符串自动截取41234568910111213',create_time:'2020年9月15日'}],
                alllist:'',//文章总数
                listcount:10,//文章加载数
                last:false,
                detail: false,
                infodatas:{
                    detailID: '',
                },
            }
        },
        created: function() {
          //  this.datalist() //调用加载数据方法
        },
        methods: {
            datalist(){
                var me = this;
                me.token=localStorage.getItem("token")
                me.POST_onclass = me.showdoc+me.items.POST_onclass+localStorage.getItem("paramid")+'&DEPT_ID='+me.mydept+'&USER_ID='+me.myuser;
                console.log(me.POST_onclass)
            //文章列表数据
            me.$http({
                method: "post",
                url: me.POST_onclass+ "&SHOWCOUNT=" + me.listcount,
                headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": me.timestamp,
                     "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + me.items.POST_onclass_head)+''
                   }, //新增加
                credientials: false,
                emulateJSON: true
                }).then(ret => {
                    //请求成功
                 var tokenkey = ret.headers.map.key // 获取token
                    me.takestate(tokenkey,ret.body.CODE)
                    me.onclassList = ret.body.DATA.result;
                    me.alllist = ret.body.DATA.totalResult;
                    if (me.alllist < 10) {
                       me.allLoaded = true;
                       me.loadingmsg = "";
                     }
                     console.log(ret.body)
                },
                ret => {
                    //请求失败
                    console.log("服务器请求失败！");
                }
                );
            },
            showdetail(ID){
                this.detail=true
                this.infodatas={detailID: ID}
            },//传数据到详细页窗口
            closebox(){
               this.detail=false
            },//关闭窗口
     loadTop() {
      setTimeout(() => {
        this.listcount = 10; //重置条数
       // this.datalist(); //重新加载数据
        this.loadingmsg = "上拉加载";
        this.allLoaded = false; //启动加载
        this.$refs.loadmore.onTopLoaded();
        this.Msgtxt("刷新成功！")
      }, 2000);
    },
    loadBottom() {
      this.token = localStorage.getItem("token");
      setTimeout(() => {
        var me = this;
        if (me.alllist - me.listcount > 0) {
          me.listcount = me.listcount + 10;
          me.$http({//获取数据
              method: "post",
              url: me.POST_onclass+ "&SHOWCOUNT=" + me.listcount,
              headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": me.timestamp,
                     "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + me.items.POST_onclass_head)+''
                   }, //新增加
              credientials: false,
              emulateJSON: true
            }).then(ret => {//请求成功 
                me.onclassList = ret.body.DATA.result;
                 console.log(me.onclassList)
              },ret => {
                //请求失败
                console.log("服务器请求失败！");
              }
            );
        } else {
          me.allLoaded = true;
          me.loadingmsg = "已经到底了";
        }
        me.$refs.loadmore.onBottomLoaded();
      }, 1000);
    }
        }
    }
</script>