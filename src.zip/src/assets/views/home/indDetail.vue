<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <!-- <text>{{tablise.textItems.items1}}</text> -->
        <div class="tablist_main">
            <div class="main-ul" > 
                <tabList :indexpost="indexpost"></tabList>
            </div>
        </div>
        <!-- <text>{{tablise}}</text> -->
    </div>
</template>
<style>
.tablist_main{
    position: fixed;
    bottom: 0;
    top: 50px;
    overflow-y: auto;
    width: 100%;
    -webkit-overflow-scrolling: touch;
}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import tabList from '../../components/list/tabList.vue';
    export default {
        components: {
            'list-header': Header,
            'tabList': tabList,
        },
        data () {
            var me=this;
            return {
                title:me.$route.params.name,
                indexpost:'/appindex/articleListByColumnId',
                postResult:'',
                tablise:{
                    POST_Tablist:'',
                    colunm_id:'',
                    activeTab: 0,
                    tabNum:1,
                    tabs: [],
                    textItems: {
                        items1:[],
                    },
                },
            }
        },
    }
        
</script>

