<template>
 <div class="wrapper">
       <list-header :title="title"></list-header>
       <div  class="main-page"  offset-accuracy="300px">
               <div class="info-row">
                 <div class="infotitle">用户ID</div>
                 <div class="infocon">{{this.USER_ID}}</div>
              </div>
           <div class="low">         
             <mt-button @click.native="Loginout" class="LIbox" >退出登录</mt-button>
           </div>
       </div>
 </div> 
</template>
<style scoped>
.main-list{background-color:#f2f2f2;}
 .info-row {
  background-color: #fff;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  padding-right: 10px;
  border-bottom:solid 1px  #d6d6d6;
  padding-left: 20px; display: flex; height: 50px; 
}
.infotitle {
  color: #7a7a7a;
 width:80px;
}
.infocon {
  text-align: right;
  color: #333; 
  align-items: right;
}
.enterimg {
  width: 35px;
  height: 80px;
  margin-left:15px;
}
.low {
  margin-top: 150px;
  flex-direction: column;
  justify-content: space-between;
  align-items: center;
}
 .LIbox {
  width: 70%;
  background-color: #da0000;
  margin:20px auto;
  height: 40px; display: flex;
  border-radius: 5px;
  font-size: 18px;
  text-align: center;
  color: #fff;

  justify-content: center;
  align-items: center;
}
.loginout{ font-size: 18px;
  text-align: center;
  color: #fff;
}
</style>

<script>
import CryptoJS from "crypto-js";
import Header from "../../components/listHeader.vue";
import { MessageBox } from 'mint-ui';
export default {
    components: {
          "list-header": Header
        },
     data() {
    return {
       title: this.$route.params.name,
     };
  },
    methods:{
        Loginout () {  //退出登陆
        MessageBox.confirm('确定要退出登录吗?','提示',{confirmButtonClass:'ybtn'}).then(action => {
          var me=this
          me.token=localStorage.getItem("token")
          me.$http({
          method: "post",
          url: me.showdoc + '/appUT/de?USER_ID='+ me.USER_ID,
          headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": Date.now().toString(),
                     "sign": CryptoJS.MD5(Date.now().toString() + me.USER_ID + me.token + '/zhdj/appUT/de')+''
                     }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功            
              if(ret.body.CODE==1){
                  me.$router.push({ name: "login"}); //退出后跳转登录页面
                  localStorage.removeItem("token") 
                  localStorage.removeItem('userDATA') 
                  me.Msgtxt('退出成功！') 
              }else{
                 console.log(ret.body.MSG)
              }   
          },
          ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
         });       
       }
    },
     created() {
 
  }
     
 }
</script>