<template>
    <div class="wrapper" id="ind_ifdiv">
        <list-header :title="title" v-if='headlist'></list-header>
        <!-- <iframe class="webview_zxcp" :src="POST_link" :style="'height:'+ss+'px'"></iframe> -->
        <div class="main-page webview_zxcp">
            <div class="detialbox" v-for="(post_detail,i) in post_detail" :key="i">
                <div class="new-title" id="title">{{post_detail.TITLE}}<!-- 文章标题 --></div>
                <div class="new-info">
                        <span class='newline' id='author'>作者：{{post_detail.AUTHOR}}</span>
                        <span id='time'>时间：{{post_detail.PUBLISH_DATE}}</span>
                </div>
                <div class="new-content" id='contenttxt' v-html="post_detail.CONTENT"><!-- 文章内容 --></div>
        </div>
       </div>
       <pingLun :postdetail='post_detail'></pingLun>
    </div>
</template>
<style scoped>

.main-page{bottom: 35px;}
.detialbox{ margin:10px 15px;padding-top:20px; padding-bottom: 20px;margin:0.625em 0.9375em;padding-top:1.250em; padding-bottom: 1.250em;}
.new-title{ padding:0 20px 0 28px; font-size: 18px;color: #4b4b4d;padding:0 1.250em 0.625em 1.75em;text-align: center;}
.new-info{ display: flex; flex-flow: nowrap; justify-content: center;padding-top: 5px;}
.new-info span{ color: #a3a3ac; font-size: 13px; padding:0 5px;}
.newline{border-right:1px solid #dbdbde;}
.new-content{ padding-top:10px;}
.new-content p{ line-height: 22px; color: #4b4b4d; }
.new-content img{ margin:0 auto;display: block;padding-top: 10px; padding-bottom: 15px; width:100%;}
</style>
<style>
.webview_zxcp *{max-width: 100%;}
</style>

<script>
import Header from '../../components/listHeader.vue';
import pingLun from './pingLun.vue';
import CryptoJS from "crypto-js";
    
    export default {
        props:["infodatas"],
        components: {
            'list-header': Header,
            'pingLun':pingLun
        },
        data () {
            var me = this;
            return {  
                title: '香港中联办新闻',
             //   POST_URL:'',
                POST_link:'',
                ss:0,
                headlist:true,
                post_detail:[
                    {TITLE: '香港中联办、国务院港澳办分别发声，谴责香港反中乱港分子诋毁抹黑内地援港抗疫举措', src: this.ImageUrl('img1.jpg'), AUTHOR:'myLearn',column_name:'党建要闻',PUBLISH_DATE:'2020年9月3日',ID:'19',CONTENT:'中央人民政府驻香港特别行政区联络办公室发言人8月30日发表谈话表示，香港极少数别有用心者制造和散布恶毒谣言，诋毁抹黑内地援港抗疫举措，行径卑劣，令人不齿。<br/>发言人介绍说，应香港特区政府的请求，近期由国家卫健委组建的两支“内地核酸检测支援队”共220多名队员先后抵港。他们将充分遵守香港既有医疗规程，做好实验室核酸检测工作，为香港抗疫助一臂之力。同时，中央政府还将支持香港改造“方舱医院”和兴建临时医院，并根据特区需要，随时调集内地医疗资源予以更多支持。连日来，特区政府和许多香港市民以各种方式对“内地核酸检测支援队”表示欢迎，衷心感谢中央对香港的关心关爱和内地同胞的大力支援，表达了广大港人的共同心声。',IS_ZAN:'1',DIANZAN:'点赞？',COMMENT_NUM:'15',}
                    ],
                page_zanurl:'/appindex/editDianZan',
                IS_ZAN:'',
                page_zan_url:'',
            }
        },
        created: function() {
            // var me = this;
            
            // if(me.infodatas=='' || me.infodatas==undefined){
            //    console.log(me.infodatas+'111')
            //  me.headlist=true;
            //  me.title='香港中联办新闻22'
            //  me.ss=document.documentElement.clientHeight-50;
            //  me.POST_link= me.showdoc + '/appindex/articleDetail?ID=' + me.$route.params.id+'&USER_ID='+me.myuser;
            //  me.page_zanurl=me.showdoc + me.page_zanurl+'?INFO_ID='+me.$route.params.id+'&USER_ID='+me.myuser;
            // }else{
            //  me.ss=me.infodatas.ifrheight;
            //  me.POST_link= me.showdoc + '/appindex/articleDetail?ID=' + me.infodatas.detailID+'&USER_ID='+me.myuser;
            //  me.page_zanurl=me.showdoc + me.page_zanurl+'?INFO_ID='+me.infodatas.detailID+'&USER_ID='+me.myuser;
            // }
            // me.token=localStorage.getItem("token")
            // me.$http({
            //     method: "post",
            //     url: me.POST_link,
            //     headers: { "Content-Type": "application/x-www-form-urlencoded" ,
            //                 "token": me.token == undefined ? '' : me.token,
            //                 "userid": me.USER_ID == undefined ? '' : me.USER_ID,
            //                 "timestamp": me.timestamp,
            //                 "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appindex/articleDetail')+''
            //                 }, //新增加
            //     credientials: false,
            //     emulateJSON: true
            //     })
            //     .then(ret => {//请求成功
            //     var tokenkey= ret.headers.map.key // 获取token
            //         me.takestate(tokenkey,ret.body.CODE)
            //       //  me.post_detail = ret.body.DATA;
            //         me.page_zan_url=me.page_zanurl+'&IS_ZAN='+me.post_detail.IS_ZAN;
            //     },
            //     ret => {
            //         //请求失败
            //         console.log("服务器请求失败！");
            //     }
            //     );
        },
        methods:{
            
        }
        
    }
        
</script>
