<template>
<div class="newbox">
    <div class="per"  @click="jumpTo('PersonInfor',{PERData: persons, PhotoData:photo})"> 
         <!--  "jump('PersonInfor')" -->
        <div class="new-imgdiv">
            <img class="new-img" resize="stretch" :src='photo' />
        </div>
    <div class="newtext">
        <div class="per-title">{{Showname}}</div>
        <div class="per-orga">所属组织：{{person.DEPTNAME}}</div>
        <div class="per-pol">政治面貌：{{person.SNAME}}</div>
    </div>       
    </div>
</div>
</template>
<style scoped>
.per{ padding:0 20px; display: flex; justify-content:space-between;  flex-direction:row; align-items: center}
.new-imgdiv{width: 70px;justify-content:center;}
.new-img{width: 70px; height: 70px; border-radius: 50px;}
.newtext{ flex:1; margin-left: 20px;}
.per-title{
    color: #000; font-size: 18px;
    margin-bottom: 5px;
}
.per-orga,.per-pol{
    color: #555;
}
</style>

<script>
    // var navigator = weex.requireModule('navigator')
    // var storage = weex.requireModule('storage');//储存模块
    export default {
        props: ["persons","person"],
        photo:'',
        data () {
            return {
                Showname:'',
                photo:this.ImageUrl('icon/mipmap-mdpi/study_zxxt.png')
            }
        },
        methods: {

        },
        created(){
            this.Showname="张三"//this.uname
            this.person.DEPTNAME="宣传部"
            this.person.SNAME="党员"
            // if( this.USER.DATA.PHOTO==''){        //获取数据用户头像字段
            //      this.photo=this.ImageUrl('icon/mipmap-mdpi/study_zxxt.png') //为空则输出默认图片
            // }else{
            //     this.photo=this.ImageUrl('icon/mipmap-mdpi/study_zxxt.png')//this.imgdoc+this.USER.DATA.PHOTO
            // }
        //   })
        }
    }
</script>