<template>
<div class="topnav">
        <div class="toptitle">{{title}}</div>
    <div class="message">
        <!-- <image class="msg-img" resize="contain" :src="this.ImageUrl('icon/mipmap-xhdpi/ic_msg.png')"/> -->
         <div class="top-go" @click="routerBack()"></div>
    </div>
</div>
</template>
<style scoped>
.iconfont2 {
    font-family:iconfont;
}
.topnav{ height:35px;width:100%; background-color: #da0000; display: flex;justify-content:center;align-items: center; position: fixed; z-index: 100000;}
.toptitle{color: #fff; font-size: 16px; }
.message{ position: absolute;top: 0;right: 0;}
.magicon{color: #fff; width: 30px;height:30px ;line-height: 100px; margin-right:10px;}
.msg-img{ width: 50px; margin-right: 20px;}
</style>
<script>
    export default {
        props:["title"],
        data () {
            return {
            }
        },
        methods: {
        }
    }
</script>