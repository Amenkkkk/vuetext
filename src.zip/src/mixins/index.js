// 存放全局应用方法
import CryptoJS from "crypto-js";
import { Toast } from 'mint-ui';


export default {
  data() {
    return {
      // showdoc:'http://192.168.1.226:8081/zhdj',
      showdoc: '/zhdj',
      imgdoc: '/zhdj',
      aesSecretKey: 'DANGjian#zhongke.123456=4ecsgj6',//加密密钥
      iv: "F27D5C9927726BCEFE7510B1BDD3D137",//iv
      salt: "3FF2EC019C627B945225DEBAD71A01B6985FE84C95A70EB132882F88C0A59A55",//salt
      linkdoc: 'http://192.168.1.226:8081',
      mydept: '',
      myuser: '',
      USER_ID: '',
      token: '',
      timestamp: Date.now().toString(),
      allLoaded: false,
      topStatus: '',
      bottomStatus: '',
      autof: false,
      loadingmsg: '上拉加载',

    }
  },
  methods: {
    jumpTo(name, params) {
      if (this.$router) {
        this.$router.push({ name: name, params: params })
      }
    },
    jump(to) {
      if (this.$router) {
        this.$router.push(to)
      }
    },
    routerBack() {
      this.$router.go(-1);
    },
    Msgtxt(message) {
      Toast({
        message: message,
        position: 'center',
        duration: 1500
      });
    },//weex的
    ImageUrl(name) { //图片地址
      let baseurl ='/static/';//本地地址 // "http://192.168.1.226:8081/zhdjweb/images/";  // 实际上线地址
      return baseurl + name;
    },
    serverUrl(name) { //服务器地址
      let baseurl = '../';//"http://192.168.1.226:8081/zhdj/";  // 实际上线地址
      return baseurl + name;
    },
    toParams(obj) {  //数据拼接
      var param = ""
      for (const name in obj) {
        if (typeof obj[name] != 'function'&&encodeURI(obj[name])!=''&&encodeURI(obj[name])!=undefined) { //为空不拼接
          param += "&" + name + "=" + encodeURI(obj[name])
        }
      }
      return param.substring(1)
    },
    handleTopChange(status) {
      this.topStatus = status;
    }, //刷新提示调用方法
    handleBottomChange(status) {
      //调用加载提示
      this.bottomStatus = status;
    },  //加载提示调用方法
    takestate(token,code){    //接口返回信息判断
      if( token != undefined&& token != '' ){
        var savetoken=this.aesDecrypt(token.toString())
        localStorage.setItem("token",savetoken) //储存更新token
     }else if(code!=1){
      // console.log('测试11111')
       this.$router.replace({ name: "login"}); //无token或过期则跳转
     }
    },

    // aes 加密
    // @param {* 待加密的字符串} content 
    aesEncrypt(content) {
      var encrypted = CryptoJS.AES.encrypt(content, this.PBKDF2(), {
        iv: CryptoJS.enc.Hex.parse(this.iv)
      });
      return encrypted.ciphertext.toString(CryptoJS.enc.Base64)
    },


    //  aes 解密
    //  @param {* 待解密的字符串} content  
    aesDecrypt(content) {
      // console.log(content)  //检测传入字符串
      var cipherParams = CryptoJS.lib.CipherParams.create({
        ciphertext: CryptoJS.enc.Base64.parse(content)
      });
      var decrypted = CryptoJS.AES.decrypt(cipherParams, this.PBKDF2(), {
        iv: CryptoJS.enc.Hex.parse(this.iv)
      });
      return decrypted.toString(CryptoJS.enc.Utf8)
    },


    // 获取PBKDF2加密后的key
    PBKDF2() {
      var key = CryptoJS.PBKDF2(this.aesSecretKey, CryptoJS.enc.Hex.parse(this.salt), {
        keySize: 128 / 32,
        iterations: 10000
      });
      return key;
    },

  },
  created() {
    var userDATA = localStorage.getItem("userDATA")   //获取用户信息
    // if (userDATA != '' && userDATA != undefined) {
    //   this.USER = JSON.parse(userDATA)    //编译用户信息
    //   this.USER_ID = this.USER.DATA.USER_ID   //在用户信息中获取id
    //   this.mydept = this.USER.DATA.DEPT_ID;  //用户部门id
    //   this.myuser = this.USER.DATA.USER_ID;  
    //   this.uname = this.USER.DATA.USERNAME;  //用户登录名
    // }

  },
  computed: {
    totalheight() {
      //  const height = 750/weex.config.env.deviceWidth*weex.config.env.deviceHeight 
      //  return height
    },
  }
}
