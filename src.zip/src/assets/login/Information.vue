<template>
 <div class="wapper" :class="{flex:flex}">
   <div class="backheader">
      <img class="back-img" @click="routerBack" resize="contain" :src="this.ImageUrl ('icon/mipmap-mdpi/ico_back.png')"/>
      <div class="backtitle">资料填写:</div>
      <!-- {{this.$route.params.userID}} -->
   </div>
<div   class="infor-list">
  <div class="infobox">
  <div class="infotips">上级需要您填写个人的详细资料，以便审核。</div>
  <div class="infortext">
    <div class="info-row">
      <div class="infotitle">所属组织</div>
      <div class="infocon infored" @click="inputName(6)"
       :class="[changeColor(topColor)]">{{organizeTxt}}</div>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl" />
    </div>
    <div class="info-row">
      <div class="infotitle">姓名</div>
      <div class="infocon infored" @click="inputName(1)"  
       :class="[changeColor(reasonColor)]">{{Nameinfo}}</div>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl" />
    </div>
    <div class="info-row">
      <div class="infotitle">身份证号</div>
      <div class="infocon" @click="inputName(2)">{{IDinfo}}</div>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl"/>
    </div>
    <div class="info-row">
      <div class="infotitle">政治面貌</div>
      <div class="infocon"  @click="inputName(7)">{{PoliticsTxt}}</div>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl"/>
    </div>
    <div class="info-row">
      <div class="infotitle">户口所在地</div>
      <div class="infocon" @click="inputName(3)">{{Origin}}</div>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl"/>
    </div>
    <div class="info-row">
      <div class="infotitle">常用住址</div>
      <div class="infocon" @click="inputName(4)">{{Homeadd}}</div>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl"/>
    </div>
    <div class="info-row" v-if="PoliticsTxt=='党员'">
      <div class="infotitle">入党时间</div>
      <mt-button  class="infocon" @click.native="open('jointime')" size="large">{{Jointimetxt}}</mt-button>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl"/>
    </div>
    <div class="info-row" v-if="PoliticsTxt=='党员'">
      <div class="infotitle">转正时间</div>
        <mt-button  class="infocon" @click.native="open('Beworktime')" size="large">{{Beworktimetxt}}</mt-button>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl"/>
    </div>
    <div class="info-row"  v-if="PoliticsTxt=='党员'">
      <div class="infotitle">党费到期日</div>
        <mt-button  class="infocon" @click.native="open('Paytime')" size="large">{{Paytimetxt}}</mt-button>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl"/>
    </div>
    <div class="info-row"  v-if="PoliticsTxt=='党员'">
      <div class="infotitle">党内职务</div>
      <div class="infocon" @click="inputName(5)">{{PDuties}}</div>
      <img class="enterimg" resize="contain" v-bind:src="ToImgurl"/>
    </div>
  </div>
  </div>
  <div v-if="inputIndex == 1" > 
    <div class="floatbg"  @click="closebtn(1)"></div>
    <div class="flinput" >
            <input placeholder="姓名" type='text' v-model="reasonTxt" :autofocus="true" maxlength='5' class="textarea-show"/>
            <div class='closebtn' @click="closebtn(1)">取消</div>
            <div class="enterbtn" @click="enterbtn(1)">确定</div>
    </div>
</div>
<div v-if="inputIndex == 2" > 
    <div class="floatbg"  @click="closebtn(1)"></div>
    <div class="flinput" >
            <input placeholder="证件号" type='number' v-model="reasonID" :autofocus="true" maxlength='18' class="textarea-show"/>
            <div class='closebtn' @click="closebtn(1)">取消</div>
            <div class="enterbtn" @click="enterbtn(2)">确定</div>
    </div>
</div>
<div v-if="inputIndex == 3" > 
    <div class="floatbg"  @click="closebtn(1)"></div>
    <div class="flinput" >
            <input placeholder="城市" v-model="reasonOrigin" :autofocus="true" maxlength='6' class="textarea-show"/>
            <div class='closebtn' @click="closebtn(1)">取消</div>
            <div class="enterbtn" @click="enterbtn(1)">确定</div>
    </div>
</div>
<div v-if="inputIndex == 4" > 
    <div class="floatbg"  @click="closebtn(1)"></div>
    <div class="flinput" >
            <input placeholder="请填写正确地址" v-model="reasonAdd" :autofocus="true" maxlength='50' class="textarea-show"/>
            <div class='closebtn' @click="closebtn(1)">取消</div>
            <div class="enterbtn" @click="enterbtn(1)">确定</div>
    </div>
</div>
<div v-if="inputIndex == 5" > 
    <div class="floatbg"  @click="closebtn(1)"></div>
    <div class="flinput" >
            <input placeholder="职务名称" v-model="reasonDut" :autofocus="true" maxlength='10' class="textarea-show"/>
            <div class='closebtn' @click="closebtn(1)">取消</div>
            <div class="enterbtn" @click="enterbtn(1)">确定</div>
    </div>
</div>
<div v-if="inputIndex == 6" > 
    <div class="floatbg"  @click="closebtn(1)"></div>
     <mt-picker class='pickint' :slots="organizesolt" :itemHeight='orgaH' @change="onOrganChange" :visible-item-count="3" ></mt-picker>
     <div class='closebtn2' @click="closebtn(1)">取消</div>
     <div class="enterbtn2" @click="enterbtn(3)">确定</div>
</div>
<div v-if="inputIndex == 7" > 
    <div class="floatbg"  @click="closebtn(1)"></div>
     <mt-picker class='pickint' :slots="Politicsolt" :itemHeight='orgaH' @change="onPolitChange" :visible-item-count="3" ></mt-picker>
            <div class='closebtn2' @click="closebtn(1)">取消</div>
            <div class="enterbtn2" @click="enterbtn(4)">确定</div>
</div>
 <mt-datetime-picker class='pickerday' ref="jointime" type="date" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日"  @confirm="joinChange"></mt-datetime-picker>
 <mt-datetime-picker class='pickerday' ref="Beworktime" type="date" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日"  @confirm="beworkChange"></mt-datetime-picker>
 <mt-datetime-picker class='pickerday' ref="Paytime" type="date" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日"  @confirm="payChange"></mt-datetime-picker>
</div>
    <div class="LIbox"   @click="saveInfo()">
        <div class="loginIN">保存</div>
    </div>
    <!--  <div>{{count}}{{mess}}</div> -->
  </div>
</template>

<!--带scoped为本页面可用的样式，其他页面无法使用*/
 .main-list{position: fixed;top: 120px;bottom: 0px;left: 0;right: 0;} -->
<style scoped>
@import"./login.css";
/*头部样式*/
.infotips {
  border-bottom:1px solid #efefef;
  text-align: center;padding:15px;
  color: #7a7a7a;
  font-size: 14px;
}
.info-row {
  background-color: #fff;
  display: flex;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  border-bottom:1px solid #d6d6d6;
  padding:0 10px;
  min-height: 60px;
}
.infotitle {
  color: #7a7a7a;
  flex:30%;
  text-align: left;
}
.infored{  color: #e8012c;}
.infocon {
  text-align: right;
  flex:70%;
  padding: 10px 0;
}

.enterimg {
  width: 20px;
  height: 20px;
}

.defaut-none {
  width: 0;
  height: 0;
}
.change-black {
  color: #333;
}
.change-red {
  color: rgb(222, 2, 2);
}
.textarea-show {
  padding:10px;
  background-color: #fff;
  border:none;
  border-bottom: 1px #cecece solid;
  top: 100px;
  margin:40px  10% 0 10%;
  color: #333;    width: 70%;
}
.floatbg {
  position: fixed;
  height: 100%;
  background-color: #000;
  opacity: 0.6;
  width: 750px;
  top: 0;
}
.flinput {
  position: fixed;
  width:70%;
  height: 130px;
  top: 35%;
  left: 50px;
  border-radius: 10px;
  background-color: #fff;
  border-color: #ccc;
  border-width: 1px;
}
.enterbtn {
  bottom: 15px;
  text-align: center;
  right: 0;
  width: 50%;
  position: absolute;
  color: #ff4081;
}
.closebtn {
  bottom: 15px;
  text-align: center;
  right: 50%;
  width: 50%;
  position: absolute;
  color: #ff4081;
}
.enterbtn2 {
  top:335px; border-top:2px solid  #ff4081;
  text-align: center; line-height:35px;
  right: 15%;
  width: 35%; background:#fff; border-radius:0 0 10px 0;
  position: absolute;    z-index: 1000;
  color: #ff4081;
}
.closebtn2 {
  border-top:2px solid  #ff4081;
  top: 335px;line-height:35px;
  text-align: center;
  right: 50%;background:#fff; border-radius:0 0 0 10px;
  width: 35%;    z-index: 1000;
  position: absolute;
  color: #ff4081;
}
</style>
<style>
/**/
.picker-item{ color: #666666;}
.picker-selected{ color: #333; font-weight: bold;}
.picker {
    padding: 0; border-radius:10px;
    overflow: hidden;
    height: 170px;
    position: fixed;
    background: #fff;
    z-index: 200;
    top: 200px;
    width: 70%;
    left: 15%;}
.pickint .picker-item {
    line-height: 20px !important;
    min-height:  45px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.pickint .picker-center-highlight{border-top: 1px solid #666666;border-bottom: 1px solid #666666;margin-top: -92px !important; height:42px;}
/*列表选择框*/
.pickerday .picker{height: 170px;}
.pickerday .picker-items{display: flex;overflow: hidden;}
.pickerday .picker-toolbar{background-color: #fff; display:flex; border-bottom: 2px solid #ff4081}
.pickerday .picker-toolbar .mint-datetime-cancel{border-right: 1px solid #cecece;}
.v-modal{    background-color: #000;
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    opacity: 0.5;}
.pickerday .mint-datetime-action{line-height:30px; width: 50%;text-align: center;}
.pickerday .picker-center-highlight{ position:fixed; height: 36px;
    margin-top: 33px !important;
    width: 100%;border-top: 1px solid #666666;border-bottom: 1px solid #666666;}
.pickerday .picker-slot{margin-top:-72px;}
.mint-button{ border: none; background:none;}
.mint-button:focus, input:focus{outline: none;   background-color: transparent;}
.mint-button:-webkit-autofill, input:-webkit-autofill { box-shadow: 0 0 0px 1000px white inset !important;}
</style>
<script type="text/babel">
import CryptoJS from "crypto-js";
export default {
  data() {
    return {
      ToImgurl: '',
      organizesolt: [{
                     flex: 1,
                     values: [],
                     className: 'slot1'
                   }], //组织列表选项初始值
      organizeid: [], //组织列表id初始值
      orgaH:  45, //picker滚动高度
      Politicsolt: [{
                       flex: 1,
                       values: [],
                       className: 'slot1'
                     }], //政治面貌列表选项初始值
      Politicsid: [], //政治面貌列表id初始值
      organizeTxt: "（必填）",//组织
      Nameinfo: "（必填）", //姓名
      PoliticsTxt: "党员",
      topColor: 0,
      twoColor: 0,
      reasonColor: 0,
      inputIndex: 0,
      reasonTxt: "", //姓名的input框
      reasonID: "", //证件号的input框
      reasonOrigin: "", //籍贯的input框
      reasonAdd: "", //地址input框
      reasonDut: "", //职务input框
      IDinfo: "", //证件
      Origin: "", //籍贯
      Homeadd: "", //地址
      PDuties: "", //职务
      value4: null,
      Jointimetxt: "", //加入时间
      Beworktimetxt: "", //转正时间
      Paytimetxt: "", //缴费时间
      count: "测试",
      mess: "ceshi",
      visible4: false,
    };
  },
  methods: {
    onOrganChange(picker, values){
        this.organize = values[0];
        for(var i=0;i<this.organizesolt[0].values.length;i++)
            {        
               if(this.organizesolt[0].values[i]==  this.organize){
                 this.olist = this.organizeid[i]; //获取相应的列表id
               }  
            }
      },//公司组织picker
      onPolitChange(picker, values){
        this.Politics = values[0];
        for(var i=0;i<this.Politicsolt[0].values.length;i++)
            {        
               if(this.Politicsolt[0].values[i]== this.PoliticsTxt){
                 this.Poid = this.Politicsid[i]; //获取相应的列表id
               }  
            }//政治面貌picker
      },
      open(picker) {
        this.$refs[picker].open();
      },
     joinChange(value) {//加入时间
         var d = value;  
         var timeStr=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
         this.Jointimetxt=timeStr
      },
     beworkChange(value) {//转正时间
         var d = value;  
         var timeStr=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
         this.Beworktimetxt=timeStr
      },
     payChange(value) {//缴费日期
         var d = value;  
         var timeStr=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
         this.Paytimetxt=timeStr
      },
    inputName(n) {
      this.flex=true
      this.inputIndex = n;
    },//加入输入内容
    enterbtn(n) { //手写的输入内容检测
        this.inputIndex = 0;
      if (n == 1) {
        var a = this.reasonTxt.replace(/s+/g, ""); //名字
        var c = this.reasonOrigin.replace(/s+/g, ""); //户口
        var d = this.reasonAdd.replace(/s+/g, ""); //住址
        var e = this.reasonDut.replace(/s+/g, ""); //党内职务
        if (a != "") {
          this.reasonColor = 1;
          this.Nameinfo = a;
        } else {
          this.reasonColor = 0;
          this.Nameinfo = "（必填）"; //姓名为必填
        }
        if (c != "") {
          this.Origin = c;
        }
        if (d != "") {
          this.Homeadd = d;
        }
        if (e != "") {
          this.PDuties = e;
        }
      } else if (n == 2) {
        var b = this.reasonID.replace(/s+/g, ""); //身份证号
        var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/; //身份证号检测
        if (b != "" && b.search(reg) === 0) {
          this.IDinfo = b;
          this.reasonColor = 1;
        } else {
          this.Msgtxt("无效证件号");
        }
      }else if(n==3){
         this.topColor=1
         this.organizeTxt =  this.organize
         this.ORGid = this.olist; //获取相应的列表id
        // console.log(this.ORGid)
      }else if(n==4){
         this.PoliticsTxt = this.Politics;
         this.POLIid = this.Poid; //获取相应的列表id
          //console.log(this.POLIid)
      }
    },
    closebtn(n) { //取消输入
      this.flex=false
      var Name = this.Nameinfo.replace(/s+/g, "");
      this.inputIndex = 0;
      if (Name != "（必填）") {
        this.reasonColor = 1;
        this.Nameinfo = Name;
        this.reasonTxt = Name;
      } else {
        this.reasonColor = 0;
        this.reasonTxt = "";
      }
    },
    changeColor(n) {
      if (n == 1) {
        return "change-black";
      }
    },
    saveInfo() {
      var me = this;
      if (me.PoliticsTxt == "群众") {  //若选择为群众则提交以下数据接口
        var postcode = me.toParams({
          APP_USER_ID: me.$route.params.userID, 
          DEPT_ID: me.ORGid,
          NAME: me.Nameinfo,
          IDENTITY_CARD: me.IDinfo,
          POLITICAL_STATUS: me.POLIid,
          REGISTERED_RESIDENCE: me.Origin,
          HOME_ADDRESS: me.Homeadd
        });
      } else {
        var postcode = me.toParams({ //若选择为党员则提交以下数据接口
          APP_USER_ID: me.$route.params.userID,
          DEPT_ID: me.ORGid,
          NAME: me.Nameinfo,
          IDENTITY_CARD: me.IDinfo,
          POLITICAL_STATUS: me.POLIid,
          REGISTERED_RESIDENCE: me.Origin,
          HOME_ADDRESS: me.Homeadd, 
          JOIN_PARTY_TIME: me.Jointimetxt,
          FULL_TIME: me.Beworktimetxt,
          INNER_PARTY_POST: me.PDuties
        });
      }
      var POST_SAVE = me.imgdoc+"/appregister/appparticularadd?" + postcode;
      me.$http({
          method: "post",
          url: POST_SAVE,
          headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp":  Date.now().toString(),
                     "sign": CryptoJS.MD5( Date.now().toString() + me.USER_ID + me.token + '/zhdj/appregister/appparticularadd')+''
                      }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
            var loginmsg = ret.body.MSG ; //连接成功获取返回提示信息
            var codenum = ret.body.CODE; //获取提交后的code
            if (codenum === "1") { //成功提交后跳转首页
                me.Msgtxt(loginmsg);
                me.$router.push({name:'Home'})
              } else { //提交失败，弹出失败信息
               me.Msgtxt(loginmsg);
                // me.mess=POST_SAVE;
              }
          },ret => {
            //请求失败
           me.Msgtxt("服务器请求失败！");
          }
        );
    },
  }, //methods end
  created() {
     var me=this
     var userDATA= localStorage.getItem("userDATA")   //获取用户信息
     var USER= JSON.parse(userDATA)    //编译用户信息
     me.USER_ID= USER.DATA.USER_ID   //在用户信息中获取id
     me.token=localStorage.getItem("token")
     me.ToImgurl=me.ImageUrl ('icon/mipmap-mdpi/icon_enter.png')
     me.$http({
          method: "post",
          url: me.showdoc+"/appregister/appparticular",
          headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": Date.now().toString(),
                     "sign": CryptoJS.MD5(Date.now().toString() + me.USER_ID + me.token + '/zhdj/appregister/appparticular')+''
                   }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(res => {//请求成功
              console.log("服务器请求成功！");
              console.log(res.body)
              var tokenkey = res.headers.map.key // 获取token
              if( tokenkey != undefined&& tokenkey != '' ){
                 var savetoken=me.aesDecrypt(tokenkey.toString())
                 localStorage.setItem("token",savetoken) //储存更新token
                 console.log('存档');
              }else if(res.body.CODE!=1){
                me.Msgtxt(res.body.CODE.MSG);
              }
              for (var i = 0; i < res.body.DATA.RETLIST.length; i++) {
                //获取组织列表，转换成单个值的列表
                me.organizesolt[0].values.push(res.body.DATA.RETLIST[i].NAME);
                me.organizeid.push(res.body.DATA.RETLIST[i].DEPARTMENT_ID);
              }
              for (var i = 0; i < res.body.DATA.DICLIST.length; i++) {
                //获取政治面貌列表
                me.Politicsolt[0].values.push(res.body.DATA.DICLIST[i].NAME);
                me.Politicsid.push(res.body.DATA.DICLIST[i].DICTIONARIES_ID);
                }
            //  console.log(me.organizesolt[0].values)
              me.POLIid = res.body.DATA.DICLIST[0].DICTIONARIES_ID;
            },res => {
            //请求失败
           me.Msgtxt("服务器请求失败！");
          }
        );
    }
};
</script>




