<template>
  <div class="wrapper" >    
    <list-header :title="title"></list-header>
     <div  class="main-page"  offset-accuracy="300px">
         <div class="infortext">
           <div class="info-row">
              <div class="infotitle" @click="inputphoto(n)">头像</div>
              <div class="infocon2"><img class="photobox" :src='photo'/></div>
              <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row"  @click="inputName(1)">
              <div class="infotitle">所属组织</div>
              <div class="infocon">{{organizeTxt}}</div>
              <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(2)">
              <div class="infotitle">姓名</div>
              <div class="infocon" >{{Nameinfo}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(3)">
              <div class="infotitle">身份证号</div>
              <div class="infocon">{{IDinfo}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(4)">
              <div class="infotitle">性别</div>
              <div class="infocon">{{sex}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(5)">
              <div class="infotitle">民族</div>
              <div class="infocon">{{Nation}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row">
              <div class="infotitle">出生日期</div>
               <mt-button  class="infocon" @click.native="inputName()" size="large">{{Birthday}}</mt-button>
<!-- open('Birthtime') -->
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(7)">
              <div class="infotitle">籍贯</div>
              <div class="infocon">{{PlaceOrigin}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(8)">
              <div class="infotitle">政治面貌</div>
              <div class="infocon">{{PoliticsTxt}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(9)">
              <div class="infotitle">户口所在地</div>
              <div class="infocon">{{Origin}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row">
              <div class="infotitle">何时来公司</div>
              <mt-button  class="infocon" @click.native="inputName()" size="large">{{JoinIn}}</mt-button>
              <!-- open('cometime') -->
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(11)">
              <div class="infotitle">婚姻状况</div>
              <div class="infocon">{{Marriage}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(12)">
              <div class="infotitle">学历</div>
              <div class="infocon">{{Education}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(13)">
              <div class="infotitle">学位</div>
              <div class="infocon">{{Degree}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(14)">
              <div class="infotitle">毕业院校</div>
              <div class="infocon">{{GraduateSchool}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row">
              <div class="infotitle">联系电话</div>
              <div class="infocon" @click="inputName(15)">{{Phone}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(16)">
              <div class="infotitle">QQ</div>
              <div class="infocon">{{QQ}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(17)">
              <div class="infotitle">电子邮箱</div>
              <div class="infocon">{{Email}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row">
              <div class="infotitle">入党时间</div>
             <mt-button  class="infocon" @click.native="inputName()" size="large">{{Jointimetxt}}</mt-button>
             <!-- open('jointime') -->
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row">
              <div class="infotitle">转正时间</div>
               <mt-button  class="infocon" @click.native="inputName()" size="large">{{Beworktimetxt}}</mt-button>
               <!-- open('Beworktime') -->
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(20)">
              <div class="infotitle">党内职务</div>
              <div class="infocon">{{PDuties}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(21)">
              <div class="infotitle">行政职务</div>
              <div class="infocon">{{Duties}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(22)">
              <div class="infotitle">现单位党组织</div>
              <div class="infocon">{{NowOrg}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(23)">
              <div class="infotitle">现单位地址</div>
              <div class="infocon">{{Companyadd}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(24)">
              <div class="infotitle">单位邮政编码</div>
              <div class="infocon">{{CompanyPostcode}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(25)">
              <div class="infotitle">常住地址</div>
              <div class="infocon">{{Homeadd}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(26)">
              <div class="infotitle">常住地详址</div>
              <div class="infocon">{{Homeadddetail}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="info-row" @click="inputName(27)">
              <div class="infotitle">常住地邮政编码</div>
              <div class="infocon">{{Postcode}}</div>
             <img class="enterimg" resize="contain" :src="ToImgurl" />
            </div>
            <div class="savebg">
            <!-- <div class="Savebox" >
              <div class="Saveinfo"  @click="check()">
              <div class="savetext">保存修改</div>
              </div>
              </div> -->
            </div>
         </div>
         <!-- <text >{{text}}</text> -->
     </div>
     <div v-if="inputIndex != 0&& inputIndex != 4&& inputIndex != 11&& inputIndex != 12&& inputIndex != 13"> 
        <div class="floatbg" @click='closebtn'></div>
         <div class="flinput" >
            <input :placeholder='Place' type='text' v-model="reasonTxt" :autofocus="true" class="textarea-show"/>
            <div class='closebtn' @click="closebtn(1)">取消</div>
            <div class="enterbtn" @click="enterbtn(num)">确定</div>
        </div>
    </div>
    <div v-if="inputIndex == 4" > 
        <div class="floatbg"  @click="closebtn(1)"></div>
        <mt-picker class='pickint' :slots="sexsolt" :itemHeight='orgaH'    @change="sexChange" :visible-item-count="3" ></mt-picker>
        <div class='closebtn2' @click="closebtn(1)">取消</div>
        <div class="enterbtn2" @click="enterbtn(4)">确定</div>
    </div>
    <div v-if="inputIndex == 11" > 
        <div class="floatbg"  @click="closebtn(1)"></div>
        <mt-picker class='pickint' :slots="marrisolt" :itemHeight='orgaH'    @change="marriChange" :visible-item-count="3" ></mt-picker>
        <div class='closebtn2' @click="closebtn(1)">取消</div>
        <div class="enterbtn2" @click="enterbtn(11)">确定</div>
    </div>
    <div v-if="inputIndex == 12" > 
        <div class="floatbg"  @click="closebtn(1)"></div>
        <mt-picker class='pickint' :slots="Educasolt" :itemHeight='orgaH'    @change="EducaChange" :visible-item-count="3" ></mt-picker>
        <div class='closebtn2' @click="closebtn(1)">取消</div>
        <div class="enterbtn2" @click="enterbtn(11)">确定</div>
    </div>
    <div v-if="inputIndex == 13" > 
        <div class="floatbg"  @click="closebtn(1)"></div>
        <mt-picker class='pickint' :slots="Degreesolt" :itemHeight='orgaH'    @change="DegreeChange" :visible-item-count="3" ></mt-picker>
        <div class='closebtn2' @click="closebtn(1)">取消</div>
        <div class="enterbtn2" @click="enterbtn(11)">确定</div>
    </div>
     <mt-datetime-picker class='pickerday' ref="jointime" type="date" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日"  @confirm="joinChange"></mt-datetime-picker>
     <mt-datetime-picker class='pickerday' ref="Beworktime" type="date" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日"  @confirm="beworkChange"></mt-datetime-picker>
     <mt-datetime-picker class='pickerday' ref="Birthtime" type="date" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日"  @confirm="BirthChange"></mt-datetime-picker>
     <mt-datetime-picker class='pickerday' ref="cometime" type="date" year-format="{value} 年" month-format="{value} 月" date-format="{value} 日"  @confirm="comeChange"></mt-datetime-picker>
  </div>
</template>

<script>
import Header from "../../components/listHeader.vue";
import CryptoJS from "crypto-js";
export default {
  components: {
    "list-header": Header
  },
  data() {
     var IDdata=this.$route.params.PERData.LIST  //通过路由获取个人信息数据
     var IDphoto=this.$route.params.PhotoData  //通过路由获取头像
    return {
      text:'-------',
      orgaH:  45, //picker滚动高度
      title: "个人信息",
      inputIndex: 0,
      Place:'123',
      reasonTxt: "",
      num:0,
      SEXitems: ['男', '女'],
      Marryitems:['未婚','已婚'],
      Educasolt:[{
                     flex: 1,
                     values:[],
                     className: 'slot1'
                   }], //学历列表选项初始值,
      Educaid:[],
      EDUid:'',
      Degreesolt:[{
                     flex: 1,
                     values:[],
                     className: 'slot1'
                   }], //学位列表选项初始值,,
      Degreeid:[],
      DEGid:[],
      phonechange:'',
      photo: IDphoto,
      organizeTxt:IDdata.DEPTNAME,
      Nameinfo:IDdata.NAME,
      IDinfo:IDdata.IDENTITY_CARD,
      sexindex:IDdata.SEX,
      Nation:IDdata.ETHNIC ,
      Birthday:IDdata.BIRTHDAY ,
      PlaceOrigin:IDdata.NATIVE_PLACE ,
      PoliticsTxt:IDdata.SNAME ,
      Origin:IDdata.REGISTERED_RESIDENCE ,
      JoinIn:IDdata.START_WORKING_TIME ,
      Marindex:IDdata.IS_MARRIAGE ,
      Marriage:'',
      Education:IDdata.EDUCATION ,
      Degree:IDdata.DEGREE ,
      GraduateSchool:IDdata.GRADUATE_INSTITUTIONS ,
      Phone:IDdata.PHONE ,
      QQ:IDdata.QQ ,
      Email:IDdata.EMAIL ,
      Jointimetxt:IDdata.JOIN_PARTY_TIME ,
      Beworktimetxt:IDdata.FULL_TIME ,
      PDuties:IDdata.INNER_PARTY_POST ,
      Duties:IDdata.ADMINISTRATIVE_DUTY ,
      NowOrg:IDdata.PARTY_ORG ,
      Companyadd:IDdata.WORK_UNIT ,
      CompanyPostcode:IDdata.POSTALCODE ,
      Homeadd:IDdata.HOME_ADDRESS ,
      Homeadddetail:IDdata.HOME_XADDRESS ,
      Postcode:IDdata.HOME_ADDRESSYZ ,
      ToImgurl: '', //箭头icon
      sexsolt: [{
                     flex: 1,
                     values:['男', '女'],
                     className: 'slot1'
                   }], //性别列表选项初始值
      marrisolt: [{
                     flex: 1,
                     values:['未婚', '已婚'],
                     className: 'slot1'
                   }], //性别列表选项初始值
    };
  },
  methods: {
    closebtn(n) { //取消输入
      this.inputIndex = 0;
    },
    sexChange(picker, values){  //性别
        this.sex = values[0];
      },
    marriChange(picker, values){  //婚姻
        this.Marriage = values[0];
      },
    EducaChange(picker, values){  //学位
        this.Education = values[0];
        for(var i=0;i<this.Educasolt[0].values.length;i++)
            {        
               if(this.Educasolt[0].values[i]== this.Education){
                 this.EDUid = this.Educaid[i]; //获取相应的列表id
               }  
            }
      },
    DegreeChange(picker, values){  //学历
        this.Degree = values[0];
        for(var i=0;i<this.Degreesolt[0].values.length;i++)
            {        
               if(this.Degreesolt[0].values[i]== this.Degree){
                 this.DEGid = this.Degreeid[i]; //获取相应的列表id
               }  
            }
      },
     open(picker) {
        this.$refs[picker].open();
      },
     joinChange(value) {//加入时间
         var d = value;  
         var timeStr=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
         this.Jointimetxt=timeStr   
      },
      beworkChange(value) {//转正时间
         var d = value;  
         var timeStr=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
         this.Beworktimetxt=timeStr
      },
      BirthChange(value) {//加入时间
         var d = value;  
         var timeStr=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
         this.Birthday=timeStr   
      },
      comeChange(value) {//转正时间
         var d = value;  
         var timeStr=d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate()
         this.JoinIn=timeStr
      },
    inputName(n) {
       this.Msgtxt('修改信息请下载APP进行操作')
    },
    inputName2(n) {
      var IDdata=this.$route.params.PERData.LIST
      if(n==1||n==8){
         this.Msgtxt("不能修改！")
      }else if(n==11){
        this.inputIndex = 11;
      }else if(n==12){ //学历
      this.inputIndex = 12;
      }else if(n==13){ //学位
      this.inputIndex = 13;
      }else{
      this.inputIndex = n,
      this.num = n
       if(n==2){
        this.Place='姓名',           //信息输入提示
        this.reasonTxt=IDdata.NAME   //获取的信息
      }else if(n==3){
        this.Place='证件号',                  
        this.reasonTxt=IDdata.IDENTITY_CARD  
      }else if(n==5){
        this.Place='民族',            
        this.reasonTxt=IDdata.ETHNIC  
      }else if(n==7){
        this.Place='籍贯',                  
        this.reasonTxt=IDdata.NATIVE_PLACE  
      }else if(n==9){
        this.Place='户口所在地',    
        this.reasonTxt=IDdata.REGISTERED_RESIDENCE  
      }else if(n==14){
        this.Place='毕业学校',    
        this.reasonTxt=IDdata.GRADUATE_INSTITUTIONS  
      }else if(n==15){
        this.Place='联系电话',    
        this.reasonTxt=IDdata.PHONE  
      }else if(n==16){
        this.Place='QQ号码',    
        this.reasonTxt=IDdata.QQ  
      }else if(n==17){
        this.Place='电子邮件',    
        this.reasonTxt=IDdata.EMAIL  
      }else if(n==20){
        this.Place='党内职务',    
        this.reasonTxt=IDdata.INNER_PARTY_POST  
      }else if(n==21){
        this.Place='行政职务',    
        this.reasonTxt=IDdata.ADMINISTRATIVE_DUTY  
      }else if(n==22){
        this.Place='现单位组织',    
        this.reasonTxt=IDdata.PARTY_ORG  
      }else if(n==23){
        this.Place='现单位地址',    
        this.reasonTxt=IDdata.WORK_UNIT  
      }else if(n==24){
        this.Place='单位邮政编码',    
        this.reasonTxt=IDdata.POSTALCODE  
      }else if(n==25){
        this.Place='常住地址',    
        this.reasonTxt=IDdata.HOME_ADDRESS  
      }else if(n==26){
        this.Place='常住地详细地址',    
        this.reasonTxt=IDdata.HOME_XADDRESS  
      }else if(n==27){
        this.Place='常住地邮政编码',    
        this.reasonTxt=IDdata.HOME_ADDRESSYZ  
      }
     }   
    },
    enterbtn(n) {
      if(n==2){
         if(this.reasonTxt.replace(/s+/g, "")!=''){
              this.Nameinfo = this.reasonTxt.replace(/s+/g, "");
         }else{
           this.Msgtxt("姓名不能为空")
         }
      }else if(n==3){
        var b = this.reasonTxt.replace(/s+/g, ""); //身份证号
        var reg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/; //身份证号检测
        if (b != "" && b.search(reg) === 0) {
          this.IDinfo = b;
        } else {
          this.Msgtxt("无效证件号");
        } 
      }else if(n==4){
            this.inputIndex = 4;
            if(this.sex=='男'){
                this.sexindex=1
             }else{
                this.sexindex=2
             }
      }else if(n==5){ //民族
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.Nation = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==7){ //籍贯
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.PlaceOrigin = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==9){ //户口所在 
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.Origin = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==11){
        if(this.Marriage=='未婚'){
                this.Marindex=0
             }else{
                this.Marindex=1
             }
      }else if(n==14){ //毕业学校  
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.GraduateSchool = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==15){   //联系电话
         if(this.reasonTxt.search(/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/) == 0){
            this.Phone = this.reasonTxt;
            this.phonechange=1
         }else{
            this.Msgtxt("号码格式不对")
         }
      }else if(n==16){ // QQ号码
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.QQ = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==17){ //电子邮件
         if(this.reasonTxt !=''){
            this.Email = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==20){ //党内职务
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.PDuties = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==21){ //行政职务
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.Duties = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==22){ //现单位组织
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.NowOrg = this.reasonTxt;

         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==23){ //现单位地址
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.Companyadd = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==24){ //单位邮政编码
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.CompanyPostcode = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==25){ //常住地址
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.Homeadd = this.reasonTxt;
         }else{
          //  this.Msgtxt("不能为空")
         }
      }else if(n==26){ //常住地详细地址
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.Homeadddetail = this.reasonTxt;
         }else{ //
          //  this.Msgtxt("不能为空")
         }
      }else if(n==27){ //常住地邮政编码
         if(this.reasonTxt.replace(/s+/g, "")!=''){
            this.Postcode = this.reasonTxt;
         }else{ 
          //  this.Msgtxt("不能为空")
         }
      }
      this.inputIndex = 0;//关闭输入框
    },
    check(){
    var me = this
    var POSTinfor=me.toParams({ //数据提交接口
          APP_USER_ID: '7bff251a5ec24f118f2f2ffdcd50049a',//IDdata.LIST.APP_USER_ID,
          ISAMEND:me.phonechange,
          NAME: me.Nameinfo,
          IDENTITY_CARD: me.IDinfo ,
          SEX: me.sexindex ,
          ETHNIC: me.Nation ,
          BIRTHDAY: me.Birthday ,
          NATIVE_PLACE: me.PlaceOrigin ,
          REGISTERED_RESIDENCE: me.Origin ,
          START_WORKING_TIME: me.JoinIn ,
          IS_MARRIAGE: me.Marindex ,
          EDUCATION: me.EDUid ,
          DEGREE: me.DEGid ,
          GRADUATE_INSTITUTIONS: me.GraduateSchool ,
          PHONE: me.Phone ,
          QQ: me.QQ ,
          EMAIL: me.Email ,
          JOIN_PARTY_TIME: me.Jointimetxt ,
          FULL_TIME: me.Beworktimetxt ,
          INNER_PARTY_POST: me.PDuties ,
          ADMINISTRATIVE_DUTY: me.Duties ,
          PARTY_ORG: me.NowOrg ,
          WORK_UNIT: me.Companyadd ,
          POSTALCODE: me.CompanyPostcode ,
          HOME_ADDRESS: me.Homeadd ,
          HOME_XADDRESS: me.Homeadddetail ,
          HOME_ADDRESSYZ: me.Postcode ,
        });
    me.token=localStorage.getItem("token")
    me.$http({
          method: "post",
          url: me.imgdoc + "/appregister/appparticularedit?"+ POSTinfor,
          headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp":  Date.now().toString(),
                     "sign": CryptoJS.MD5( Date.now().toString() + me.USER_ID + me.token + '/zhdj/appregister/appparticularedit')+''
                      }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
            var tokenkey = ret.headers.map.key // 获取token
            me.takestate(tokenkey,ret.body.CODE)
            // console.log('get:'+JSON.stringify(ret));
             me.Msgtxt(ret.data.MSG)
          },ret => {
            //请求失败
           me.Msgtxt("服务器请求失败！");
          }
        );
    }
  },
  created(){
      var IDdata=this.$route.params.PERData
   //   console.log(IDdata)
      this.ToImgurl=this.ImageUrl ('icon/mipmap-mdpi/icon_enter.png')
          if(IDdata.LIST.SEX != ''){
              if(IDdata.LIST.SEX == 1 ){
                this.sex='男'
             }else if(IDdata.LIST.SEX == 2 ){
                this.sex='女'
             }
          }  //性别初始值转换
          if(IDdata.LIST.IS_MARRIAGE != ''){
             if(IDdata.LIST.IS_MARRIAGE == 0 ){
                this.Marriage='未婚'
               }else if(IDdata.LIST.IS_MARRIAGE == 1){
                this.Marriage='已婚'
             }
          } //婚姻状况初始值转换
          for (var i = 0; i < IDdata.XLLIST.length; i++) { //获取组织列表，转换成单个值的列表
            this.Educasolt[0].values.push(IDdata.XLLIST[i].NAME);
            this.Educaid.push(IDdata.XLLIST[i].DICTIONARIES_ID);    
           } // 学历
          for (var i = 0; i < IDdata.XWLIST.length; i++) { //获取组织列表，转换成单个值的列表
            this.Degreesolt[0].values.push(IDdata.XWLIST[i].NAME);
            this.Degreeid.push(IDdata.XWLIST[i].DICTIONARIES_ID);    
           } //学位
  },
} 
</script>


<style scoped>
  .info-row {
  background-color: #fff;
  justify-content: space-between;
  align-items: center;
  flex-direction: row;
  padding-right: 10px;
  border-bottom:1px solid #d6d6d6;
  padding-left: 20px; display: flex; height:50px;
}
.infotitle {
  color: #7a7a7a;
  flex: 0.4;
}
.infocon {
  text-align: right;
  color: #333;
  flex: 0.7;
  align-items: right;
}
.enterimg {
  width: 20px;
  height: 20px;
  margin-left:5px;
}
.infocon2 { display: flex;
  flex: 0.7;
  align-items: flex-end;
  justify-content:flex-end;
}
.photobox{ width:30px;height: 30px; border-radius: 80px; }
.floatbg {
  position: fixed;
  height: 100%;
  background-color: #000;
  opacity: 0.6;
  width: 750px;
  top: 0;
}
.flinput {
  position: fixed;
  width:70%;
  height: 130px;
  top: 35%;
  left: 50px;
  border-radius: 10px;
  background-color: #fff;
  border-color: #ccc;
  border-width: 1px;
}
.textarea-show {
  padding:10px;
  background-color: #fff;
  border:none;
  border-bottom: 1px #cecece solid;
  top: 100px;
  margin:40px  10% 0 10%;
  color: #333;    width: 70%;
}
.enterbtn {
  bottom: 15px;
  text-align: center;
  right: 0;
  width: 50%;
  position: absolute;
  color: #ff4081;
}
.closebtn {
  bottom: 15px;
  text-align: center;
  right: 50%;
  width: 50%;
  position: absolute;
  color: #ff4081;
}
.enterbtn2 {
  top:335px; border-top:2px solid  #ff4081;
  text-align: center; line-height:35px;
  right: 15%;
  width: 35%; background:#fff; border-radius:0 0 10px 0;
  position: absolute;    z-index: 1000;
  color: #ff4081;
}
.closebtn2 {
  border-top:2px solid  #ff4081;
  top: 335px;line-height:35px;
  text-align: center;
  right: 50%;background:#fff; border-radius:0 0 0 10px;
  width: 35%;    z-index: 1000;
  position: absolute;
  color: #ff4081;
}
.savebg{background-color: #f2f2f2;padding:30px 0;}
.Savebox {
  justify-content: center;
  align-items: center;}
.Saveinfo {
  width: 80%; 
  background-color: rgb(29, 108, 219);
  margin:0px auto;
  border-radius: 5px;
  justify-content: center;
  align-items: center;
}
.savetext {
   text-align: center;
  color: #fff; font-size: 18px;
  line-height: 50px;
}
</style>
<style>
.picker-item{ color: #666666; text-align:center;}
.picker-selected{ color: #333; font-weight: bold;}
.picker {
    padding: 0; border-radius:10px;
    overflow: hidden;
    height: 170px;
    position: fixed;
    background: #fff;
    z-index: 200;
    top: 200px;
    width: 70%;
    left: 15%;}
.pickint .picker-item {
    line-height: 20px !important;
    min-height:  45px;
    display: flex;
    align-items: center;
    justify-content: center;
}
.pickint .picker-center-highlight{border-top: 1px solid #666666;border-bottom: 1px solid #666666;margin-top: -92px !important; height:42px;}
/*列表选择框*/
.pickerday .picker{height: 170px;}
.pickerday .picker-items{display: flex;overflow: hidden;}
.pickerday .picker-toolbar{background-color: #fff; display:flex; border-bottom: 2px solid #ff4081}
.pickerday .picker-toolbar .mint-datetime-cancel{border-right: 1px solid #cecece;}
.v-modal{    background-color: #000;
    width: 100%;
    height: 100%;
    position: fixed;
    top: 0;
    opacity: 0.5;}
.pickerday .mint-datetime-action{line-height:30px; width: 50%;text-align: center;}
.pickerday .picker-center-highlight{ position:fixed; height: 36px;
    margin-top: 33px !important;
    width: 100%;border-top: 1px solid #666666;border-bottom: 1px solid #666666;}
.pickerday .picker-slot{margin-top:-72px;}
.mint-button{ border: none; background:none;}
.mint-button:focus, input:focus{outline: none;   background-color: transparent;}
.mint-button:-webkit-autofill, input:-webkit-autofill { box-shadow: 0 0 0px 1000px white inset !important;}
</style>