<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="tab-panels" >
            <div class="main-ul" > 
                <resList :items="POST_cjgk"></resList>
            </div>
        </div>
    </div>
</template>
<style scoped>
.tab-panels{
    position: fixed;
    width: 750px;
    top: 35px;
    bottom: 0px;
    left: 0;
    right: 0;
    /* transition: left 0.2s ease-in-out; */
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import resList from '../../components/list/resList.vue';
    export default {
        components: {
            'list-header': Header,
            'resList': resList,
        },
        data () {
            return {
                loadinging: false,
                refreshing: false,
                title:'成绩公开',
                POST_cjgk:'/appocourses/cjgkList',
                tablise:{
                    activeTab: 0,
                    tabNum:1,  //这里是tab个数，tab大于1时必填
                    tabWidth:375,  //这里是tab宽度，建议：tab=2时，tabWidth=375； tab=3时，tabWidth=250；
                    tabs: [
                        {NAME: '支部公开',}, 
                        {NAME: '党委公开',}
                     ],
                },
                              
                showLoading: 'hide'
            }
        },
        methods: {
         
        }
    }
        
</script>
