<template>
    <div class="nodatast" >
               <div class="tipimg">
               <img :src="ImageUrl ('icon/mipmap-xhdpi/ic_no_msg.png')"/>
               <div class='nomstxt'>没有新的数据</div>
               </div>
           </div>
</template>
<style>
.nodatast{ position: relative;height: 90%;}
.tipimg{ position: absolute; top:50%; left: 50%; margin-left: -42px; margin-top:-60px; text-align: center}
.nomstxt{ font-size: 14px; line-height: 50px;}
.tipimg img{ height: 60px;}
</style>

