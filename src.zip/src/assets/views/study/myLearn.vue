<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <tabTop :tablise="tablise" v-if="tablise.tabNum>1"></tabTop>
        <div  :class="['tab-panels', tablise.tabNum==1?'nottabtop':'']">
            <div class="main-ul">
                <tabList :items="onclass" v-if="tablise.activeTab==0"></tabList>
                <div class="main-li" v-if="tablise.activeTab==1">
                    <iframe  class="webview_zxcp" :src="POST_cjcx"></iframe>
                </div>
            </div>
        </div>
        <!-- <text>{{onclass}}</text> -->
    </div>
</template>
<style scoped>
.tab-panels{
    position: fixed;
    width: 100%;
    top: 77px;
    bottom: 0px;
    left: 0;
    right: 0; overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.nottabtop{
    top: 50px;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
    justify-content:flex-start;

}
.hide{display: none;}
.showclass{display: block}
.main-li{
    width: 100vw; height: 100%;
    overflow-y: scroll;
    padding-left: 0;
    flex-direction: row;
    justify-content:flex-start;
    background-color: #fff;
    float: left;
}
.webview_zxcp{
    position:relative ;
    width: 100vw;
    height: 100%;
    top: 0px;
    bottom: 0;
    border: none;
}
.kejie{padding-top: 20px;padding-bottom: 20px;padding-left: 20px;padding-right: 20px;font-size: 28px;}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import tabTop from '../../components/tabTop.vue';
    import tabList from '../../components/list/courseList.vue';
    export default {
        components: {
            'list-header': Header,
            'tabTop':tabTop,
            'tabList': tabList,
        },
        data () {
            var me=this;
            return {
                loadinging: false,
                refreshing: false,
                title:me.$route.params.title,
                // POST_cjcx:'/appexam/cjcx',
                 POST_cjcx:'http://www.baidu.com/', //服务器链接不可用，链接百度测试
                onclass:{
                        POST_onclass:'/appocourses/dkxxList?PARENT_ID=',
                        ify_url:'courseList',
                        POST_onclass_head:'/zhdj/appocourses/dkxxList'
                },
                tablise:{
                    activeTab: 0,
                    tabNum:2,  //这里是tab个数，tab大于1时必填
                    tabWidth:'50',  //这里是tab宽度，建议：tab=2时，tabWidth=375； tab=3时，tabWidth=250；
                    tabs: [
                        {NAME: '课程文章',},
                        {NAME: '学习成绩', }
                     ],
                    textItems: {
                        items:[
                        ],
                    },
                },
            }
        },
        created: function() {
            var me = this;
         //   me.POST_cjcx = me.showdoc+me.POST_cjcx+'?USER_ID='+me.myuser;
        },
        methods: {
        }
    }
        
</script>

