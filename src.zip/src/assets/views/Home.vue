<template>
<div  class="wrapper">
    <home-header :title="title"></home-header>
        <div class="contenter">
          <mt-loadmore :top-method="loadTop" :autoFill='autof' @top-status-change="handleTopChange" :bottom-method="loadBottom" @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="textbox">
            <!-- -->
             <div class="sliderbox">
                <indslider class="slider" :indBanners="indBanners"></indslider>
                <!-- <div class="slider" @click="jump('HelloWorld')">helloworld</div> -->
             </div>
             <div class="cell-button bord_bottom">
               <item-top :topics="topics"></item-top>       
             </div>
             <!-- <div>{{text}}{{txt}}</div> -->
            <div class="box">  
               <newList :items="post_newList"></newList>
             </div>
             <div slot="top" class="loadmore-top">
               <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
               <span v-show="topStatus === 'drop'">释放加载</span>
               <span v-show="topStatus === 'loading'">正在加载....</span>
             </div>
             <!--下拉加载提示-->
        <div slot="bottom" class="loadmore-bottom">
          <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
          <span v-show="bottomStatus === 'loading'">加载中...</span>
        </div>
           </mt-loadmore> 
        </div>
    <tabNav :active="active"/>
</div>
</template>
<style scoped>
.contenter {
   position: fixed; top:35px; bottom: 63px; left: 0;right: 0; overflow-y:auto;overflow-x:hidden;   width: 100%;-webkit-overflow-scrolling: touch;
}
.cell-button {
  padding-bottom: 10px; width: 100%; overflow: hidden;
}
</style>

<script>
import Header from "../components/Header.vue";
import itemTops from "../components/itemTops.vue";
import tabNav from "../components/tabNav.vue";
import newList from "../components/commonList.1.vue";
import indslider from './home/indBanner.vue';
import CryptoJS from "crypto-js";
export default {
  components: {
    "home-header": Header,
    "item-top": itemTops,
    "indslider":indslider,
    "newList": newList,
    "tabNav": tabNav
  },
  data() {
    return {
      topStatus: "",
      active: 1,
      title: "首  页",
      timestamp :Date.now().toString(),
      USER_ID: '',
      token:'',
      indBanners: [
                    { title: '', src: this.ImageUrl('img1.jpg'), url:'myLearn', id:'19'},
                    { title: '', src: this.ImageUrl('img2.jpg'), url:'myLearn',id:'11'},
                    { title: '', src: this.ImageUrl('img3.jpg'), url:'myLearn',id:'199'},
                    { title: '', src: this.ImageUrl('img4.jpg'), url:'myLearn',id:'000'}
                ],
      topics: [
                    {name:'党政要闻',img:this.ImageUrl("icon/mipmap-mdpi/home_dzyw.png"),url:'partyNew'},
                    {name:'通知公告',img:this.ImageUrl("icon/mipmap-mdpi/home_tzgg.png"),url:'partyNew'},
                    {name:'三会一课',img:this.ImageUrl("icon/mipmap-mdpi/home_whhd.png"),url:'partyNew'},
                    {name:'文化活动',img:this.ImageUrl("icon/mipmap-mdpi/home_hdjl.png"),url:'partyNew'},
                    {name:'文化活动',img:this.ImageUrl("icon/dyxs.png"),url:'partyNew'}
                ],  //图标栏目数据绑定值
      post_newList: [
        {id:'001',img_url:this.ImageUrl("icon/demo_1.jpg"),title:"不忘初心牢，记使命新闻学习专题",publish_date:'2020年8月1日'},
        {id:'002',img_url:this.ImageUrl("img1.jpg"),title:"实时更新：新型冠状肺炎全国疫情地图",publish_date:'2020年9月1日'},
        {id:'003',img_url:this.ImageUrl("img2.jpg"),title:"美大学限期驱逐中国公费留学生 外交部回应",publish_date:'2020年8月21日'},
        {id:'004',img_url:this.ImageUrl("img3.jpg"),title:"张国清任辽宁省委书记 袁家军任浙江省委书记",publish_date:'2020年8月17日'},
        {id:'005',img_url:this.ImageUrl("img4.jpg"),title:"全国地方志2020年卷综合年鉴已启动编纂3205种",publish_date:'2020年8月12日'},
        {id:'006',img_url:this.ImageUrl("img1.jpg"),title:"中国海事局：黄海南部9月2日至4日进行实弹演习",publish_date:'2020年8月10日'},
        {id:'007',img_url:this.ImageUrl("img2.jpg"),title:"陕西镇安中学问题整改完成 9月1日正常开学",publish_date:'2020年8月6日'}
        ], //文章列表
      postResult: "", //数据获取结果
      myused: "", //用户id
      alllist: "", //文章总数
      listcount: 10, //文章加载数
      allLoaded: false,
      autof:false,
      bottomStatus: '',
      loadingmsg:'上拉加载',
      //----测试值↓↓↓
      text: "----",
    };
  },
  methods: {
    datalist() {
      var me = this;
      //首页文章列表数据
      me.myused = 63;
      var POST_URL = me.showdoc + "/appindex/getIndexList?DEPT_ID=" + me.myused;
      var POST_lunBo = me.showdoc + "/appindex/LunBo?DEPT_ID=" + me.myused;
      var POST_lanmu = me.showdoc + "/appindex/columnList?DEPT_ID=" + me.myused;
      me.text= me.dataget(POST_URL)
      me.token=localStorage.getItem("token")
      me.$http({ //获取幻灯片数据
          method: "post",
          url: POST_lunBo,
          headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": me.timestamp,
                     "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appindex/LunBo')+''
                   }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
            var tokenkey = ret.headers.map.key // 获取token
             me.takestate(tokenkey,ret.body.CODE) 
           //  me.indBanners = ret.body.DATA;   
          },ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
      me.$http({ //获取首页新闻列表数据
          method: "post",
          url: POST_URL,
          headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": me.timestamp,
                     "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appindex/getIndexList')+''
                     }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
          var tokenkey= ret.headers.map.key // 获取token
            me.takestate(tokenkey,ret.body.CODE) 
               me.post_newList = ret.body.DATA.result;
               me.alllist = ret.body.DATA.totalResult;
          },
          ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
      me.$http({  //获取首页图标列表数据
          method: "post",
          url: POST_lanmu,
          headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": me.timestamp,
                     "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appindex/columnList')+''
                      }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then( ret => { //请求成功
         var tokenkey = ret.headers.map.key // 获取token
         me.takestate(tokenkey,ret.body.CODE)
            me.topics = ret.body.DATA;
            me.topics[0].img = me.ImageUrl("icon/mipmap-mdpi/home_dzyw.png");
            me.topics[1].img = me.ImageUrl("icon/mipmap-mdpi/home_tzgg.png");
            me.topics[2].img = me.ImageUrl("icon/mipmap-mdpi/home_whhd.png");
            me.topics[3].img = me.ImageUrl("icon/mipmap-mdpi/home_hdjl.png");
            me.topics[4].img = me.ImageUrl("icon/dyxs.png");
            me.topics[0].url = "partyNew";
            me.topics[1].url = "partyNew";
            me.topics[2].url = "partyNew";
            me.topics[3].url = "partyNew";
            me.topics[4].url = "partyNew";
          },
          ret => {
            //请求失败
            me.Msgtxt("服务器请求失败！");
          }
        );
    },
    handleTopChange(status) {  //调用刷新提示
      this.topStatus = status;
    },
    loadTop() {  //下拉刷新
      setTimeout(() => {
        this.listcount = 10; //重置条数
        this.loadingmsg='上拉加载'
      //  this.datalist(); //重新加载数据
        this.allLoaded = false;  //再次启动加载
        this.$refs.loadmore.onTopLoaded();
        this.Msgtxt("刷新成功！")
      }, 2000);
    },
    handleBottomChange(status) { //调用加载提示
        this.bottomStatus = status;
      },
    loadBottom() {  //上拉加载
        this.token=localStorage.getItem("token")
        setTimeout(() => {
            var me = this;
      if (me.alllist - me.listcount > 0) {
          me.listcount = me.listcount + 10;
         //  console.log(me.listcount);
          me .$http({
              //获取幻灯片数据
              method: "post",
              url: me.showdoc + "/appindex/getIndexList?DEPT_ID=" + me.myused + "&SHOWCOUNT=" + me.listcount,
              headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                         "token": me.token == undefined ? '' : me.token,
                         "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                         "timestamp": me.timestamp,
                         "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appindex/getIndexList')+'' }, //新增加
              credientials: false,
              emulateJSON: true
            }).then(ret => { //请求成功                
                 me.post_newList = ret.body.DATA.result;
              },
              ret => {  //请求失败
               me.Msgtxt("服务器请求失败！");
              }
            );
       }else {
            me.allLoaded = true;
            me.loadingmsg='已经到底了'
           } 
            me.$refs.loadmore.onBottomLoaded();  
        }, 1500);
      },
  },
  created: function() {
    //  this.datalist(); //调用加载数据方法   
  }
};
</script>
