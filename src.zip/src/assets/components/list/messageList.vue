<template>
<div class="wrapper">
        <list-header :title="title"></list-header>
        <!-- <tabTop :tablise="tablise" v-if="tablise.tabNum>1"></tabTop> -->
         <div class="main-page">
             <mt-loadmore :top-method="loadTop" :autoFill='autof' @top-status-change="handleTopChange" :bottom-method="loadBottom" @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="textbox">
                <div class="cell-button">
                    <div class="newbox">
                        <div class="newUl">
                            <div class="newLi" v-for="(mmss,i) in mm" :key="i">
                                <div class="newtext" @click="mmss.business_id == ''? jumpTo('messDetail',{title: mmss.title,receive_date:mmss.receive_date,content:mmss.content,msid: mmss.sub_id}) : jumpTo('newDetail',{id: mmss.business_id.substring(9)});messtate(mmss.sub_id)">
                                    <div class="new-tips" v-if='mmss.status!=2'>未读</div>
                                    <div class="new-title">{{mmss.title}}</div>
                                    <div class="mass_source">{{mmss.content}}</div>
                                    <div class="date-div">
                                        <div class="date-icomi">
                                        <img class="date-ico" :src="srclink"/>
                                        </div>
                                        <div class="new-date" >{{mmss.receive_date.substr(0,11)}}</div>
                                    </div>
                                </div>
                            </div>
                            <!-- <div>{{mm}}{{POST_masslist}}</div> -->
                        </div> 
                    </div>
                </div>
                <div slot="top" class="loadmore-top">
                    <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
                    <span v-show="topStatus === 'drop'">释放加载</span>
                    <span v-show="topStatus === 'loading'">正在加载....</span>
                    </div>
                    <!--下拉加载提示-->
                <div slot="bottom" class="loadmore-bottom">
                <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
                <span v-show="bottomStatus === 'loading'">加载中...</span>
                </div>
            </mt-loadmore>
     </div>
</div>        
</template>
<style scoped>
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
.main-li{width: 100%;}
.newUl{display: block;}
.newLi:first-child{border-top-color:#ccc; border-top-width: 1px;border-top-style: solid;}
.newLi{ border-bottom-color: #ccc;border-bottom-width: 1px;border-bottom-style: solid; padding: 10px 15px;display: flex; justify-content:space-between;  flex-direction:row;}
.new-imgdiv{flex: 1; }
.new-img{ height: 150px;border: 1px solid #e8e8e8;}
.newtext{ flex: 2.5; position: relative;}
.new-title{
    font-size: 16px;
    color: #000;
    margin-bottom: 5px;
}
.new-date{
    font-size: 14px;
    color: #555;
    flex:14;
    margin-left: 10px;
    padding-top:2px;
}
.date-div{
    display: flex; justify-content:space-between;  flex-direction:row;
}
.date-icomi{
    flex:1;
}
.date-ico{
    width:20px;
    height:20px;
}
.mass_source{color:#555;font-size: 14px;margin-bottom: 5px;}
.new-tips{border: #da0000 1px solid;
    border-radius: 5px;
    font-size: 12px;
    position: absolute;
    right: 10px; top:2px;
    padding: 0 6px; 
    color: #da0000;}
</style>

<script>
    import CryptoJS from "crypto-js";
    import Header from '../listHeader.vue';
    export default {
        components: {
            'list-header': Header,
        },
        data () {
            return {
                title:'消息中心',
                loadinging: false,
                refreshing: false,
                postResult:'',
                alllist:'',//文章总数
                listcount:10,//文章加载数
                last:false,
                showLoading: 'hide',
                srclink:this.ImageUrl('icon/status_shenhe.png'),
                POST_masslist:'',
                POST_data:'',
                mm:[{business_id:'001',title:'消息测试',receive_date:'2020年9月25日',content:'1消息传送测试，信息文章列表1',sub_id:'223',status:'2'},
                {business_id:'002',title:'消息测试',receive_date:'2020年9月25日',content:'2消息传送测试，信息文章列表1',sub_id:'224',status:'1'},
                {business_id:'003',title:'消息测试',receive_date:'2020年9月25日',content:'3消息传送测试，信息文章列表1',sub_id:'225',status:'1'},
                {business_id:'004',title:'消息测试',receive_date:'2020年9月25日',content:'4消息传送测试，信息文章列表1',sub_id:'225',status:'1'},
                {business_id:'005',title:'消息测试',receive_date:'2020年9月25日',content:'5消息传送测试，信息文章列表1',sub_id:'225',status:'1'},
                {business_id:'006',title:'消息测试',receive_date:'2020年9月25日',content:'6消息传送测试，信息文章列表1',sub_id:'225',status:'1'},
                {business_id:'007',title:'消息测试',receive_date:'2020年9月25日',content:'7消息传送测试，信息文章列表1',sub_id:'225',status:'1'},
                {business_id:'008',title:'消息测试',receive_date:'2020年9月25日',content:'8消息传送测试，信息文章列表1',sub_id:'225',status:'1'},
                {business_id:'009',title:'消息测试',receive_date:'2020年9月25日',content:'9消息传送测试，信息文章列表1',sub_id:'225',status:'1'},
                {business_id:'0010',title:'消息测试',receive_date:'2020年9月25日',content:'10消息传送测试，信息文章列表1',sub_id:'225',status:'1'}],
                mmlist:[],
                allLoaded: false,
                autof:false,
                bottomStatus: '',
                loadingmsg:'上拉加载',
            }
        },
        created: function() {
         //   this.datalist() //调用加载数据方法
        },
        methods: {
            datalist(){
            var me = this;
            me.token=localStorage.getItem("token")
            me.POST_masslist = me.showdoc+'/appmessage/list?USER_ID='+me.myuser
            //活动列表数据
            me.$http({
          method: "post",
          url: me.POST_masslist,
          headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": me.timestamp,
                     "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appmessage/list')+''
                   }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
            var tokenkey = ret.headers.map.key // 获取token
             me.takestate(tokenkey,ret.body.CODE)
             me.alllist=ret.data.DATA.totalResult;
             me.mm=ret.data.DATA.result
             // console.log(ret.body.DATA.result)
          },ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
            },
            handleTopChange(status) {  //调用刷新提示
      this.topStatus = status;
    },
    loadTop() {  //下拉刷新
      setTimeout(() => {
        this.listcount = 10; //重置条数
        this.loadingmsg='上拉加载'
      //  this.datalist(); //重新加载数据
        this.allLoaded = false;  //再次启动加载
        this.$refs.loadmore.onTopLoaded();
        this.Msgtxt("刷新成功！")
      }, 2000);
    },
    handleBottomChange(status) { //调用加载提示
        this.bottomStatus = status;
      },
    loadBottom() {  //上拉加载
        this.token=localStorage.getItem("token")
        setTimeout(() => {
            var me = this;
      if (me.alllist - me.listcount > 0) {
          me.listcount = me.listcount + 10;
          me .$http({
              method: "post",
              url: me.POST_masslist+"&SHOWCOUNT=" + me.listcount,
              headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                         "token": me.token == undefined ? '' : me.token,
                         "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                         "timestamp": me.timestamp,
                         "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appmessage/list')+'' }, //新增加
              credientials: false,
              emulateJSON: true
            }).then(ret => { //请求成功  
                me.mm = ret.body.DATA.result;
              },
              ret => {  //请求失败
               me.Msgtxt("服务器请求失败！");
              }
            );
       }else {
            me.allLoaded = true;
            me.loadingmsg='已经到底了'
           } 
            me.$refs.loadmore.onBottomLoaded();  
        }, 1500);
      },
      messtate(messid){  //修改未读状态
        //   var me = this;
        //     me.token=localStorage.getItem("token")
        //     me.POST_masslist = me.showdoc+'/appmessage/editSub?ID='+ messid
        //     //消息修改状态
        //     me.$http({
        //   method: "post",
        //   url: me.POST_masslist,
        //   headers: { "Content-Type": "application/x-www-form-urlencoded" ,
        //              "token": me.token == undefined ? '' : me.token,
        //              "userid": me.USER_ID == undefined ? '' : me.USER_ID,
        //              "timestamp": me.timestamp,
        //              "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appmessage/editSub')+''
        //            }, //新增加
        //   credientials: false,
        //   emulateJSON: true
        // }).then(ret => {//请求成功
        //     var tokenkey = ret.headers.map.key // 获取token
        //     me.takestate(tokenkey,ret.body.CODE)
        //   },ret => {
        //     //请求失败
        //     console.log("服务器请求失败！");
        //   });
      }
        }
    }
</script>