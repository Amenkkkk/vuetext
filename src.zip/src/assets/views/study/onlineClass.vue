<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <!-- <tabTop :tablise="tablise" v-if="tablise.tabNum>1"></tabTop> -->
        <div  class="tab-panels">
            <div class="main-ul"> 
                <classifyList :items="onclass"></classifyList>
            </div>
        </div>
        
    </div>
</template>
<style scoped>
.tab-panels{
    position: fixed;
    width: 100%;
    top: 35px;
    bottom: 0px;
    left: 0;
    right: 0;
    overflow-y:auto;
  -webkit-overflow-scrolling: touch;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import classifyList from '../../components/list/classifyList.vue';
    export default {
        components: {
            'list-header': Header,
            'classifyList': classifyList,
        },
        data () {
            return {
                loadinging: false,
                refreshing: false,
                title:'在线课堂',
                onclass:{
                        POST_onclass:'/appocourses/rList?TYPE=1&PARENT_ID=0',
                        POST_onclass_head:'/zhdj/appocourses/rList',
                        ify_url:'courseList'
                },
                

                tablise:{
                    activeTab: 0,
                    tabNum:1,  //这里是tab个数，tab大于1时必填
                    tabWidth:250,  //这里是tab宽度，建议：tab=2时，tabWidth=375； tab=3时，tabWidth=250；
                    tabs: [
                        {title: '在线课堂',}
                    ],
                    textItems: {
                        items:[],
                    },
                },
            }
        },
        methods: {
        },
    }
        
</script>

