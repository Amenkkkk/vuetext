<template>
<div class="main-li" >
    <mt-loadmore :top-method="loadTop" :autoFill='autof'  @top-status-change="handleTopChange"  :bottom-method="loadBottom"  @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="textbox">
        <div class="cell-button">
            <div class="newbox">
                <div class="newUl">
                    <div class="newLi" v-for="(lisen,i) in orgaList" :key='i'>
                        <div class="newtext" @click="showdetail(lisen.ID,POST_detail)">
                            <div class="new-title" >{{lisen.RE_ELECTION_DATE.substr(0,4)}}{{lisen.DEPTNAME}}{{lisen.STEP_0_OPINION}}</div>
                            <div class="date-div">
                                <div class="date-icomi">
                                <img class="date-ico" :src="srclink"/>
                                </div>
                                <div class="new-date" >{{itemsOrga.dateText}}:{{lisen.RE_ELECTION_DATE.substr(0,11)}}</div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
         <div slot="top" class="loadmore-top">
            <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
            <span v-show="topStatus === 'drop'">释放加载</span>
            <span v-show="topStatus === 'loading'">正在加载....</span>
             </div>
             <!--下拉刷新提示-->
        <div slot="bottom" class="loadmore-bottom">
            <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
            <span v-show="bottomStatus === 'loading'">加载中...</span>
         </div><!--上拉加载提示-->
    </mt-loadmore>
        <div class="detailbox"  v-if='detail'>  
            <div class="closebtn" @click="closebox()"><!--关闭按钮--></div>
            <details2 :infodata='infodatas'></details2>
        </div>
</div>
        
</template>
<style scoped>
.main-li {
  width: 100%;
}
.refresh {
  width: 100%;
  height: 90px;
  display: -ms-flex;
  display: -webkit-flex;
  display: flex;
  -ms-flex-align: center;
  -webkit-align-items: center;
  -webkit-box-align: center;
  align-items: center;
}
.refont {
  font-size: 30px;
  /* height: 100px; margin-top: -100px; */
}
.indicator {
  width: 50px;
  height: 50px;
  margin-top: 20px;
}
.newUl {
  display: block;
}
.newLi:first-child {
  border-top-color: #ccc;
  border-top-width: 1px;
  border-top-style: solid;
}
.newLi {
  border-bottom-color: #ccc;
  border-bottom-width: 1px;
  border-bottom-style: solid;
  padding: 20px;
  display: flex;
  justify-content: space-between;
  flex-direction: row;
}
.new-imgdiv {
  flex: 1;
}
.new-img {
  height: 150px;
  border: 1px solid #e8e8e8;
}
.newtext {
  flex: 2.5;
}
.new-title {
  font-size: 16px;
  color: #000;
  margin-bottom: 10px;
}
.new-date {
  font-size: 14px;
  color: #555;
  flex: 14;
  height: 20px;
  padding-left: 10px;
  line-height: 20px;
}
.date-div {
  display: flex;
}
.date-icomi {
  flex: 1;
}
.date-ico {
  width: 20px;
  height: 20px;
}
.detailbox {
  position: fixed;
  background-color: #fff;
  top: 0px;
  left: 0;
  right: 0;
  bottom: 0px;
}
.closebtn {
  position: absolute;
  top: 0;
  left: 0;
  width: 50px;
  height: 50px;
  z-index: 100;
}
</style>

<script>
import details2 from "../detail/hjxjdetails.vue";
import CryptoJS from "crypto-js";
export default {
  props: ["itemsOrga"],
  components: {
    details2: details2
  },
  data() {
    return {
      postResult: "",
      topStatus: "",
      alllist: "", //文章总数
      listcount: 10, //文章加载数
      last: false,
      showLoading: false,
      srclink: this.ImageUrl("icon/status_shenhe.png"),
      POST_orgalist: this.itemsOrga.POST_list,
      POST_detail: this.itemsOrga.POST_detail,
      orgaList: [
      {id:'123',RE_ELECTION_DATE:'2020年9月7日',DEPTNAME:'XX部门',STEP_0_OPINION:'第二届'},
      {id:'124',RE_ELECTION_DATE:'2020年9月6日',DEPTNAME:'XX部门',STEP_0_OPINION:'第三届'}],
      detail: false,
      infodatas: {
        pj_posturl: this.itemsOrga.pj_posturl,
        detailID: "",
        detailURL: this.itemsOrga.POST_detail
      }
    };
  },
  created: function() {
   // this.datalist(); //调用加载数据方法
  },
  methods: {
    datalist() {
      var me = this;
      me.token = localStorage.getItem("token");
      //列表数据
      me.POST_orgalist =
        me.showdoc + me.itemsOrga.POST_list + "?DEPT_ID=" + me.mydept;
      me.$http({
          method: "post",
          url: me.POST_orgalist,
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            token: me.token == undefined ? "" : me.token,
            userid: me.USER_ID == undefined ? "" : me.USER_ID,
            timestamp: me.timestamp,
            sign:
              CryptoJS.MD5(
                me.timestamp +
                  me.USER_ID +
                  me.token +
                  "/zhdj" +
                  me.itemsOrga.POST_list
              ) + ""
          }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(
          ret => {
            //请求成功
            var tokenkey = ret.headers.map.key; // 获取token
            if (tokenkey != undefined && tokenkey != "") {
              var savetoken = me.aesDecrypt(tokenkey.toString());
              localStorage.setItem("token", savetoken); //储存更新token
            } else if (ret.body.CODE != 1) {
              console.log(ret.body.CODE.MSG);
              me.$router.push({ name: "login" }); //无token或过期则跳转
            }
            me.orgaList = ret.body.DATA.result;
            me.alllist = ret.body.DATA.totalResult;
            if (me.alllist < 10) {
              me.allLoaded = true;
              me.loadingmsg = "";
            }
          },
          ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
    },
    showdetail(ID, URL) {
      this.detail = true;
      // this.infodatas={detailID: ID,
      //     detailURL:URL,}
      this.infodatas.detailID = ID;
      this.infodatas.detailURL = URL;
    }, //传数据到详细页窗口
    closebox() {
      this.detail = false;
    }, //关闭窗口
    loadTop() {
      setTimeout(() => {
        this.listcount = 10; //重置条数
        this.datalist(); //重新加载数据
        this.loadingmsg = "上拉加载";
        this.allLoaded = false; //启动加载
        this.$refs.loadmore.onTopLoaded();
        this.Msgtxt("刷新成功！")
      }, 2000);
    },
    loadBottom() {
      this.token = localStorage.getItem("token");
      setTimeout(() => {
        var me = this;
        if (me.alllist - me.listcount > 0) {
          me.listcount = me.listcount + 10;
          me
            .$http({
              //获取幻灯片数据
              method: "post",
              url: me.POST_orgalist + "&SHOWCOUNT=" + me.listcount,
              headers: { "Content-Type": "application/x-www-form-urlencoded" }, //新增加
              credientials: false,
              emulateJSON: true
            })
            .then(
              res => {
                //请求成功
                me.orgaList = res.body.DATA.result;
              },
              res => {
                //请求失败
                console.log("服务器请求失败！");
              }
            );
        } else {
          me.allLoaded = true;
          me.loadingmsg = "已经到底了";
        }
        me.$refs.loadmore.onBottomLoaded();
      }, 1000);
    }
  }
};
</script>