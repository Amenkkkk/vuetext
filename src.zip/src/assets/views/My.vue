<template>
  <div class="wrapper">    
    <home-header :title="title"></home-header>
     <div class="main-list" offset-accuracy="300px">
          <div class="cell-item-top">
             <person :persons="persons" :person="person"></person>
          </div>
          <div class="cell-button">
            <per-list  :perlists="perlists"></per-list>
          </div>
     </div>
    <tabNav :active="active"/>
  </div>
</template>
<style scoped>
.cell-item-top {
  padding: 5px 0;
  border-bottom: 2px #f2f2f2 solid;
}
.paytips {
  text-align: center;
  margin-top: 80px;
  font-size: 25px;
  color: #777;
}
</style>
<script>
import CryptoJS from "crypto-js";
import Header from "../components/myHeader.vue";
import person from "./my/person.vue";
import perList from "../components/perList.vue";
import tabNav from "../components/tabNav.vue";
export default {
  components: {
    "home-header": Header,
    'person': person,
    "per-list": perList,
    tabNav: tabNav
  },
  data() {
    return {
      actilink: 0,
      title: "个人中心",
      active: 4,
      person: [],
      persons: [],
      Link: "",
      perlists: [
        {
          name: "党费缴交",
          img: this.ImageUrl("icon/dfjn.png"),
          url: "PartyPay",
          tjicon: this.ImageUrl("icon/mipmap-mdpi/icon_enter.png"),
          itemlist: {
            title: "党费缴交",
            img: "",
            dataUrl: ""
          }
        },
        {
          name: "我是培养人",
          img: this.ImageUrl("icon/wspyr.png"),
          url: "personList",
          tjicon: this.ImageUrl("icon/mipmap-mdpi/icon_enter.png"),
          itemlist: {
            title: "我是培养人",
            img: "",
            dataUrl: '/apprdflow/getPersonList'
          }
        },
        {
          name: "我是介绍人",
          img: this.ImageUrl("icon/wsjsr.png"),
          url: "personList",
          tjicon: this.ImageUrl("icon/mipmap-mdpi/icon_enter.png"),
          itemlist: {
            title: "我是介绍人",
            img: "",
            dataUrl: '/apprdflow/getJsrList'
          }
        },
        {
          name: "我的活动",
          img: this.ImageUrl("icon/wdhd.png"),
          url: "recActivity",
          tjicon: this.ImageUrl("icon/mipmap-mdpi/icon_enter.png"),
          itemlist: {
            title: "我的活动",
            img: this.ImageUrl("icon/jqhd.png"),
            dataUrl: "/appPartyBranchActivity/activityJoinList",
          }
        },
        {
          name: "设置",
          img: this.ImageUrl("icon/sz.png"),
          url: "Setup",
          tjicon: this.ImageUrl("icon/mipmap-mdpi/icon_enter.png"),
          itemlist: {
            title: "设置",
            img: "",
            dataUrl: ""
          }
        }
      ]
    };
  },
  created() {
    var me = this;
    me.token = localStorage.getItem("token");
    var POST_USER =
      me.imgdoc + "/appregister/apppzrzx?APP_USER_ID=" + me.USER_ID;
    // me.$http({
    //     method: "post",
    //     url: POST_USER,
    //     headers: {
    //       "Content-Type": "application/x-www-form-urlencoded",
    //       token: me.token == undefined ? "" : me.token,
    //       userid: me.USER_ID == undefined ? "" : me.USER_ID,
    //       timestamp: Date.now().toString(),
    //       sign:CryptoJS.MD5( Date.now().toString() + me.USER_ID + me.token + "/zhdj/appregister/apppzrzx") + ""
    //     }, //新增加
    //     credientials: false,
    //     emulateJSON: true
    //   }).then( ret => {
    //       //请求成功
    //       console.log(ret.body)
    //       var tokenkey = ret.headers.map.key // 获取token
    //       me.takestate(tokenkey,ret.body.CODE)
    //       me.person = ret.body.DATA.LIST;
    //       me.persons = ret.body.DATA;
    //     },
    //     ret => {
    //       //请求失败
    //       me.Msgtxt("服务器请求失败！");
    //     }
    //   );
  }
};
</script>
