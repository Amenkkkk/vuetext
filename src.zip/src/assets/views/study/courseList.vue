<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <tabTop :tablise="tablise" v-if="tablise.tabNum>1"></tabTop>
        <div  :class="['tab-panels', tablise.tabNum==1?'nottabtop':'']">
            <div class="main-ul"> 
                <courseList :items="onclass" v-if="tablise.activeTab==0"></courseList>
                <div class="main-li" v-if="tablise.activeTab==1">
                <div class="">
                    <div class="kejie">{{$route.params.profile}}</div>
                </div>
            </div>
            </div>
        </div>
        <!-- <text>{{onclass}}</text> -->
    </div>
</template>
<style scoped>
.tab-panels{
    position: fixed;
    width: 100%;
    top: 77px;
    bottom: 0px;
    left: 0;
    right: 0;
    /* transition: left 0.2s ease-in-out; */
}
.nottabtop{
    top: 50px;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
.main-li{
    width: 100vw;
    float: left;
}
.kejie{padding-top: 20px;padding-bottom: 20px;padding-left: 20px;padding-right: 20px;font-size: 14px;}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import courseList from '../../components/list/courseList.vue';
    import tabTop from '../../components/tabTop.vue';
    export default {
        components: {
            'list-header': Header,
            'courseList': courseList,
            'tabTop': tabTop,
        },
        data () {
            var me=this;
            return {
                loadinging: false,
                refreshing: false,
                title:'',
                onclass:{
                        POST_onclass:'/appocourses/rList?TYPE=1&PARENT_ID=',
                        POST_onclass_head:"/zhdj/appocourses/rList",
                        ify_url:'courseList'
                },
                tablise:{
                    activeTab: 0,
                    tabNum:2,  //这里是tab个数，tab大于1时必填
                    tabWidth:50,  //这里是tab宽度，建议：tab=2时，tabWidth=375； tab=3时，tabWidth=250；
                    tabs: [
                        {NAME: '课程文章',},
                        {NAME: '课程简介',}
                     ],
                    textItems: {
                        items:[
                        ],
                    },
                },
            }
        },
        methods: {
        },
        created(){
            if(this.$route.params.id!=''&&this.$route.params.id!=undefined){
               localStorage.setItem("paramid",this.$route.params.id)  
             }
            this.saveid=localStorage.getItem("paramid") 
        }
        
    }
        
</script>

