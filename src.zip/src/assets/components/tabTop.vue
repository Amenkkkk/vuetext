<template>
        <div class="tab-scroller">
        <div class="tabbar" :style="{width:tablise.tabNum*tablise.tabWidth}" >
            <div class="tab active" :style="[{ left: tablise.activeTab*tablise.tabWidth +'%'},{ width: tablise.tabWidth+'%'}]"></div>
            <div v-for="(tab, i) in tablise.tabs" :key="i" class="tab" @click="tablise.activeTab = i" :style="{ width: tablise.tabWidth+'%'}">
                <div class="tab_title">{{tab.NAME}}</div>
            </div>
        </div>
        </div>
        <!--  -->
</template>
<style scoped>
.tab-scroller{
    width:100%;
    position:fixed;
    top:35px;
    left:0;
    right:0; z-index: 100000;
}
/* tab */
.tabbar {
    flex-direction: row;
    background-color: #f2f2f2;
    height: 42px;
}
.tab {
    height: 40px;
    float: left;
    text-align:center;
}
.tab-border{
    border-left-width:1px;
    border-style:solid;
    border-color:#ccc;
}
.tab.active {
    position: absolute;
    top: 0;
    left: 0;
    border-bottom:2px solid  #da0000;
    transition: left 0.2s ease-in-out;
}
.tab_title {
    font-size: 16px;  
    line-height: 40px;
}
</style>

<script>
    export default {
        props:["tablise"],
        data () {
            return {
            }
        },
    }
</script>
