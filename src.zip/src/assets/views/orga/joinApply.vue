<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="tab-panels">
            <div class="main-ul"> 
                <joinList :items="onclass"></joinList>
            </div>
        </div>
    </div>
</template>
<style scoped>
.tab-panels{
    position: fixed;
    width: 100%;
    top: 35px;
    bottom: 0px;
    left: 0;
    right: 0;
    overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.nottabtop{
    top: 100px;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import joinList from '../../components/list/joinList.vue';    
    export default {
        components: {
            'list-header': Header,
            'joinList': joinList,
        },
        data () {
            var me=this;
            return {
                title:'入党流程',
                onclass:{
                         POST_onclass:me.$route.params.dataUrl,
                },
                tablise:{
                    activeTab: 0,
                    // tabNum:1,  //这里是tab个数，tab大于1时必填
                    // tabWidth:250,  //这里是tab宽度，建议：tab=2时，tabWidth=375； tab=3时，tabWidth=250；
                },
            }
        },
        methods: {
        }
    }
        
</script>

