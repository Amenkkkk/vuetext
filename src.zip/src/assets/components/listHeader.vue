<template>
<div class="topnav">
    <div class="top-go" @click="routerBack()">
      <img class="top-goimg" :src="this.ImageUrl('icon/mipmap-mdpi/ico_back.png')"/>
    </div>
        <div class="toptitle">{{title}}</div>
    <div class="message">
        <!-- <image class="msg-img" resize="contain" :src="this.ImageUrl('icon/mipmap-xhdpi/ic_msg.png')"/> -->
        <!--<text class="iconfont2 magicon">&#xe901;</text>-->
    </div>
</div>
</template>
<style scoped>
.iconfont2 {
    font-family:iconfont;
}
.topnav{ height:35px;width:100%; background-color: #da0000; display: flex;justify-content:center;align-items: center; position: fixed;}
.toptitle{color: #fff; font-size: 16px;  line-height: 100px;}
.message{ position: absolute;top: 0;right: 0;}
.magicon{color: #fff; width: 30px;height:30px ;line-height: 100px; margin-right:10px;}
.msg-img{ width: 50px; height: 100px; margin-right: 20px;}
.top-go {
    position: absolute;
    left: 5px;
    top: 2px;
}
</style>
<script>
    export default {
        props:["title"],
        data () {
            return {
            }
        },
        methods: {
        }
    }
</script>