<template>
    <div class="pidj_bott">
        <!-- {{page_zanurl}} -->
            <div class="pinlun_input" @click="showdetail(postdetail.ID)">
               <input type="text" value="说说你的看法">
            </div>
            <div class="pinlun" @click="showdetail(postdetail.ID)">
               <img :src="ImageUrl('icon/pl_icon.png')" alt=""> {{postdetail.COMMENT_NUM}}
            </div>
            <div class="dianz" @click="clisk_dz()">
               <img :src="ImageUrl('icon/huiz.png')" alt="" v-if="postdetail.IS_ZAN==0">
               <img :src="ImageUrl('icon/redz.png')" alt="" v-if="postdetail.IS_ZAN==1"> 
               {{postdetail.DIANZAN}}
            </div>
            <div class="detailbox"  v-if='detail'>  
           <div class="closebtn" @click="closebox()"><!--关闭按钮--></div>
           <review  :infodata='infodatas'></review>
        </div>
       </div>
</template>
<style scoped>
.pidj_bott *{box-sizing:border-box}
.pidj_bott{position:fixed;top:auto;right:0;bottom:0;left:0;display:flex;box-sizing:border-box;padding:5px 15px;height:35px;border-top:1px solid #ccc;background:#fff}
.pinlun_input{flex:3}
.pinlun_input input{padding:0 10px;width:100%;height:25px;border:none;border-radius:13px;background:#f0f0f0}
.dianz,.pinlun{margin-left:5px;text-align:center;font-size:14x;flex:1}
.dianz img,.pinlun img{width:25px;vertical-align:middle}

.detailbox{ position: fixed; background-color:#fff; top:0px;left: 0;right: 0;bottom:0px;}
.closebtn{position: absolute ; top: 0;left: 0;width:50px; height: 50px; z-index: 100;}

</style>

<script>
import CryptoJS from "crypto-js";
import review from "../list/reviewList.vue";
export default {
    props:["postdetail"],
    components: {
            'review':review
        },
    data () {
           // var me = this;
            return {  
                page_zanurl:'/appindex/editDianZan',
                page_zan_url:'',
                infodatas:0,
                detail:false,
            }
        },
        created:function(){
            this.postdetail.COMMENT_NUM="123",
            this.postdetail.IS_ZAN='1',
            this.postdetail.DIANZAN='点赞',
            this.postdetail.ID="123"
        },
    methods: {
            showdetail(ID){
                this.detail=true
                 this.infodatas=ID
            },//传数据到详细页窗口
            closebox(){
               this.detail=false
            },//关闭窗口
            
            //  clisk_dz(){
            //     var me = this
            //     me.token=localStorage.getItem("token")
            //     me.page_zanurl=me.showdoc+'/appindex/editDianZan'+'?INFO_ID='+me.postdetail.ID+'&USER_ID='+me.myuser+'&IS_ZAN='+me.postdetail.IS_ZAN;
            //     me.page_zan_url=me.page_zanurl+'&IS_ZAN='+me.postdetail.IS_ZAN;
            //     me.$http({
            //     method: "post",
            //     url:  me.page_zan_url,
            //     headers: { "Content-Type": "application/x-www-form-urlencoded" ,
            //                 "token": me.token == undefined ? '' : me.token,
            //                 "userid": me.USER_ID == undefined ? '' : me.USER_ID,
            //                 "timestamp": me.timestamp,
            //                 "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appindex/editDianZan')+''
            //                 }, //新增加
            //     credientials: false,
            //     emulateJSON: true
            //     })
            //     .then(ret => {//请求成功
            //     var tokenkey= ret.headers.map.key // 获取token
            //         me.takestate(tokenkey,ret.body.CODE)
            //         console.log(ret.body);
            //         if(me.postdetail.IS_ZAN==0){
            //             me.postdetail.IS_ZAN=1;
            //             me.postdetail.DIANZAN=me.postdetail.DIANZAN+1;
            //         }else if(me.postdetail.IS_ZAN==1){
            //             me.postdetail.IS_ZAN=0;
            //             me.postdetail.DIANZAN=me.postdetail.DIANZAN-1;
            //         }
                    
                    
            //     },
            //     ret => {
            //         //请求失败
            //         console.log("服务器请求失败！");
            //     }
            //     );
            //  }
        },
}

</script>
