<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="main-page" >
        <div class="tab-panels" v-for="(detail_text,i) in detail_text" :key='i'> 
            <div class="new_h1">{{detail_text.TITLE}}</div>
            <div class="deta_xin">
                <div class="deta_xinli">{{detail_text.PUBLISH_DATE}}</div>
                <div class="deta_xinli">{{detail_text.APPLICANT}} | {{detail_text.RE_ELECTION_DATE}}</div>
            </div>
            <div class="infoconent">{{detail_text.STEP_0_OPINION}}</div>
        </div>
    </div>
    </div>
</template>
<style scoped>
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
.wrapper .new_h1{
    width: 100%;
    padding-top: 30px;
    padding-bottom: 10px;
    font-size: 20px;
    color: #000;
    text-align: center;
}
.wrapper .deta_xin{
    justify-content: center;
    flex-direction: row;
    align-items: center;
}
.wrapper .deta_xinli{
    padding-left: 10px;
    padding-right: 10px;
    margin-bottom: 10px;
    font-size: 14px;
    text-align: center;
    color: #555;
}
.wrapper .new_h2{
    width: 100%;
    text-align: center;
    font-size: 30px;
}
.wrapper .infoconent{ padding-left: 20px; padding-right: 20px;}
.tab-panels{top:0; position: unset;}
</style>

<script>
import listHeader from '../listHeader.vue'
    import CryptoJS from "crypto-js"
    export default {
        props:["infodata"],
        components: {
            'list-header': listHeader,
        },
        data () {
            var me = this;
            return {  
                loadinging: false,
                refreshing: false,
                title: '',
                detail_text:[{PUBLISH_DATE:'2020年9月7日1',APPLICANT:'测试文档啦啦啦啦',RE_ELECTION_DATE:'2020年9月7日2',STEP_0_OPINION:'第二届基层换届选举'}],
                xj_deta:'',
                POST_URL:'',
                token:'',
                timestamp :Date.now().toString(),
            }
        },
        methods:{
        },
        created: function() {
           var me = this;
           me.token=localStorage.getItem("token")
            me.POST_URL=me.showdoc+me.infodata.detailURL+me.infodata.pj_posturl+me.infodata.detailID
            me
                .$http({
                method: "post",
                url: me.POST_URL,
                headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                    "token": me.token == undefined ? '' : me.token,
                    "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                    "timestamp": me.timestamp,
                    "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj'+me.infodata.detailURL)+''
                }, //新增加
                credientials: false,
                emulateJSON: true
                })
                .then(
                ret => {
                    //请求成功
                    var tokenkey = ret.headers.map.key // 获取token
                    me.takestate(tokenkey,ret.body.CODE)
                    me.detail_text=ret.data.DATA.electionPd;
                    // me.title=me.detail_text.TITLE;
                    me.xj_deta=ret.data.DATA.electionPd.RE_ELECTION_DATE.substr(0,11)
                },
                ret => {
                    //请求失败
                    console.log("服务器请求失败！");
                }
                );
        },
        computed: {
        },
         methods: {
        },
        
    }
        
</script>
