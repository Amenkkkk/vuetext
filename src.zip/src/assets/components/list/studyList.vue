<template>
<div class="main-li" >
        <div class="cell-button">
            <div class="newbox">
                <div class="newUl">
                    <div class="newLi" v-for="(item, i) in items" :key="i"  @click="jumpTo('courseDetail',{id: item.id})">
                        <div class="new-imgdiv">                            
                            <img class="new-img" resize="stretch" :src="serverUrl (item.url)" />
                            <img class="videologo" v-if="item.type==2" :src="videologo"/>
                        </div>
                        <div class="newtext">
                            <div class="new-title" >{{item.title}}</div>
                            <div class="new-date" >{{item.create_time.substr(0,11)}}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <!-- <text>{{POST_study}}</text> -->
</div>
        
</template>
<style scoped>

.main-li{
    width: 100%;
}
.refresh {
    width: 100%;
    display: -ms-flex;
    display: -webkit-flex;
    display: flex;
    -ms-flex-align: center;
    -webkit-align-items: center;
    -webkit-box-align: center;
    align-items: center;
  }
  .retype{height: 40px;}
  .refont{
    font-size: 20px;
    line-height: 40px;
    margin-top: -35px;
    align-items:center;
  }
.newUl{display: block;}
.newLi:first-child{border-top-color:#ccc; border-top-width: 1px;border-top-style: solid;}
.newLi{ border-bottom-color: #ccc;border-bottom-width: 1px;border-bottom-style: solid; padding: 15px;display: flex; justify-content:space-between;  flex-direction:row;}
.new-imgdiv{flex: 40%; position: relative; overflow: hidden; }
.new-img{width: 100%; height: 80px;border: 1px solid #e8e8e8;}
.newtext{ flex: 1; margin-left: 20px; flex: 60%}
.new-title{
    font-size: 16px; min-height: 55px;
    color: #000;
    margin-bottom: 10px;
}
.new-date{
    font-size: 14px;
    color: #555;
}
.videologo{position: absolute;
    width: 36px;
    top: 50%;
    left: 50%;
    margin-left: -19px;margin-top: -19px;}
</style>

<script>
    export default {
        props:["title","items"],
        data () {
            var me = this;
            return {
                videologo:'',
                showLoading: 'hide',
                postResult:'',
                // POST_study:me.items,
                // studyList:[],
            }
        },
        
        methods: {
        
        },
        created(){
            this.videologo=this.ImageUrl('icon/ic_play.png')
           
        }

    }
</script>