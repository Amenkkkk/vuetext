<template>
 <div class="wrapper">
       <list-header :title="title"></list-header>
       <div  class="main-page"  offset-accuracy="300px">
           <div class="perLi" v-for="(per, i) in persenlist" :key="i" >
               <img class="perimage" :src='thisphoto' v-if="per.photo==''"/>
               <!-- <img class="perimage" :src='showdoc+per.photo' v-if="per.photo!=''"/> -->
               <div class="pertext">{{per.name}}</div>
           </div>
           <nodata-ms v-if="nodata"></nodata-ms>
       </div>
 </div> 
</template>
<style scoped>
.main-list{background-color:#f2f2f2;}
.perLi{background-color: #fff; justify-content: left; align-items: center;flex-direction: row; padding:10px 25px; display: flex; border-bottom: 2px #f2f2f2 solid;}
.perimage{ width: 30px; height: 30px; border-radius:20px;}
.pertext{color: #666; margin-left: 30px; font-size: 18px;}
.paytips{ text-align: center; margin-top:80px; font-size: 18px; color: #777}
</style>


<script>
import CryptoJS from "crypto-js";
import Header from "../../components/listHeader.vue";
import nodatams from "../../components/nodatams.vue";
    export default {
        props:["perlists"],
        components: {
          "list-header": Header,
          "nodata-ms":nodatams
        },
        data () {
             var me=this;
            return {
                title: me.$route.params.name, 
                persenlist:[{photo:'',name:'李四'},{photo:'',name:'赵六'},{photo:'',name:'王继'},{photo:'',name:'陈春'},{photo:'',name:'马明'}], 
                thisphoto: this.ImageUrl('icon/mipmap-mdpi/study_zxxt.png') ,   
                nodata:false,
            }
        },
        methods: {

        },
        created(){
    //  var me = this; //学习首页文章列表数据
    //  me.token=localStorage.getItem("token")
    //  me.$http({
    //       method: "post",
    //       url: me.showdoc+me.$route.params.dataUrl+'?USER_ID='+me.USER_ID,
    //       headers: { "Content-Type": "application/x-www-form-urlencoded" ,
    //                  "token": me.token == undefined ? '' : me.token,
    //                  "userid": me.USER_ID == undefined ? '' : me.USER_ID,
    //                  "timestamp": Date.now().toString(),
    //                  "sign": CryptoJS.MD5(Date.now().toString() + me.USER_ID + me.token + me.showdoc+me.$route.params.dataUrl)+''
    //                  }, //新增加
    //       credientials: false,
    //       emulateJSON: true
    //     })
    //     .then(ret => {//请求成功
    //           if(ret.body.CODE==1){
    //               if(ret.body.DATA.totalResult==0){
    //                 me.nodata=true
    //               }else{
    //               me.persenlist=ret.body.DATA.result;
    //               me.message=''
    //               }
    //           }else if(ret.body.CODE==0){
    //               me.$router.push({name: "login"}); //退出后跳转登录页面
    //           }   
    //       },
    //       ret => {
    //         //请求失败
    //         console.log("服务器请求失败！");
    //       }
    //     );
        }
        
    }
</script>