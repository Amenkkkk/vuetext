/**
 * Created by zwwill on 2017/8/27.
 */

let utilFunc = {
    
};

export default utilFunc;