<template>
<div>
<list-header :title="title"></list-header>
<div class="main-li" >
    <div  class="main-page" >   
    <mt-loadmore :top-method="loadTop" :autoFill='autof'  @top-status-change="handleTopChange"  :bottom-method="loadBottom"  @bottom-status-change="handleBottomChange" :bottom-all-loaded="allLoaded" ref="loadmore" class="textbox">
        <div class="cell-button">
            <div class="newbox">
                <div class="newUl">
                    <div class="newLi" v-for="(lisen,i) in dygsitem" :key='i'>
                        <div class="newtext">
                            <div class="pl_left">
                                <img :src="lisen.photo" alt="">
                            </div>
                            <div class="pl_right">
                                <div class="us_name">{{lisen.USERNAME}}</div>
                                <div class="us_pl">{{lisen.CONTENT}}</div>
                                <div class="gl_hf">{{lisen.RE_USERNAME}}回复：{{lisen.RE_CONTENT}}</div>
                            </div>
                        </div>
                    </div>
                </div> 
            </div>
        </div>
        <div slot="top" class="loadmore-top">
            <span v-show="topStatus !== 'loading'&&topStatus !== 'drop'">下拉刷新..</span>
            <span v-show="topStatus === 'drop'">释放加载</span>
            <span v-show="topStatus === 'loading'">正在加载....</span>
             </div>
             <!--下拉刷新提示-->
        <div slot="bottom" class="loadmore-bottom">
            <span v-show="bottomStatus !== 'loading'" :class="{ 'is-rotate': bottomStatus === 'drop' }">{{loadingmsg}}</span>
            <span v-show="bottomStatus === 'loading'">加载中...</span>
         </div><!--上拉加载提示-->
        </mt-loadmore>
        <div class="pl_from">
            <div class="pl_inp">
                <input type="text" v-model="message" placeholder="说说你的看法">
            </div>
            <div class="pl_btn" @click="plmessage(message)"><span>发送</span></div>
            <div v-show="plts" class="pl_ts"> <span> {{pltsnei}} </span></div>
        </div>
    </div>
</div>
</div>
</template>
<style scoped>

.main-li{
    width: 100%;
}
.main-page{background:#f0f0f0; bottom: 35px;}
.newUl{display: block;}
.newLi:first-child{border-top-color:#ccc; border-top-width: 1px;border-top-style: solid;}
.newLi{margin-bottom: 5px; padding:10px 15px;display: flex; background: #fff;}
.newtext{display: flex}
.pl_left{flex: 1}
.pl_left img{width: 100%;}
.pl_right{flex: 8; padding-left: 5px;}
.us_name{line-height: 30px; font-size: 14px;font-weight: bold;}
.us_pl{line-height: 30px; border-bottom:1px solid #f0f0f0; font-size: 14px;}
.gl_hf{line-height: 30px; font-size: 14px;}
.pl_from{display: flex; position: fixed;width: 100%;height: 35px;left: 0;top: auto;bottom: 0; background:#fff;}
.pl_inp{flex: 4;padding: 0 10px;}
.pl_inp input{width: 100%;
    border: none;
    background: #f0f0f0;
    margin-top: 5px;
    height: 24px;
    border-radius: 12px;
    text-indent: 5px;}
.pl_btn{flex: 1}
.pl_btn span{ width: 46px;text-align: center;border-radius: 3px;display:block;height:24px; margin-top: 5px;font-size: 12px;background: #7094ef;color: #fff;line-height: 24px;}
.pl_ts{position: fixed; left: 0;top: 50%;width: 100%; text-align: center;}
.pl_ts span {
    display: inline-block;
    font-size: 12px;
    background: #f0f0f0;
    border-radius: 14px;
    line-height: 28px;
    padding: 0 8px;
    /* border: 1px solid #fff; */
    box-shadow: 0px 0px 4px 2px #fff;
}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import CryptoJS from "crypto-js";
    import { MessageBox } from 'mint-ui';
    export default {
        props:["infodata"],
        components: {
            'list-header': Header,
        },
        data () {
            var me=this; 
            return {
                title:'评论',
                message:'',
                loadinging: false,
                refreshing: false,
                postResult:'',
                alllist:'',//文章总数
                listcount:10,//文章加载数
                last:false,
                showLoading: 'hide',
                post_dygs:'',
                post_plurl:'',
                dygsitem:[{photo:this.ImageUrl('icon/mipmap-xhdpi/ic_person_n.png'),USERNAME:'人员1',CONTENT:'文章评论内容啦啦啦啦啦啦',RE_USERNAME:'人员2',RE_CONTENT:'文章评论回复内容222'},{photo:this.ImageUrl('icon/mipmap-xhdpi/ic_person_n.png'),USERNAME:'张三',CONTENT:'文章写的非常好',RE_USERNAME:'李四',RE_CONTENT:'谢谢夸奖'},{photo:this.ImageUrl('icon/mipmap-xhdpi/ic_person_n.png'),USERNAME:'赵武',CONTENT:'看不懂',RE_USERNAME:'陆毅',RE_CONTENT:'多理解一下就看懂了'},{photo:this.ImageUrl('icon/mipmap-xhdpi/ic_person_n.png'),USERNAME:'陈亮',CONTENT:'文章评论内容啦啦啦啦啦啦',RE_USERNAME:'吴生',RE_CONTENT:'知识海洋积累知识'},{photo:this.ImageUrl('icon/mipmap-xhdpi/ic_person_n.png'),USERNAME:'王二',CONTENT:'文章评论内容啦啦啦啦啦啦',RE_USERNAME:'太一',RE_CONTENT:'文章评论回复内容222'}],
                kk:'22',
                detail:false,
                plts:false,
                pltsnei:"",
            }
        },
        created: function() {
          // this.datalist() 
        },
        methods: {
            plmessage(message){
                 var me = this;
                me.token=localStorage.getItem("token")
                me.post_plurl = me.showdoc+'/appcomment/comment'+'?INFO_ID='+me.infodata+'&USER_ID='+me.myuser+'&CONTENT='+message;
            //评论列表数据
            console.log(me.post_plurl);
            me
                .$http({
                method: "post",
                url: me.post_plurl,
                headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                    "token": me.token == undefined ? '' : me.token,
                    "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                    "timestamp": me.timestamp,
                    "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appcomment/comment')+''
                }, //新增加
                credientials: false,
                emulateJSON: true
                }).then(ret => {
                    //请求成功
                var tokenkey = ret.headers.map.key // 获取token
                 me.takestate(tokenkey,ret.body.CODE)
                   if(ret.body.CODE==2){
                    //    MessageBox.alert('用户已经平论过，每个用户只能评论一次');
                    me.pltsnei='用户已经评论过，每个用户只能评论一次'
                    me.plts=true;
                    setTimeout(() => {
                        me.plts=false;
                    }, 2000);
                   }else if(ret.body.CODE==1){
                    //    MessageBox.alert('评论成功，等待后台审核');
                    me.pltsnei='评论成功，等待后台审核'
                    me.plts=true;
                    setTimeout(() => {
                        me.plts=false;
                    }, 2000);
                   } 
                    
                },ret => {
                    //请求失败
                    console.log("服务器请求失败！");
                }
                );
            },
            datalist(){
                var me = this;
                me.token=localStorage.getItem("token")
                me.post_dygs = me.showdoc+'/appcomment/commentList'+'?INFO_ID='+me.infodata+'&APP_USER_ID='+me.myuser;
            //评论列表数据
            me
                .$http({
                method: "post",
                url: me.post_dygs,
                headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                    "token": me.token == undefined ? '' : me.token,
                    "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                    "timestamp": me.timestamp,
                    "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appcomment/commentList')+''
                }, //新增加
                credientials: false,
                emulateJSON: true
                }).then(ret => {
                    //请求成功
                var tokenkey = ret.headers.map.key // 获取token
                if( tokenkey != undefined&& tokenkey != '' ){
                var savetoken=me.aesDecrypt(tokenkey.toString())
                localStorage.setItem("token",savetoken) //储存更新token
                }else if(ret.body.CODE!=1){
                console.log(ret.body.MSG+'无token或过期');
                //me.$router.push({ name: "login"}); //无token或过期则跳转
                }
                    me.dygsitem = ret.body.DATA.result;
                    me.alllist = ret.body.DATA.totalResult;
                    if(me.alllist<10){
                             me.allLoaded = true;
                             me.loadingmsg='' 
                          }
                },ret => {
                    //请求失败
                    console.log("服务器请求失败！");
                }
                );
            },     
            loadTop() {
              setTimeout(() => {
                this.listcount = 10; //重置条数
                this.datalist(); //重新加载数据
                this.loadingmsg = "上拉加载";
                this.allLoaded = false; //启动加载
                this.$refs.loadmore.onTopLoaded();
                this.Msgtxt("刷新成功！")
              }, 2000);
            },
            loadBottom(){
            this.token=localStorage.getItem("token")
                        setTimeout(() => {
                            var me=this
                            if(me.alllist-me.listcount > 0){     
                            me.listcount=me.listcount+10
                            me.$http({  //获取数据
                                method:"post",
                                url: me.post_dygs+'&SHOWCOUNT='+ me.listcount,
                                headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                                    "token": me.token == undefined ? '' : me.token,
                                    "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                                    "timestamp": me.timestamp,
                                    "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj/appcomment/commentList')+''
                        }, //新增加
                                credientials:false, 
                                emulateJSON: true     
                            }).then(res=>{  //请求成功
                                me.dygsitem = res.body.DATA.result;
                                console.log(me.post_dygs)
                            }, res => { //请求失败
                                console.log('服务器请求失败！')
                                }
                            ); 
                            }else{
                            me.allLoaded = true;
                            me.loadingmsg='已经到底了'                     
                            }
                            me.$refs.loadmore.onBottomLoaded()
            }, 1000);
        },
        created: function() {
            if(this.$route.params.id=='' ||this.$route.params.id==undefined){
            var pageurl=window.location.href
            var pagenum=pageurl.indexOf('=')
            var pagecode=pageurl.substr(pagenum+1)
            console.log(pagecode)
            this.depid=pagecode
            }else{
            this.depid=this.$route.params.id
            }
            this.datalist(); //调用加载数据方法
        }
    }
    
}
</script>