<template> 
<div class="wapper">
  <div class="backheader">
      <img class="back-img" @click="routerBack" resize="contain" :src="this.ImageUrl ('icon/mipmap-mdpi/ico_back.png')"/>
      <div class="backtitle">手机号验证</div>
  </div>
  <div class="yanzheng">
       <div class="yz-tips">当前的手机号是：{{this.$route.params.PHE}} </div>
       <!-- -->
       <div class="top-row input-row">
            <img class="user-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ic_password.png')"/>
            <input type="password"  placeholder="密码" class="username" placeholder-color="#999"   value="" @blur="checkPSD" v-model="PSDnum"/>
        </div>
        <div class="bottom-row input-row">
            <img class="pw-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ico_coden.png')"/>
           <input type="password"  placeholder="确认密码" class="password"   v-model="PSDagain" placeholder-color="#999"/>
        </div>
        <div class="LIbox"  @click="Resetto()">
           <div class="loginIN" >重置密码</div>
        </div>
        <!-- <div>{{getResult}}</div> -->
  </div>
</div>
</template>
<style scoped>
@import"./login.css";
</style>

<script>// 2018年03月19日17:54:33 测试完毕
import md5 from "crypto-js/md5";

export default {
  data() {
    return {
      // phone:'加载中..',
      PSDnum: "",
      PSDagain:'',
      CCD:'',
      getResult: "测试结果"
    };
  },
  methods: {
    checkPSD() {
      if (this.PSDnum == "") {
        this.Msgtxt("请输入密码");
      } else if (this.PSDnum.search(/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$/) == 0 ) {
        this.CCD=1;
      } else {
       this.Msgtxt("密码必须6-20位，包含字母与数字");
       this.CCD=0
      }
    },
    Resetto() {
      var me = this;
      var password = me.PSDnum;
      var passagain = me.PSDagain;
      if (password != passagain) {
        me.Msgtxt("两次密码输入结果不一致"+password+passagain);
      } else if (me.CCD == 1) {  //当密码格式正确的时候获取数据 
        var postreset = me.toParams({
          PHONE: me.$route.params.PHE,
          PASSWORD: md5(password)
        });
        var POST_RESET =  me.imgdoc+"/appregister/editpwdByPhone?" + postreset;
         me.$http({
          method: "post",
          url:  POST_RESET,
          headers: { "Content-Type": "application/x-www-form-urlencoded"  }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
           //   me.getResult = JSON.stringify(ret.body) + POST_RESET;
              var codenum = ret.body.CODE; //获取返回数据的code
              var loginmsg = ret.body.MSG; //获取返回结果说明
              if (codenum === "1") {
                //成功重置后跳转首页
                me.Msgtxt('重置成功！');
                me.$router.push("login");
              } else {
                //登陆失败，弹出失败信息
               me.Msgtxt("重置失败");
              }
          },ret => {
            //请求失败
            me.Msgtxt("服务器请求失败！");
          }
        );
      }else{
         me.Msgtxt("验证失败！");
      }
    }
  },
  created() {
  }
};
</script>