<template>
<div class="wapper">
  <div class="backheader">
      <img class="back-img" @click="routerBack" resize="contain" :src="this.ImageUrl ('icon/mipmap-mdpi/ico_back.png')"/>
      <div class="backtitle">手机号验证</div>
  </div>
  <div class="yanzheng">
       <div class="yz-tips">为了保证账户安全，找回密码前，需要通过手机验证</div>
       <div class="top-row input-row">
            <img class="user-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ico_phone.png')"/>
            <input type="number"  maxlength="11" placeholder="手机号" class="username" placeholder-color="#999"   value="" @change="checkphone" v-model="phonenumber"  />
        </div>
        <div class="bottom-row input-row">
            <img class="pw-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ico_coden.png')"/>
           <input type="text" maxlength="6" placeholder="验证码" class="codenumber" v-model="codeint" placeholder-color="#999"/>
           <div class="PCode">
            <div class="PCodep"  @click="checkp()">获取验证码</div>
            </div>
        </div>
        <div class="LIbox"   @click="codecheck()">
        <div class="loginIN">下一步</div>
        </div>
        <!-- <text>{{getResult}}</text>  -->
  </div>
</div>
</template>
<style scoped>
@import"./login.css";
</style>
<script>
import util from "../util";
export default {
  data() {
    return {
      getResult: "加载中..",
      phonenumber: "",
      codeint:'',
    };
  },
  methods: {
    checkphone() {
      if (this.phonenumber == "") {
        this.Msgtxt("请输入手机号");
      } else if (
        this.phonenumber.search(
          /^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/
        ) == 0
      ) {
        return true;
      } else {
        this.Msgtxt("请输入正确手机号");
      }
    },
    checkp() {//验证码获取
      var me = this;
      var phone = me.phonenumber;
      var POST_TEL = me.imgdoc+"/appregister/vhcode?PHONE=" + phone; //验证码接口
      me.$http({
          method: "post",
          url:  POST_TEL,
          headers: { "Content-Type": "application/x-www-form-urlencoded"  }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
            me.getResult = JSON.stringify(ret.body); //测试输出查看数据信息
            me.code = ret.body.CODE; //获取数据的code
            var loginmsg = ret.body.MSG; //获取返回结果说明
            if (me.code === "1") { //成功验证后获取返回code
              me.codekey = ret.body.DATA.CODEKEY; //获取codekey
               me.Msgtxt("验证码已发送，请留意短信");
            } else {
               me.Msgtxt(loginmsg);
            }
          },ret => {
            //请求失败
             me.Msgtxt("服务器请求失败！");
          }
        );
    },
    codecheck() {// 提交验证信息
      var me = this;
      var postcode = me.toParams({
        PHONE: me.phonenumber,
        CODEKEY: me.codekey,
        IDENTIFYING: me.codeint
      });
      var POST_CODE = me.imgdoc+"/appregister/vhcodeyz?" + postcode;
      me.$http({
          method: "post",
          url: POST_CODE,
          headers: { "Content-Type": "application/x-www-form-urlencoded"  }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
            me.getResult = JSON.stringify(ret.data) + POST_CODE;
            var codenum = ret.body.CODE; //获取验证完成后的code
            var loginmsg = ret.body.MSG; //获取返回结果说明
            if (codenum === "1") { //成功后跳转重置页
              me.Msgtxt(loginmsg);
              me.$router.push({ name: "reset", params: { PHE: me.phonenumber } });
            } else {//登陆失败，弹出失败信息
              me.Msgtxt(loginmsg);
            }
          },ret => {
            //请求失败
           me.Msgtxt("服务器请求失败！");
          }
        );
    }
  },
  created() {
  
  }
};
</script>

