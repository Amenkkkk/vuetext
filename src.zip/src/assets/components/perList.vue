<template>
<div class="newbox">
    <div class="newUl">
        <div class="newLi" v-for="(per, i) in perlists" :key="i"  @click="jumpTo(per.url,{dataUrl: per.itemlist.dataUrl,name:per.itemlist.title})">
                <img class="new-img" resize="stretch" :src="per.img" />
        <div class="newtext" >
            <div class="new-title">{{per.name}}</div>
        </div>
            <img class="tj_icon_img" resize="stretch" :src="per.tjicon" />
        </div>
    </div>
</div>
</template>
<style scoped>
.newUl{display: block;}
.newLi{ border-bottom-color: #ccc;border-bottom-width: 1px;border-bottom-style: solid; padding: 10px 5px 10px 20px;display: flex; justify-content:space-between;  flex-direction:row; display: flex; align-items: center;}
.new-img{width: 25px; height: 25px;}
.tj_icon_img{width: 25px; height: 25px;}
.newtext{ flex: 9; margin-left: 20px;}
.new-title{
    color: #000;
}
.new-date{
    color: #555;
}
</style>

<script>
    // var navigator = weex.requireModule('navigator')
    export default {
        props:["perlists"],
        data () {
            return {
            }
        },
        methods: {
        }
    }
</script>