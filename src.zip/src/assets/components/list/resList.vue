<template>
<div class="main-li" >
    <div  class="main-page" offset-accuracy="300px">
        <!--需要添加刷新加载-->
        <div class="cell-button">
            <div class="newbox">
                <div class="newUl">
                    <div class="newLi" v-for="(item, i) in cjgklist" :key="i">
                        <div class=" restext res-title">{{item.title}}</div>
                        <div class=" restext res-startTime">开始时间：{{item.start_time.substr(0,11)}}</div>
                        <div class=" restext res-endTime">结束时间：{{item.end_time.substr(0,11)}}</div>
                        <div class=" restext res-textTime">考试时长：{{item.lentime}}</div>
                        <div class=" restext res-parNum">参加人数：{{item.tz.zs}}</div>
                        <div class=" restext res-aveScore">平均得分：{{item.tz.pjz}}</div>
                        <div class="resbut">
                            <div class="res-but" @click="jumpTo('resDetail',{ID: item.id})">查看</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
        
</template>
<style scoped>

.main-li{
    width: 100%;
}
.newUl{display: block;}
.newLi:first-child{border-top-color:#ccc; border-top-width: 1px;border-top-style: solid;}
.newLi{ border-bottom-color: #ccc;border-bottom-width: 1px;border-bottom-style: solid; padding:15px;position: relative;}
.resbut{
    position: absolute;
    bottom: 20px;
    right: 20px;
}
.res-but{
    width: 60px;
    align-items: center;
    color: #fff;
    text-align: center;
    padding-top: 6px;
    padding-bottom: 6px;
    background-color: #da0000;
    font-size: 12px;
    border-radius: 5px;
}
.restext{
    font-size: 14px;
    margin-bottom: 5px;
    margin-top: 5px;
}
.res-title{ font-size: 16px;}
</style>

<script>
    import CryptoJS from "crypto-js";    
    export default {
        props:["title","items"],
        data () {
            var me = this;
            return {
                loadinging: false,
                refreshing: false,
                showLoading: 'hide',
                POST_cjgk:me.items,
                cjgklist:[{title:'考试试卷题目A卷',start_time:'2020年9月23日',end_time:'2020年9月23日',lentime:'60分钟',tz:{zs:'60',pjz:'75.2'},id:'534'},
                {title:'考试试卷题目B卷',start_time:'2020年9月23日',end_time:'2020年9月23日',lentime:'60分钟',tz:{zs:'60',pjz:'75.2'},id:'555'},
                {title:'考试试卷题目C卷',start_time:'2020年9月23日',end_time:'2020年9月23日',lentime:'60分钟',tz:{zs:'60',pjz:'75.2'},id:'567'}],
                alllist:'',//文章总数
                listcount:10,//文章加载数
                last:false,
            }
        },
        created: function() {
            //this.datalist() //调用加载数据方法
        },
        methods: {
            datalist(){
                var me = this;
                me.token=localStorage.getItem("token")
                me.POST_cjgk=me.showdoc+me.items+"?DEPT_ID="+me.mydept
                me
                    .$http({
                    method: "post",
                    url: me.POST_cjgk,
                    headers: { "Content-Type": "application/x-www-form-urlencoded" ,
                     "token": me.token == undefined ? '' : me.token,
                     "userid": me.USER_ID == undefined ? '' : me.USER_ID,
                     "timestamp": me.timestamp,
                     "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj'+me.items)+''
                   }, //新增加
                    credientials: false,
                    emulateJSON: true
                    })
                    .then(
                    ret => {
                        //请求成功
                        var tokenkey = ret.headers.map.key // 获取token
                        me.takestate(tokenkey,ret.body.CODE)
                        me.cjgklist = ret.body.DATA.result;
                        me.alllist = ret.body.DATA.totalResult;
                    },
                    ret => {
                        //请求失败
                        console.log("服务器请求失败！");
                    }
                    );
            },
            
        }
    }
</script>