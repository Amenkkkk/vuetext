<template>
<div class="wapper">
  <div class="backheader">
      <img class="back-img" @click="routerBack" resize="contain" :src="this.ImageUrl ('icon/mipmap-mdpi/ico_back.png')"/>
      <div class="backtitle">注册</div>
  </div>
  <div class="zctips">{{zcwarm}}{{txwarm}}</div>
  <div class="zhuce">
      <div class="top-row input-row">
            <img class="user-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ic_username.png')"/>
            <input type="text" placeholder="用户名" class="username" placeholder-color="#999" v-model="nameInput"  value="" />
        </div>
       <div class="mid-row input-row">
            <img class="user-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ico_phone.png')"/>
            <input type="number"  maxlength="11" placeholder="手机号" class="username" placeholder-color="#999" v-model="phone"  value="" />
        </div>
        <div class="mid-row input-row">
            <img class="pw-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ic_password.png')"/>
           <input type="password" placeholder="密码" class="password" v-model="password"  placeholder-color="#999"/>
        </div>
        <div class="mid-row input-row">
            <img class="pw-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ic_pcode.png')"/>
           <input type="text" placeholder="图形验证" class="imagecode"  @change="checkLpicma" v-model="picLyanzhengma" placeholder-color="#999"/>
            <div class="imgCode" :class="{ fontsize: isSize,}"  @click="createCode">{{checkCode}}</div>
        </div>
        <div class="bottom-row input-row">
            <img class="pw-img" resize="contain" :src="this.ImageUrl ('icon/mipmap-xhdpi/ico_coden.png')"/>
           <input type="text" maxlength="6" placeholder="验证码" class="codenumber"  placeholder-color="#999" v-model="Codein" />
           <div class="PCode">
            <div class="PCodep" @click="checkp()" >获取验证码</div>
            </div>
        </div>
        <div class="LIbox" @click="RegisterIn()">
        <div class="loginIN" >注册</div>
        </div>
        <!-- <div>{{postResult}} {{checkCode}}</div> -->
  </div>
</div>
</template>
<style  scoped>
@import"./login.css";
</style>

<script>
var code;  // 定义code
import md5 from "crypto-js/md5";
export default {
  data() {
    return {
      nameInput:'',
      phone:'',
      password:'',
      zcwarm:'',
      txwarm:'',
      Codein:'',
      isSize:false,
     // txtInput: 0,
      postResult: "测试数据",
      picLyanzhengma: "",
      checkCode: "点击刷新"
    };
  },
  methods: {
     createCode() {
      //生成随机图片验证码
      code = "";
      var codeLength = 4; //验证码的长度
      var random = new Array(0,1,2,3,4,5,6,7,8,9,'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z');//随机数
      for (var i = 0; i < codeLength; i++) { //循环操作
        var index = Math.floor(Math.random() * 36); //取得随机数的索引（0~35）
        code += random[index]; //根据索引取得随机数加到code上
      }
      this.checkCode = code; //把code值赋给验证码
      this.isSize=true;
    },
    checkLpicma() { // 失焦验证图和密码
      this.picLyanzhengma.toUpperCase(); //取得输入的验证码并转化为大写
      if (this.picLyanzhengma == "") {
        if(this.zcwarm==''){
        this.txwarm="请输入图形验证码";}
      } else if (this.picLyanzhengma.toUpperCase() != this.checkCode) {
        //若输入的验证码与产生的验证码不一致时
        this.zcwarm="图形验证码不正确";
        this.createCode(); //刷新验证码
        this.picLyanzhengma = "";
      } else {//输入正确时
        this.txwarm="";
        return true;
      }
    },
    checkp() { //验证码获取
      var me = this;
      var phone = me.phone;
      var POST_TEL =  me.imgdoc+"/appregister/verificationcode?PHONE=" + phone; //注册验证码接口
      if (this.checkLpicma() == true) {
        me.$http({
          method: "post",
          url:  POST_TEL,
          headers: { "Content-Type": "application/x-www-form-urlencoded"  }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
              console.log("get:" + JSON.stringify(ret));
              me.postResult = JSON.stringify(ret.data); //测试输出查看数据信息
              me.code = ret.data.CODE;
              me.codekey = ret.data.DATA.CODEKEY; //获取codekey
              console.log("验证码已发送，请留意短信");
          },ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
      }
    },
    RegisterIn() {
      var me = this;
      var phone = me.phone;
      var pw = me.password;
      if (pw == "") {
        me.zcwarm="请输入密码";
      } 
      else if ( pw.search(/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,20}$/) == 0) {
        var Pwtrue = 1;
        me.zcwarm=''
      }else {
       me.zcwarm="密码必须6-20位，包含字母与数字";
      }
      if (phone == "") {
       me.zcwarm="请输入手机号";
      }  else if (phone.search(/^(0|86|17951)?(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$/) == 0) {
        var Numtrue = 1;
        me.zcwarm=''
      }else{
        me.zcwarm="请输入11位正确手机号";
      }
      if(me.nameInput==''){        
        me.zcwarm="请输入用户名";
      }
      if (this.checkLpicma() == true && Numtrue == 1 && Pwtrue == 1) {
        var postcode = me.toParams({
          USERNAME: me.nameInput,
          PHONE: me.phone,
          PASSWORD: md5(pw),
          CODEKEY: me.codekey,
          IDENTIFYING: me.Codein
        });
        var POST_REGIST =  me.imgdoc+"/appregister/zhuce?" + postcode;
         me.$http({
          method: "post",
          url:  POST_REGIST,
          headers: { "Content-Type": "application/x-www-form-urlencoded"  }, //新增加
          credientials: false,
          emulateJSON: true
        })
        .then(ret => {//请求成功
              var codenum = ret.data.CODE; //获取注册后的code
              var loginmsg = ret.data.MSG; //获取返回结果说明
              if (codenum === "1") { //成功注册后跳转首页
                console.log(loginmsg);
                me.$router.push({name:'login'})
              } else if (codenum === "2") {  //验证码有误
                 me.zcwarm=(loginmsg);
                //  me.createCode();//刷新图形验证码
                //  me.picLyanzhengma = '';
              } else {
                //登陆失败，弹出失败信息
                console.log(loginmsg);
              }
          },ret => {
            //请求失败
            console.log("服务器请求失败！");
          }
        );
      }
    }
  },
  created() {
    this.createCode(); //刷新页面更新图形验证码
  }
};
</script>

