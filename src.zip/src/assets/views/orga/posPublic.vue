<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <!-- <tabTop :tablise="tablise" v-if="tablise.tabNum>1"></tabTop> -->
        <div class="tab-panels" >
            <div class="main-ul" > 
                <orgaList :itemsOrga="tablise.textItems"></orgaList>
            </div>
        </div>
        <!-- <text>{{tablise.textItems}}</text> -->
    </div>
</template>
<style scoped>
.tab-panels{
    position: fixed;
    width: 100%;
    top: 200px;
    bottom: 0px;
    left: 0;
    right: 0;
    /* transition: left 0.2s ease-in-out; */
}
.nottabtop{
    top: 100px;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    import orgaList from '../../components/list/dygsList.vue';
    export default {
        components: {
            'list-header': Header,
            'orgaList': orgaList,
        },
        data () {
            var me=this;
            return {
                loadinging: false,
                refreshing: false,
                title:me.$route.params.name,
                postResult:'',
                tablise:{
                    colunm_id:'',
                    activeTab: 0,
                    tabs: [],
                    tabNum:1,
                    textItems: {
                        post_dygs:me.$route.params.dataUrl,
                        dateText:me.$route.params.dateText,
                        dataUrl_type:'?TYPE=2',
                        detailName:'zsdygsDetail',//指定跳转的详细页
                        detailpost:'/apprdflow/phaseThirteen',//详细页接口
                    },
                },
            }
        },
        created: function() {

        },
        methods: {
        }
    }
        
</script>

