<template>
<div class="main-li" >
    <div  class="" >
        <div class="cell-button">
            <div class="newbox">
                <div class="newUl">
                    <!-- <div class="">
                        <div>{{post_join}}{{joinList}}</div>
                    </div>
                    ['newLi', joinList.CURRENT_STAGE==15-i?'ml-ipx':'']
                    -->
                    <div :class="newLi"  v-for="(item, i) in join" :key="i" >
                        <div v-if="10>=15-i">
                        <div class="ydqk" >
                            <div class="ydqk_bg"><div class="ydqk_bghui"></div></div>
                                <img class="ydqk_bgimg" v-if="joinList.CURRENT_STAGE==15-i&&joinList.CURRENT_STAGE!=15" :src='ImageUrl("icon/mipmap-xhdpi/status_1.png")'/>
                                <img class="ydqk_bgimg" v-if="joinList.CURRENT_STAGE>15-i||joinList.CURRENT_STAGE==15" :src='ImageUrl("icon/mipmap-xhdpi/status_2.png")'/>
                            <div class="ydqk_bg"><div class="ydqk_bghui"></div></div>
                            <div class="ydqk_bg" v-if="joinList.CURRENT_STAGE==15-i" ><div class="ydqk_bghui"></div></div>
                        </div>
                        <div class="newtext">
                            <div class="new-title"  @click="jumpTo('courseDetail',{id: item.id})">{{item.title}}</div>
                            <div class="zfgl_text" v-if="joinList.CURRENT_STAGE==15-i&&joinList.CURRENT_STAGE!=15">{{jointext}}</div>
                            <div class="zfgl_text" v-if="joinList.CURRENT_STAGE==15-i&&joinList.CURRENT_STAGE_STATUS==3">{{jointext2}}</div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>   
</template>
<style scoped>
.main-li{
    width: 100%;
}
.newUl{display: block;}

.newLi:first-child{border-top-color:#ccc; border-top-width: 1px;border-top-style: solid;}
.newLi{min-height:100px; border-bottom-color: #ccc;border-bottom-width: 1px;border-bottom-style: solid; padding-right: 20px;display: flex; justify-content:space-between;  flex-direction:row;}
.new-imgdiv{ margin-top: 20px;margin-bottom: 20px;}
.new-img{ height: 150px;border: 1px solid #e8e8e8;}
.newtext{ flex:6;}
.new-title{
    font-size: 16px;
    color: #fff;
    margin-bottom: 10px;
    margin-top: 28px;
    background-color: #798ffd;
    height: 20px;
    line-height: 20px;
    width: 80%;
    border-radius: 10px;
    padding: 12px;
}
.zfgl_text{
    font-size: 16px;
    color: #555;
    margin-bottom: 10px;
    background-color: #f9f9f9;
    height: 20px;
    line-height: 20px;
    width: 80%;
    /* border-top-right-radius: 10px;
    border-top-left-radius: 10px;
    border-bottom-right-radius: 10px;
    border-bottom-left-radius: 10px; */
    padding: 12px;
}
.new-date{
    font-size: 28px;
    color: #555;
}
.ydqk{flex: 1;display: flex; justify-content:space-between;  flex-direction:column; text-align: center;align-items: center;}
.ydqk_bg{position: relative;}
.ydqk_bghui{width: 5px;height: 40px;background-color: #ccc;}
.ml-ipx{min-height:132px}
.ml-ipx .ydqk{height:132px}
.ydqk_bgimg{width: 20px;height: 20px;}
</style>

<script>
    import CryptoJS from "crypto-js";
    export default {
        props:["title","items"],
        data () {
            var me=this;
            return {
                loadinging: false,
                refreshing: false,
                showLoading: 'hide',
                POST_onclass:me.items.POST_onclass,
                post_join:'',
                joinList:[{CURRENT_STAGE:'10',CURRENT_STAGE_STATUS:'3'}],
                jointext:'请您继续努力',
                jointext2:'恭喜您成为党员',
                join:[
                    {title:'15.上级党组织批准为正式党员',id:'15'},
                    {title:'14.支部党员大会决议',id:'14'},
                    {title:'13.转为正式党员公示',id:'13'},
                    {title:'12.预备党员继续培养考察期',id:'12'},
                    {title:'11.预备党员宣誓',id:'11'},
                    {title:'10.入党志愿和考察期',id:'10'},
                    {title:'9.通表大会和组谈话',id:'9'},
                    {title:'8.预备党员公示',id:'8'},
                    {title:'7.发展对象审查',id:'7'},
                    {title:'6.发展对象确定',id:'6'},
                    {title:'5.入党前培训',id:'5'},
                    {title:'4.入党积极分子培养考察',id:'4'},
                    {title:'3.确定入党积极分子',id:'3'},
                    {title:'2.入党的基本知识学习教育',id:'2'},
                    {title:'1.递交入党申请',id:'1'},
                ],
            }
        },
        created: function() {
            // var me = this;
            // me.token=localStorage.getItem("token")
            // me.post_join=me.showdoc+me.POST_onclass+'?USER_ID='+me.myuser
            // me.$http({
            // method: "post",
            // url: me.post_join,
            // headers: { "Content-Type": "application/x-www-form-urlencoded" ,
            //         "token": me.token == undefined ? '' : me.token,
            //         "userid": me.USER_ID == undefined ? '' : me.USER_ID,
            //         "timestamp": me.timestamp,
            //         "sign": CryptoJS.MD5(me.timestamp + me.USER_ID + me.token + '/zhdj'+me.POST_onclass)+''
            //     }, //新增加
            // credientials: false,
            // emulateJSON: true
            // })
            // .then(
            // ret => {
            //     //请求成功
            //     var tokenkey = ret.headers.map.key // 获取token
            //     me.takestate(tokenkey,ret.body.CODE)
            //     me.joinList = ret.body.DATA;
            // },
            // ret => {
            //     //请求失败
            //     console.log("服务器请求失败！");
            // }
            // );
        },
        methods: {
        
        }
    }
</script>