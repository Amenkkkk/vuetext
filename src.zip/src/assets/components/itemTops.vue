<template>
<div class="itembox">
    <div class="itemUl">
    <div class="itemLi" v-for="(topics,i) in topics" :key='i'>
       <div >
       <img @click="jumpTo(topics.url,{name: topics.name,id: topics.id})" class="item-img" resize="contain" :src="topics.img"/>
       <div class="item-name" @click="jumpTo(topics.url,{name: topics.name,id: topics.id})">{{topics.name}}</div>
       </div>
    </div>
    </div>
</div>
</template>
<style scoped>
.itembox{display: block;}
.itemUl{ flex-direction: row ;align-content: space-between; width: 100%; display: flex;}
.itemLi{ flex: 1 ; flex-direction:column; text-align: center;}
.item-img{ width:25px; height: 25px; margin-bottom:5px; margin-top:10px;}
.itemLi .item-name{ text-align: center; font-size: 14px;}

</style>
<script>
    export default {
        props:["topics"],
        data () {
            return {
                
            }
        },
        methods: {
        }
    }
</script>