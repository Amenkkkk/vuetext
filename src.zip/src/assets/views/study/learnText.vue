<template>
    <div class="wrapper">
        <list-header :title="title"></list-header>
        <div class="iframe_div">
            <iframe ref="webview" class="webview_zxcp" :src="POST_zxcp"></iframe>
        </div>
    </div>
</template>
<style scoped>
.iframe_div{
    position: fixed;
    width: 100%;
    top: 35px;
    bottom: 0px;
    left: 0;
    right: 0;
    /* transition: left 0.2s ease-in-out; */
}
.webview_zxcp{
    width: 100%;
    height: 100%;
    border: none
}
.nottablist{
    top: 100px;
}
.main-ul{
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    flex-direction: row;
}
</style>

<script>
    import Header from '../../components/listHeader.vue';
    export default {
        components: {
            'list-header': Header,
        },
        data () {
            return {
                loadinging: false,
                refreshing: false,
                title:'学习测评',
                POST_zxcp:'/appexam/measurement',
                tablise:{
                    activeTab: 0,
                    tabNum:2,  //这里是tab个数，tab大于1时必填
                    tabWidth:375,  //这里是tab宽度，建议：tab=2时，tabWidth=375； tab=3时，tabWidth=250；
                    textItems: {
                    },
                },
                              
                showLoading: 'hide'
            }
        },
        created: function() {
            var me=this;
         //   me.POST_zxcp=me.showdoc+'/appexam/measurement'+'?DEPT_ID='+me.mydept+'&USER_ID='+me.myuser;
          me.POST_zxcp='http://www.baidu.com/'; //服务器链接不可用，链接百度测试
        // storage.getItem('userDATA', event => {
            //     // console.log('get value:', event.data)
            //     var USER=JSON.parse(event.data)
            //     me.mydept = USER.DATA.DEPT_ID
            //     me.myuser = USER.DATA.USER_ID
            //     me.POST_zxcp=me.showdoc+'/zhdj/appexam/measurement'+'?DEPT_ID='+me.mydept+'&USER_ID='+me.myuser;
            // })
        },
        methods: {
        }
    }
        
</script>
