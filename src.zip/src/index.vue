<template>
  <div id="web">
    <!-- <img src="./assets/logo.png"> -->
      <router-view/>   
  </div>
</template>

<script>
export default {
  name: 'web',
  mounted: function() {
     this.token=localStorage.getItem("token")
     if(this.token==""||this.token==undefined||this.token==null){
       this.$router.replace({ name: "login"}); //无toke则跳转
     }
   }
  }  
</script>

<style> /*公共样式*/
body{background-color: #fff;}
#web {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
}
.main-list {
  position: fixed;
  top: 35px;
  bottom: 63px;
  left: 0;
  width: 100%;
  right: 0; overflow-y: scroll;
}
.main-page {
  position: fixed;
  top: 35px;
  bottom: 0px;
  left: 0;
  right: 0; overflow-x: hidden; overflow-y: auto;
}
input{font-size: 16px;}
/*提示样式*/
.mint-toast {
    position: fixed;
    max-width: 80%;
    border-radius: 5px;
    background: rgba(0, 0, 0, 0.7);
    color: #fff;
    box-sizing: border-box;
    text-align: center;
    z-index: 1000;
    -webkit-transition: opacity .3s linear;
    transition: opacity .3s linear
}
.mint-toast.is-placebottom {
    bottom: 50px;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
            transform: translate(-50%, 0)
}
.mint-toast.is-placemiddle {
    left: 50%;
    top: 50%;
    -webkit-transform: translate(-50%, -50%);
            transform: translate(-50%, -50%)
}
.mint-toast.is-placetop {
    top: 50px;
    left: 50%;
    -webkit-transform: translate(-50%, 0);
            transform: translate(-50%, 0)
}
.mint-toast-icon {
    display: block;
    text-align: center;
    font-size: 56px
}
.mint-toast-text {
    font-size: 14px;
    display: block;
    text-align: center
}
.mint-toast-pop-enter, .mint-toast-pop-leave-active {
    opacity: 0
}
.loadmore-top,.loadmore-bottom {
  text-align: center;
  font-size: 13px;
  line-height: 30px;
}
.loadmore-top{
    position: absolute;
    top:-40px;
    width: 100%;
}
/*信息弹出框样式*/
.mint-msgbox {
  position: fixed;
  top: 50%;
  left: 50%;
  -webkit-transform: translate3d(-50%, -50%, 0);
          transform: translate3d(-50%, -50%, 0);
  background-color: #fff;
  width: 85%;
  border-radius: 3px;
  font-size: 16px;
  -webkit-user-select: none;
  overflow: hidden;
  -webkit-backface-visibility: hidden;
          backface-visibility: hidden;
  -webkit-transition: .2s;
  transition: .2s;
}
.mint-msgbox-header {
  padding: 15px 0 0;
}
.mint-msgbox-content {
  padding: 10px 20px 15px;
  border-bottom: 1px solid #ddd;
  min-height: 36px;
  position: relative;
}
.mint-msgbox-input {
  padding-top: 15px;
}
.mint-msgbox-input input {
  border: 1px solid #dedede;
  border-radius: 5px;
  padding: 4px 5px;
  width: 100%;
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  outline: none;
}
.mint-msgbox-input input.invalid {
  border-color: #ff4949;
}
.mint-msgbox-input input.invalid:focus {
  border-color: #ff4949;
}
.mint-msgbox-errormsg {
  color: red;
  font-size: 12px;
  min-height: 18px;
  margin-top: 2px;
}
.mint-msgbox-title {
  text-align: center;
  padding-left: 0;
  margin-bottom: 0;
  font-size: 16px;
  font-weight: 700;
  color: #333;
}
.mint-msgbox-message {
  color: #999;
  margin: 0;
  text-align: center;
  line-height: 36px;
}
.mint-msgbox-btns {
  display: -webkit-box;
  display: -ms-flexbox;
  display: flex;
  height: 40px;
  line-height: 40px;
}
.mint-msgbox-btn {
  line-height: 35px;
  display: block;
  background-color: #fff;
  -webkit-box-flex: 1;
      -ms-flex: 1;
          flex: 1;
  margin: 0;
  border: 0;
}
.mint-msgbox-btn:focus {
  outline: none;
}
.mint-msgbox-btn:active {
  background-color: #fff;
}
.mint-msgbox-cancel {
  width: 50%;
  border-right: 1px solid #ddd;
}
.mint-msgbox-cancel:active {
  color: #000;
}
.mint-msgbox-confirm {
  color: #26a2ff;
  width: 50%;
}
.mint-msgbox-confirm:active {
  color: #26a2ff;
}
.msgbox-bounce-enter {
  opacity: 0;
  -webkit-transform: translate3d(-50%, -50%, 0) scale(0.7);
          transform: translate3d(-50%, -50%, 0) scale(0.7);
}
.msgbox-bounce-leave-active {
  opacity: 0;
  -webkit-transform: translate3d(-50%, -50%, 0) scale(0.9);
          transform: translate3d(-50%, -50%, 0) scale(0.9);
}
.v-modal-enter {
  -webkit-animation: v-modal-in .2s ease;
          animation: v-modal-in .2s ease;
}
.v-modal-leave {
  -webkit-animation: v-modal-out .2s ease forwards;
          animation: v-modal-out .2s ease forwards;
}
.v-modal {
  position: fixed;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  opacity: 0.5;
  background: #000;
}
.ybtn{
  color: #ff4081;
}
</style>
